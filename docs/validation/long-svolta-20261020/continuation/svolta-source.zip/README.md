# Svolta

App locale in italiano per piccoli progetti personali. Il flusso attuale permette
creazione, rinomina, archiviazione e riattivazione dei progetti; creazione,
modifica, archiviazione e filtri combinati delle attività. I conflitti tra schede
si risolvono confrontando i dati e scegliendo esplicitamente le modifiche.
La vista **Settimana** raccoglie le scadenze da lunedì a domenica e le attività
senza scadenza, con lo stesso editor della lista. Da entrambe le viste si può
registrare tempo e consultare le sessioni; **Riepilogo** raccoglie la cronologia
globale, i conteggi delle attività e il tempo della settimana scelta, totale e
per progetto, incluso lo storico archiviato. **Backup** permette di scaricare una
copia completa e ripristinarla con consenso esplicito alla sostituzione dei dati.
Nessun account, servizio esterno o telemetria; nessuna dipendenza da installare.

La [guida pratica](docs/guida.md) accompagna il percorso progetto → attività →
settimana → tempo → backup. Il contratto è in [BRIEF.md](BRIEF.md).
Questa descrizione deriva dai sorgenti, non certifica il prodotto.

La missione `long-svolta-20261020-r4` prosegue dal candidato esistente senza un
checkpoint certificato. Il [registro delle verifiche](docs/verifiche.md) riporta
ora le sette ricevute host correnti **PASS**, con comandi, ID completi e gruppi
6/6/4/7/3/4/3. Vi sono separati i limiti della copertura, i controlli locali
dichiarati dal modello e le ricevute storiche del run precedente.

## Avvio

Occorre Node.js **22.13 o successivo** e un browser moderno con JavaScript e
supporto ai dialoghi nativi. Non occorre `npm install`. Dalla cartella del progetto:

```sh
node src/server.mjs
# oppure
npm start
```

Lasciare il terminale aperto e aprire nel browser l’indirizzo annunciato, per esempio:

```text
SVOLTA_READY http://127.0.0.1:4386
```

La pagina dell’app è su `/`. Il server ascolta soltanto su `127.0.0.1`, porta
predefinita `4386`. Per scegliere cartella e porta, in una shell macOS/Linux:

```sh
SVOLTA_DATA_DIR="$HOME/DatiSvolta" PORT=4387 node src/server.mjs
```

`PORT=0` sceglie una porta libera: usare l’indirizzo stampato in `SVOLTA_READY`.
Fermare il processo con **Ctrl+C**. Ai riavvii usare la stessa cartella dati.
Non sono caricate risorse esterne: il server serve la pagina e gli asset locali,
non i sorgenti, la documentazione o i file dati. Questa guida si legge dal repository.

Il layout prevede schermi stretti, ma l’indirizzo locale sul telefono raggiunge
il telefono stesso, non il computer. Non è disponibile un accesso tra dispositivi
né una sincronizzazione. Il server non è predisposto per pubblicazione remota.

## Primo utilizzo

1. In **Progetti**, compilare **Nome progetto** e premere **Crea progetto**.
2. Sul progetto scegliere **Aggiungi un’attività**, oppure aprire **Attività** e
   scegliere **Progetto**. Compilare **Titolo attività** e, se utili, **Note**,
   **Scadenza** e **Stima (minuti)**, quindi **Crea attività**. Lo stato iniziale
   è «Da fare». Il messaggio di successo conferma il salvataggio sul server.
3. **Modifica** sulla scheda apre **Modifica attività**. Cambiare i dettagli o
   **Stato** e premere **Salva modifiche**; il progetto dell’attività resta invariato.
4. **Filtra per progetto**, **Filtra per stato** e **Cerca attività** si combinano
   e aggiornano l’elenco senza invio. La ricerca ignora maiuscole e minuscole in
   titolo e note. **Azzera filtri** torna alle attività di tutti i progetti attivi.
5. In **Progetti**, **Rinomina**, **Archivia** e **Riattiva** aprono un dialogo da
   confermare. Archiviare un progetto conserva i dati e nasconde le sue attività
   dalla vista generale; il filtro progetto permette ancora di consultarle.
6. **Archivia** su una singola attività richiede una conferma e la nasconde da
   tutti gli elenchi. Non c’è ancora una riattivazione delle attività dall’interfaccia.
7. In **Settimana**, scegliere un lunedì in **Inizio settimana** e premere
   **Mostra settimana**. I sette giorni includono le completate e i giorni vuoti;
   sotto si trovano le attività **Senza scadenza**. I filtri Attività non limitano
   questo piano. **Modifica** permette di assegnare, spostare o togliere una
   scadenza; dopo il salvataggio il piano si aggiorna.
8. Sulla scheda scegliere **Registra tempo**. Nel dialogo compilare **Data**,
   **Minuti** (interi 1–1440) e, se utile, **Nota sessione** (massimo 2000 caratteri),
   poi **Salva sessione**. La data iniziale è quella locale di oggi, non la scadenza
   o la settimana visualizzata. Dopo il salvataggio confermato il dialogo si chiude
   automaticamente e il successo è annunciato nella pagina di origine. Cronologia
   e riepilogo già consultati si aggiornano; per vedere le sessioni dell’attività
   riaprire **Registra tempo**. In caso di errore il dialogo resta aperto e gli
   input sono conservati.
9. Per rimuovere una sessione scegliere **Elimina sessione**, controllare data e
   minuti e premere **Conferma eliminazione sessione**. **Annulla eliminazione**
   lascia i dati invariati. L’eliminazione non è annullabile e non cambia l’attività.
   In **Riepilogo** la **Cronologia sessioni** include anche le attività archiviate;
   **Aggiorna cronologia** rilegge le sessioni e il riepilogo dell’ultima data richiesta.
10. In **Riepilogo**, scegliere **Data di riferimento** (inizialmente oggi sul
    dispositivo) e premere **Aggiorna riepilogo**. Il tempo totale e per progetto
    riguarda la settimana contenente quel giorno, da lunedì a domenica inclusi.
    I conteggi Da fare, In corso e Completate comprendono tutte le attività non
    archiviate di progetti attivi, anche fuori settimana; non sono una fotografia
    storica. **Scadute** include Da fare e In corso con scadenza precedente alla
    data scelta. Il tempo comprende anche attività e progetti archiviati.
    La cronologia sottostante rimane globale, senza filtro sulla data.

I dati salvati vengono riletti alla riapertura. Nomi, titoli e note sono testo
letterale: eventuali tag HTML non diventano markup. Le attività completate
restano nell’elenco, salvo i filtri; un record appena salvato può non comparire
se non soddisfa quelli selezionati.

Gli errori conservano gli input. Se il server non conferma un salvataggio per
un’interruzione di connessione, usare **Aggiorna progetti** o **Aggiorna attività**
e controllare i dati prima di riprovare: la modifica potrebbe essere già salvata.
Per una sessione usare **Aggiorna sessioni** nel dialogo o **Aggiorna cronologia**
in Riepilogo: una risposta persa potrebbe riguardare un inserimento già salvato
o un’eliminazione già avvenuta. Non ci sono tentativi automatici.
Gli elenchi si rileggono anche al ritorno nella scheda/finestra, senza
sincronizzazione continua e senza sostituire gli editor aperti.

Su conflitto, lasciare aperta la bozza, scegliere **Leggi versione corrente** e
confrontare prima di inviare di nuovo. Per le attività si sceglie il valore da
applicare per ciascun campo modificato; per i progetti si conferma solo la
rinomina o lo stato richiesto. La [guida ai conflitti](docs/guida.md#conflitti-tra-schede)
spiega le scelte e il caso di un’attività non più consultabile.

Le bozze vivono solo nella pagina: cambiare sezione o aggiornare gli elenchi le
conserva; ricaricare o chiudere la pagina le perde. **Annulla** o **Escape**
scartano le modifiche del dialogo. Durante un salvataggio occorre attendere la
risposta prima di chiuderlo. Per tastiera e schermi stretti vedere la
[guida](docs/guida.md#tastiera-e-schermi-stretti).

## Cartella dati e affidabilità

La cartella predefinita è `~/.local/share/svolta`, fuori dai sorgenti.
`SVOLTA_DATA_DIR` permette di cambiarla; un percorso relativo è risolto dalla
cartella di avvio. Se cartella o `archive.json` non esistono, vengono creati con
un archivio vuoto, senza dati dimostrativi. Cambiare cartella non trasferisce i dati.

`archive.json` contiene il formato interno versione 1, progetti, attività e
`timeEntries`, inclusi i record archiviati e il loro tempo. Gli archivi precedenti
con soli progetti o con progetti e attività vengono letti aggiungendo gli elenchi
mancanti vuoti in memoria, senza cambiare ID, nomi o revisioni; il file è aggiornato
solo alla prima modifica salvata. Campi presenti ma invalidi, sessioni duplicate
o riferimenti incoerenti interrompono l’avvio conservando il file originale.

Ogni scrittura prepara un file temporaneo nella stessa cartella, ne sincronizza
i contenuti e sostituisce il principale con una rinomina atomica. Il successo
viene inviato dopo la sostituzione. Se il salvataggio fallisce, lo stato in
memoria resta quello precedente e le richieste successive possono riprovare.
I temporanei di una chiusura improvvisa non sono caricati come dati.

Usare **un solo processo per cartella dati**, su un filesystem locale che supporti
la rinomina atomica. La coda serializza le modifiche del singolo processo;
non esiste un blocco tra processi. L’archivio è letto interamente in memoria ed
è pensato per piccoli volumi personali. La scrittura atomica non è una garanzia
contro guasti del disco o perdita improvvisa di alimentazione. Non modificare
manualmente il file durante l’esecuzione.

| Problema | Come procedere |
| --- | --- |
| Nessun annuncio `SVOLTA_READY` | Leggere l’errore nel terminale: l’avvio non è completato. Controllare Node, `PORT` (intero 0–65535) e cartella dati. |
| Porta già in uso | Scegliere un’altra `PORT` o `PORT=0`; se Svolta è già avviato sulla stessa cartella, usare quel processo. |
| Archivio illeggibile, vuoto o non valido | L’avvio si interrompe conservando il file. Controllare percorso, permessi e contenuto; non cancellarlo per far partire l’app. `archive.json` deve essere un file regolare, non un collegamento simbolico. |
| Impossibile caricare i dati | Controllare il processo e l’indirizzo, poi usare **Aggiorna progetti**, **Aggiorna attività** o **Mostra settimana** per conservare gli input. |
| Salvataggio rifiutato | Correggere il campo segnalato o controllare la cartella dati; su conflitto seguire il confronto, senza ricaricare la pagina. |
| Riepilogo non aggiornato | Usare **Aggiorna riepilogo**. Se la lettura fallisce, un risultato precedente per la stessa data è segnalato come potenzialmente non aggiornato; cambiando data il vecchio risultato viene nascosto. |

## Backup e ripristino

1. In **Backup**, premere **Scarica backup** e conservare il JSON nei download
   del browser. Contiene tutti i progetti, attività e sessioni, inclusi archivi,
   note, ID e revisioni; le bozze non salvate non sono incluse. È una copia
   manuale in chiaro: nessuna cifratura o copia automatica.
2. Prima di ripristinare, scaricare anche una copia dei dati correnti che si
   vogliono conservare e chiudere le altre schede di Svolta.
3. Scegliere **File di backup**. Il browser controlla JSON UTF-8, formato Svolta
   versione 1, tutti i record e i riferimenti. Un file malformato, incompleto o
   oltre 2 MiB produce un errore visibile e non viene inviato.
4. Selezionare **Ho capito: il ripristino sostituisce i dati correnti**, quindi
   **Ripristina backup**. Servono un file valido e il consenso; cambiarne il file
   azzera il consenso. Durante un’altra scrittura occorre attendere.
5. Attendere il messaggio **Backup ripristinato**. L’archivio viene sostituito
   interamente, senza fusione: i record assenti dalla copia scompaiono. Non c’è
   annullamento; per tornare indietro serve il backup precedente.

Il server ripete la validazione completa prima del salvataggio atomico. Errori
400/413/503 lasciano invariati memoria e file persistente. Il ripristino conserva
ID, revisioni, archiviazioni e sessioni originali senza rigenerarli o incrementarli.
Dopo il successo, il browser scarta bozze, editor, confronti di revisione, filtri
e selezioni precedenti; imposta settimana corrente e data di riferimento di oggi
e rilegge progetti, attività, settimana, cronologia globale e riepilogo. Una vista
che non riesce a caricarsi mostra il proprio errore e permette di riprovare.

Se si perde la risposta del server, l’esito può essere incerto: il browser azzera
comunque i vecchi editor e rilegge le viste. Controllare i dati, anche scaricando
una copia, prima di dare di nuovo il consenso. Non ci sono tentativi automatici.
Le altre schede non ricevono una notifica di sostituzione: riaprirle dopo il
ripristino, senza salvare le loro vecchie bozze. Le revisioni importate sono
quelle originali e possono coincidere con revisioni viste prima del ripristino.

Per trasferire i dati, avviare Svolta nella destinazione con una cartella dati
separata e importare il JSON con la stessa procedura. Il file interno
`archive.json` non è il backup portabile: manca il campo `format`. Non caricarlo
come backup e non modificarlo durante l’esecuzione. Non sono previste importazioni
da altri prodotti, fusioni, recupero automatico o cifratura. L’archivio può crescere
oltre 2 MiB ed essere esportato, ma il limite delle richieste impedisce di
ripristinare copie oltre 2 MiB: questa versione non offre suddivisione automatica.

## Uso delle API

Le risposte sono JSON, salvo il 204 senza corpo dopo l’eliminazione di una sessione.
Per inviare dati usare `Content-Type: application/json`.
Il corpo di una richiesta può occupare al massimo 2 MiB. Gli ID negli esempi
sono segnaposto da sostituire con quelli restituiti dal server.

### Progetti

| Richiesta | Corpo | Risultato |
| --- | --- | --- |
| `GET /api/projects` | — | Array di tutti i progetti, inclusi gli archiviati |
| `POST /api/projects` | `{"name":"Studio"}` | 201, progetto creato |
| `PATCH /api/projects/<id>` | `{"revision":1,"name":"Studio rivisto"}` | 200, progetto aggiornato |
| `PATCH /api/projects/<id>` | `{"revision":2,"archived":true}` | 200, progetto archiviato senza cancellazione |

Un nuovo progetto ha questa struttura:

```json
{"id":"<UUID>","name":"Studio","archived":false,"revision":1}
```

Il nome viene ripulito dagli spazi ai bordi e deve contenere da 1 a 100 caratteri
Unicode. `archived` accetta soltanto booleani; `false` riattiva un progetto.
I campi non previsti sono rifiutati. Ogni PATCH accettata incrementa la revisione
di uno, anche quando i valori non cambiano. ID e revisione iniziale sono generati
dal server, non scelti dal chiamante.

### Attività

| Richiesta | Corpo o filtri | Risultato |
| --- | --- | --- |
| `GET /api/tasks` | — | Array di attività non archiviate di progetti attivi |
| `GET /api/tasks?projectId=<id>&status=doing&q=caff%C3%A8` | Filtri facoltativi e combinabili | Attività del progetto, in corso, con «caffè» nel titolo o nelle note |
| `POST /api/tasks` | `{"projectId":"<id>","title":"Leggere"}` | 201, attività creata |
| `PATCH /api/tasks/<id>` | `{"revision":1,"status":"doing","dueDate":"2028-02-29"}` | 200, attività aggiornata |
| `PATCH /api/tasks/<id>` | `{"revision":2,"archived":true}` | 200, attività archiviata senza cancellazione |

Una nuova attività con i soli campi obbligatori restituisce:

```json
{"id":"<UUID>","projectId":"<id>","title":"Leggere","notes":"","status":"todo","dueDate":null,"estimateMinutes":0,"archived":false,"revision":1}
```

Per creare un’attività occorre un progetto esistente e attivo. Il titolo viene
ripulito dagli spazi ai bordi e deve contenere da 1 a 160 caratteri Unicode.
Le note sono testo libero di massimo 4000 caratteri Unicode: spazi, a capo e
markup restano testo. `estimateMinutes` è un numero intero da 0 a 10080, non una
stringa. I campi omessi diventano `notes: ""`, `dueDate: null`,
`estimateMinutes: 0`; i valori null non sono ammessi per note e stima.

`dueDate` è null oppure una data civile esatta `YYYY-MM-DD`, con anno da 0001 a
9999 e giorno reale nel calendario gregoriano. Per esempio `2028-02-29` è valida,
`2026-02-29` e `2026-04-31` vengono rifiutate. Non si accettano orari, stringhe
vuote o date con mese/giorno senza zero iniziale. La data viene conservata come
stringa senza conversioni UTC o dipendenza dal fuso orario del computer.

Il PATCH richiede `revision` e accetta i campi `title`, `notes`, `dueDate`,
`estimateMinutes`, `status`, `archived`. La sola revisione è ammessa e viene
incrementata come negli altri PATCH. Gli stati ammessi sono `todo`, `doing`,
`done`; `archived` accetta solo booleani. `dueDate: null` rimuove la scadenza.
ID e progetto di un’attività non possono essere cambiati. Campi sconosciuti,
compresi stato e archiviazione alla creazione, vengono rifiutati.

La lista mantiene l’ordine di creazione e include le attività completate.
La ricerca `q` è una sottostringa senza distinzione di maiuscole in titolo o
note; un valore vuoto non restringe l’elenco. I tre filtri sono applicati insieme.
Uno stato non valido dà 400, un `projectId` sconosciuto dà 404.
Un `projectId` esplicito mostra anche le attività del relativo progetto
archiviato, sempre escludendo le attività archiviate e gli altri progetti.

Archiviare un progetto nasconde le sue attività dalla lista generale senza
alterarne i record; riattivarlo le rende nuovamente visibili. Archiviare
un’attività la nasconde da tutte le liste senza eliminarla: è riattivabile con
un PATCH al suo ID noto e alla revisione corrente. Modificare attività già
archiviate o appartenenti a progetti archiviati è consentito; crearne di nuove
in un progetto archiviato è rifiutato. Cambiare stato o archiviazione conserva
gli ID e tutti gli altri campi.

Esempio pratico con `curl`, dopo aver avviato il server:

```sh
curl -H 'Content-Type: application/json' \
  -d '{"name":"Studio"}' http://127.0.0.1:4386/api/projects
# Copiare l’id restituito e sostituire ID_PROGETTO:
curl -H 'Content-Type: application/json' \
  -d '{"projectId":"ID_PROGETTO","title":"Leggere","notes":"Capitolo 1","estimateMinutes":25}' \
  http://127.0.0.1:4386/api/tasks
curl 'http://127.0.0.1:4386/api/tasks?status=todo&q=capitolo'
# Copiare l’id dell’attività e la sua revisione corrente:
curl -X PATCH -H 'Content-Type: application/json' \
  -d '{"revision":1,"status":"doing"}' \
  http://127.0.0.1:4386/api/tasks/ID_ATTIVITA
```

### Settimana (API)

`GET /api/week?start=2026-10-19` restituisce `{start,days,unscheduled}`:
`days` contiene sette oggetti `{date,tasks}`, ordinati da lunedì a domenica,
anche quando un giorno è vuoto. Le attività senza scadenza sono in `unscheduled`.
Sono incluse solo attività non archiviate di progetti attivi; le completate
restano presenti con `status: "done"`. Le attività con scadenza fuori dalla
settimana sono escluse. In ogni elenco resta l’ordine di creazione e i record
conservano tutti i campi, comprese le revisioni.

`start` è obbligatorio e deve essere un lunedì reale nel formato `YYYY-MM-DD`.
Valori mancanti, date impossibili e giorni diversi dal lunedì danno 400.
Il calcolo usa il calendario gregoriano senza conversioni di fuso e gestisce
cambi di mese, anno e bisestili. Tutti e sette i giorni devono rientrare negli
anni 0001–9999: una settimana che supera questo intervallo dà 400.
La lettura non modifica attività, revisioni o archivio. La vista **Settimana**
nel browser usa questa API indipendentemente dai filtri della lista Attività.
All’apertura propone il lunedì della settimana locale corrente. **Mostra settimana**
invia la data scelta senza correggerla automaticamente: un giorno diverso dal
lunedì viene rifiutato con un errore leggibile. L’intervallo mostrato resta
esplicito anche se si sta preparando una nuova data nel campo.

Salvare una modifica o un’archiviazione aggiorna il piano; archiviare un progetto
ne nasconde le attività. Le bozze negli editor restano conservate durante gli
aggiornamenti. Il ritorno nella sezione o nella scheda rilegge la settimana
richiesta, senza inviare la data ancora in bozza. Non c’è sincronizzazione continua.
Se una rilettura fallisce, l’eventuale piano conservato è segnalato come potenzialmente
non aggiornato; riprovare con **Mostra settimana**. Le date sono mostrate come
giorno/mese/anno, senza conversioni di fuso.

### Sessioni di tempo (API)

| Richiesta | Corpo o filtri | Risultato |
| --- | --- | --- |
| `POST /api/time-entries` | `{"taskId":"<id>","date":"2026-10-21","minutes":25,"note":"Capitolo 1"}` | 201, sessione salvata con `id` e `projectId` assegnati dal server |
| `GET /api/time-entries` | — | Tutte le sessioni in ordine di registrazione, anche di attività o progetti archiviati |
| `GET /api/time-entries?taskId=<id>` | ID di un’attività esistente, anche archiviata | Solo le sessioni di quella attività |
| `DELETE /api/time-entries/<id>` | Nessun corpo richiesto | 204 senza corpo, elimina solo la sessione indicata |

La registrazione richiede un’attività e un progetto non archiviati; è ammessa anche
per attività completate. `date` è una data civile reale `YYYY-MM-DD`, `minutes` è
un numero intero da 1 a 1440 e `note` è testo letterale di massimo 2000 caratteri
Unicode (default `""`). Le stringhe numeriche e i campi non previsti sono rifiutati.
Un ID di attività o sessione sconosciuto dà 404. Registrare o eliminare una sessione
non cambia stato, campi o revisione dell’attività. L’archiviazione conserva la
cronologia e l’eliminazione resta possibile anche dopo l’archiviazione.

### Riepilogo (API)

`GET /api/summary?date=2026-10-21` restituisce `date`, `weekStart`, `weekEnd`,
`totals` e `byProject`. La data è obbligatoria e segue le stesse regole civili
della settimana, senza conversioni di fuso; nell’esempio l’intervallo incluso
è `2026-10-19`–`2026-10-25`. Una data invalida o una settimana che oltrepassa
gli anni 0001–9999 dà 400.

`totals.todo`, `doing` e `done` contano tutte le attività non archiviate di progetti
attivi, anche fuori settimana. `overdue` conta quelle non completate, incluse le
`doing`, con scadenza anteriore alla data di riferimento; esclude le attività
senza scadenza e quelle `done`.
`minutesThisWeek` somma solo le sessioni dal lunedì alla domenica inclusi.

La scelta attuale è conservare nel totale anche il tempo di attività e progetti
archiviati: l’archiviazione non cancella il lavoro svolto. `byProject` include
tutti i progetti nell’ordine di creazione, con `projectId`, nome corrente,
`minutesThisWeek` e numero di attività attive `done`. Un progetto archiviato ha
quindi `done: 0`, ma può avere minuti. Le somme di minuti e `done` per progetto
coincidono con i rispettivi totali; eliminare una sessione aggiorna i minuti
senza alterare i conteggi delle attività.
Questa lettura non modifica l’archivio. Il browser usa l’intero risultato con
**Data di riferimento** e **Aggiorna riepilogo**, indipendentemente dai filtri
Attività e dalla settimana aperta nel piano. La data scelta stabilisce la soglia
delle scadute e la settimana del tempo, non ricostruisce gli stati passati.
Salvataggi, archiviazioni e modifiche alle sessioni rileggono l’ultima data
richiesta senza sostituire quella eventualmente in bozza. Stati vuoti,
caricamento ed errori sono espliciti; una risposta precedente non sostituisce
una lettura più recente. La cronologia globale resta consultabile anche se il
riepilogo non si carica.

### Backup (API)

| Richiesta | Corpo | Risultato |
| --- | --- | --- |
| `GET /api/backup` | — | 200, JSON scaricabile con `Content-Disposition: attachment` |
| `POST /api/restore` | Backup completo | 200, `{"restored":true}` |

La struttura portabile è:

```json
{"format":"svolta","version":1,"projects":[],"tasks":[],"timeEntries":[]}
```

Gli elenchi contengono i record completi delle API, inclusi gli archivi. Formato,
versione, campi mancanti o estranei, tipi, limiti, date reali, stati, revisioni,
ID duplicati per tipo e riferimenti incoerenti sono validati prima di sostituire
l’archivio. Un backup vuoto valido svuota tutti i dati. Il server usa la stessa
coda e rinomina atomica delle altre scritture; un errore lascia i dati precedenti.
JSON malformato dà 400, un corpo oltre 2 MiB dà 413, senza interrompere il server.
Il consenso è un controllo del browser: chi usa direttamente l’API deve essere
consapevole che `POST /api/restore` sostituisce i dati senza un’ulteriore conferma.

### Revisioni ed errori

Per modificare, leggere prima la revisione corrente e inviarla nel PATCH.
Ogni aggiornamento riuscito incrementa la revisione di uno, anche a valori
invariati. Progetti, attività, sessioni e ripristini condividono una coda: confronto della
revisione, controlli dei riferimenti e dell’archiviazione e salvataggio sono serializzati.
Due aggiornamenti concorrenti dello stesso record con la stessa revisione
producono un successo e un 409, se il salvataggio riesce. Il client deve
conservare i propri input su un conflitto, rileggere i dati e scegliere cosa
applicare; non ritentare automaticamente con una revisione più recente.
Richieste invalide, conflitti ed errori di salvataggio lasciano invariati record
e revisioni. Il successo viene comunicato solo dopo aver salvato l’archivio.

Gli errori hanno forma `{"error":"Messaggio in italiano","code":"CODICE"}`:

- 400: dati non validi, revisione mancante o JSON malformato;
- 404: indirizzo o identificativo sconosciuto;
- 405: metodo HTTP non disponibile, con intestazione `Allow`;
- 409: revisione obsoleta (o limite numerico delle revisioni raggiunto);
- 413: corpo troppo grande; 415: tipo di contenuto diverso da JSON;
- 503: salvataggio fallito, senza applicare la modifica;
- 500: errore interno inatteso, dettagli nel terminale.

## Stato delle verifiche

Le sette [ricevute host correnti](docs/verifiche.md#ricevute-host-correnti) del run
`20261020T234131-6d40b050`, contratto v1, riportano **PASS** per `projects-api`,
`tasks-api`, `board-ui`, `planning-api`, `planning-ui`, `backup-api` e `backup-ui`,
con gruppi rispettivamente **6/6/4/7/3/4/3**. Il registro contiene i sette comandi
approvati e gli ID completi consultati nel runtime. È una fotografia degli esiti
disponibili prima di questo aggiornamento documentale, senza riesecuzione locale.

Le ricevute coprono i casi API e browser approvati, compresi download reale,
consenso al ripristino e assenza di scorrimento orizzontale nelle viste Attività,
Settimana e Backup a 390 × 844. I [limiti della copertura](docs/verifiche.md#copertura-e-limiti)
restano espliciti: non costituiscono un collaudo completo di ogni flusso, layout,
focus o accessibilità, né di tutti gli aggiornamenti dopo il ripristino.

I controlli locali di sintassi, validazione e logica simulata sono dichiarazioni
conservate dalla consegna dell’implementazione, distinte dagli esiti host e non
rieseguite qui. Questo task ha controllato documentazione, collegamenti e diff,
senza modificare codice, test o contratto né avviare suite API/browser. Le cinque
ricevute del run `20261020T231956-19cf8a63` rimangono nello storico. Non si dichiara
un checkpoint certificato, un revisore indipendente o una pubblicazione.
