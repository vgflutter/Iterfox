'use strict';

// Keep server records separate from the live form controls. Refreshing a list
// must never replace an unsaved draft, including its project selection.
const byId = id => document.getElementById(id);
const projectForm = byId('project-form');
const taskForm = byId('task-form');
const projectSelect = byId('task-project');
const projectFilter = byId('filter-project');
const statusFilter = byId('filter-status');
const searchFilter = byId('filter-search');
const projectDialog = byId('project-dialog');
const projectEditForm = byId('project-edit-form');
const taskDialog = byId('task-dialog');
const taskEditForm = byId('task-edit-form');
const weekForm = byId('week-form');
const weekStartInput = byId('week-start');
const timeDialog = byId('time-dialog');
const timeForm = byId('time-form');
const summaryForm = byId('summary-form');
const summaryDateInput = byId('summary-date');
const restoreForm = byId('restore-form');
const backupFileInput = byId('backup-file');
const backupConsent = byId('backup-consent');
const maxBackupBytes = 2 * 1024 * 1024;
let backupCandidate = null;
let backupFileRead = 0;
let backupFileLoading = false;
let backupDownloading = false;
let backupRestoring = false;
let pendingWrites = 0;
const taskStates = { todo: 'Da fare', doing: 'In corso', done: 'Completata' };
const taskComparisonFields = [
  ['title', 'Titolo attività'], ['notes', 'Note'], ['dueDate', 'Scadenza'],
  ['estimateMinutes', 'Stima (minuti)'], ['status', 'Stato'], ['archived', 'Archiviazione'],
];
let projectEditor = null;
let taskEditor = null;
let projects = [];
let tasks = [];
let projectsLoaded = false;
let projectsFailed = false;
let tasksLoaded = false;
let tasksLoading = true;
let projectRead = 0;
let taskRead = 0;
let creatingProject = false;
let creatingTask = false;
// The submitted week and its records are independent of task filters and of
// the date currently being drafted in the week control.
let weekStart = currentMonday();
let weekPlan = null;
let weekRead = 0;
let weekRequested = false;
let timeEditor = null;
let timeWritePending = false;
let timePendingStatus = 'time-form-status';
const timeHistory = { prefix: 'time-history', taskId: null, records: null, read: 0, requested: false, confirmId: null };
// Refresh the submitted reference date, leaving any unsent date in the control.
let summaryDate = currentCivilDate();
let summaryData = null;
let summaryRequested = false;
let summaryRead = 0;

function currentCivilDate() {
  const today = new Date();
  return `${String(today.getFullYear()).padStart(4, '0')}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
}

function currentMonday() {
  const today = new Date();
  today.setDate(today.getDate() - (today.getDay() + 6) % 7);
  return `${String(today.getFullYear()).padStart(4, '0')}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
}

function formatCivilDate(value) {
  const [year, month, day] = value.split('-');
  return `${day}/${month}/${year}`;
}

function message(id, text = '') {
  const target = byId(id);
  target.textContent = text;
  target.hidden = !text;
}

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

// Native disabled controls can lose focus. Keep a focusable progress message
// in the modal while its controls are locked, then expose errors in reading order.
function focusDialogError(prefix) {
  const error = byId(`${prefix}-edit-error`);
  if (!error.hidden) error.focus();
}

function restoreActionFocus(container, previous, kind, fallback) {
  const buttons = [...container.querySelectorAll(`[data-${kind}-action]`)];
  const id = previous.dataset[`${kind}Id`];
  const action = previous.dataset[`${kind}Action`];
  const replacement = buttons.find(button => button.dataset[`${kind}Id`] === id && button.dataset[`${kind}Action`] === action)
    ?? buttons.find(button => button.dataset[`${kind}Id`] === id);
  (replacement ?? fallback).focus({ preventScroll: true });
}

function navigate(page, moveFocus = true) {
  for (const button of document.querySelectorAll('nav [data-page]')) {
    const selected = button.dataset.page === page;
    byId(button.dataset.page).hidden = !selected;
    if (selected) button.setAttribute('aria-current', 'page');
    else button.removeAttribute('aria-current');
  }
  byId('contenuto').prepend(byId(page));
  if (moveFocus) byId(`${page}-heading`).focus();
  if (page === 'settimana') void loadWeek();
  if (page === 'riepilogo') {
    void loadTimeHistory(timeHistory);
    void loadSummary();
  }
}

class RequestError extends Error {
  constructor(text, code, status) {
    super(text);
    this.code = code;
    this.status = status;
  }
}

async function api(path, input, method = input === undefined ? 'GET' : 'POST') {
  const saving = method !== 'GET';
  // A restore starts only once previous writes have settled. Until its response,
  // no editor or form may enqueue a change against the archive being replaced.
  if (saving && backupRestoring && path !== '/api/restore') {
    throw new RequestError('Ripristino in corso. Attendi il completamento prima di modificare i dati.', 'RESTORING');
  }
  if (saving) { ++pendingWrites; syncBackupControls(); }
  try {
    let response;
    let data;
    try {
      response = await fetch(path, {
        method,
        cache: 'no-store',
        headers: input !== undefined ? { 'Content-Type': 'application/json' } : {},
        ...(input !== undefined ? { body: JSON.stringify(input) } : {}),
      });
      data = response.status === 204 ? null : await response.json();
    } catch {
      if (method === 'DELETE') {
        throw new RequestError('Impossibile confermare l’eliminazione. Aggiorna la cronologia e controlla se la sessione è ancora presente prima di riprovare.', 'CONNECTION');
      }
      throw new RequestError(saving
        ? 'Non è stato possibile confermare il salvataggio. Gli input sono conservati. Aggiorna l’elenco e controlla se il record è presente prima di riprovare.'
        : 'Impossibile caricare i dati. Controlla che il server Svolta sia avviato e riprova con Aggiorna.', 'CONNECTION');
    }
    if (!response.ok) {
      throw new RequestError(typeof data?.error === 'string' ? data.error : 'La richiesta non è riuscita. Riprova.', data?.code, response.status);
    }
    return data;
  } finally {
    if (saving) { --pendingWrites; syncBackupControls(); }
  }
}

function renderProjectFilter() {
  const selected = projectFilter.value;
  const previousName = projectFilter.selectedOptions[0]?.dataset.name ?? 'Progetto selezionato';
  const options = document.createDocumentFragment();
  options.append(new Option('Tutti i progetti attivi', ''));
  for (const archived of [false, true]) {
    const group = element('optgroup');
    group.label = archived ? 'Archiviati' : 'Attivi';
    for (const project of projects.filter(item => item.archived === archived)) {
      const option = new Option(`${project.name}${archived ? ' (archiviato)' : ''}`, project.id);
      option.dataset.name = project.name;
      group.append(option);
    }
    if (group.children.length) options.append(group);
  }
  if (selected && !projects.some(item => item.id === selected)) {
    const option = new Option(`${previousName} (non disponibile)`, selected);
    option.dataset.name = previousName;
    options.append(option);
  }
  projectFilter.replaceChildren(options);
  projectFilter.value = selected;
  const project = projects.find(item => item.id === selected);
  message('filter-project-selection', selected ? `Progetto filtrato: ${project?.name ?? previousName}` : '');
  byId('filter-project-help').textContent = selected && !project && projectsLoaded
    ? 'Il progetto selezionato non è disponibile. Scegli esplicitamente un altro filtro; la bozza attività è conservata.'
    : project?.archived
      ? 'Stai consultando un progetto archiviato. Le sue attività restano salvate; riattivalo per crearne altre.'
      : 'La vista generale esclude i progetti archiviati. Puoi selezionarli per consultarne le attività.';
}

function renderProjectOptions() {
  const selected = projectSelect.value;
  const previousName = projectSelect.selectedOptions[0]?.dataset.name ?? 'Progetto selezionato';
  const options = document.createDocumentFragment();
  options.append(new Option('Scegli un progetto', ''));
  for (const project of projects.filter(item => !item.archived)) {
    const option = new Option(project.name, project.id);
    option.dataset.name = project.name;
    options.append(option);
  }
  if (selected && !projects.some(item => item.id === selected && !item.archived)) {
    const name = projects.find(item => item.id === selected)?.name ?? previousName;
    const option = new Option(`${name} (non disponibile)`, selected);
    option.dataset.name = name;
    option.disabled = true;
    options.append(option);
  }
  projectSelect.replaceChildren(options);
  projectSelect.value = selected;
  showAvailability();
}

function showAvailability() {
  const selected = projectSelect.value;
  const project = projects.find(item => item.id === selected);
  const available = project && !project.archived;
  message('task-project-selection', selected
    ? `Progetto scelto: ${project?.name ?? projectSelect.selectedOptions[0]?.dataset.name ?? 'Progetto non disponibile'}`
    : '');
  message('project-availability', projectsFailed && !projectsLoaded
    ? 'Impossibile caricare i progetti. Usa Aggiorna attività per riprovare. Gli input sono conservati.'
    : selected && !available
      ? project?.archived
        ? 'Il progetto selezionato è archiviato e non accetta nuove attività. La bozza è conservata: riattiva il progetto in Progetti oppure scegli esplicitamente un altro progetto attivo.'
        : 'Il progetto selezionato non è più disponibile per nuove attività. Gli altri input sono conservati: scegli esplicitamente un progetto attivo.'
      : '');
  byId('task-project-help').textContent = !projectsLoaded
    ? 'I progetti devono essere caricati prima di creare un’attività.'
    : !projects.some(item => !item.archived)
      ? 'Non ci sono progetti attivi. Crea prima un progetto nella sezione Progetti.'
      : 'Puoi aggiungere attività ai progetti attivi.';
}

function renderProjects() {
  const focusedAction = document.activeElement;
  const restoreFocus = focusedAction?.dataset.projectAction && byId('progetti').contains(focusedAction);
  const active = document.createDocumentFragment();
  const archived = document.createDocumentFragment();
  for (const project of projects) {
    const card = element('li', 'project-card');
    const info = element('div');
    info.append(element('p', 'project-name', project.name));
    info.append(element('span', `badge${project.archived ? ' archived' : ''}`, project.archived ? 'Archiviato' : 'Attivo'));
    const actions = element('div', 'project-actions');
    if (!project.archived) {
      const button = element('button', 'subtle', 'Aggiungi un’attività');
      button.type = 'button';
      button.setAttribute('aria-label', `Aggiungi un’attività a ${project.name}`);
      button.dataset.projectId = project.id;
      button.dataset.projectAction = 'add';
      button.addEventListener('click', () => {
        if (creatingTask) return;
        // This explicit action may change the project; background refreshes may not.
        projectSelect.value = project.id;
        showAvailability();
        navigate('attivita');
        byId('task-title').focus();
      });
      actions.append(button);
    }
    for (const action of ['rename', project.archived ? 'restore' : 'archive']) {
      const label = { rename: 'Rinomina', archive: 'Archivia', restore: 'Riattiva' }[action];
      const button = element('button', 'subtle', label);
      button.type = 'button';
      button.setAttribute('aria-label', `${label} ${project.name}`);
      button.dataset.projectId = project.id;
      button.dataset.projectAction = action;
      button.addEventListener('click', () => openProjectEditor(project, action));
      actions.append(button);
    }
    card.append(info, actions);
    (project.archived ? archived : active).append(card);
  }
  const activeCount = projects.filter(item => !item.archived).length;
  const archivedCount = projects.length - activeCount;
  byId('project-list').replaceChildren(active);
  byId('archived-project-list').replaceChildren(archived);
  byId('project-count').textContent = projectsLoaded ? `(${projects.length})` : '';
  byId('active-project-count').textContent = `(${activeCount})`;
  byId('archived-project-count').textContent = `(${archivedCount})`;
  byId('active-projects').hidden = !projectsLoaded || projects.length === 0;
  byId('active-projects-empty').hidden = activeCount > 0;
  byId('archived-projects').hidden = archivedCount === 0;
  byId('projects-empty').hidden = !projectsLoaded || projects.length > 0;
  renderProjectOptions();
  renderProjectFilter();
  renderTasks();
  renderWeek();
  if (timeHistory.records !== null) renderTimeHistory(timeHistory);
  if (restoreFocus) restoreActionFocus(byId('progetti'), focusedAction, 'project', byId('progetti-heading'));
}

function visibleTasks() {
  const selected = projectFilter.value;
  const query = searchFilter.value.toLowerCase();
  // Also filter optimistic save results by the current controls. Never insert
  // a newly saved task into an unrelated filtered view while its GET is pending.
  return tasks.filter(task => !task.archived
    && (selected ? task.projectId === selected
      : !projectsLoaded || projects.some(project => project.id === task.projectId && !project.archived))
    && (!statusFilter.value || task.status === statusFilter.value)
    && (task.title.toLowerCase().includes(query) || task.notes.toLowerCase().includes(query)));
}

// Both views open the same revision-aware editor with the full API record.
function taskCard(task, headingId) {
  const card = element('article', 'task-card');
  const title = element('h4', '', task.title);
  title.id = headingId;
  card.setAttribute('aria-labelledby', title.id);
  card.append(element('span', `badge ${task.status}`, taskStates[task.status] ?? task.status), title);
  card.append(element('p', 'task-project', projects.find(item => item.id === task.projectId)?.name
    ?? (projectsLoaded ? 'Progetto non disponibile' : 'Nome progetto non caricato')));
  if (task.notes) card.append(element('p', 'task-notes', task.notes));
  const details = element('dl', 'task-details');
  const due = element('div');
  due.append(element('dt', '', 'Scadenza'));
  const dueValue = element('dd');
  if (task.dueDate) {
    const time = element('time', '', formatCivilDate(task.dueDate));
    time.dateTime = task.dueDate;
    dueValue.append(time);
  } else dueValue.textContent = 'Nessuna';
  due.append(dueValue);
  const estimate = element('div');
  estimate.append(element('dt', '', 'Stima'), element('dd', '', task.estimateMinutes ? `${task.estimateMinutes} min` : 'Non indicata'));
  details.append(due, estimate);
  card.append(details);
  const actions = element('div', 'task-actions');
  for (const action of ['edit', 'archive']) {
    const label = action === 'edit' ? 'Modifica' : 'Archivia';
    const button = element('button', 'subtle', label);
    button.type = 'button';
    button.setAttribute('aria-label', `${label} ${task.title}`);
    button.dataset.taskId = task.id;
    button.dataset.taskAction = action;
    button.addEventListener('click', () => openTaskEditor(task, action));
    actions.append(button);
  }
  const recordTime = element('button', 'subtle', 'Registra tempo');
  recordTime.type = 'button';
  recordTime.setAttribute('aria-label', `Registra tempo per ${task.title}`);
  recordTime.dataset.taskId = task.id;
  recordTime.dataset.taskAction = 'time';
  recordTime.addEventListener('click', () => openTimeEditor(task));
  actions.append(recordTime);
  card.append(actions);
  return card;
}

function renderTasks() {
  const list = document.createDocumentFragment();
  const focusedAction = document.activeElement;
  const restoreFocus = focusedAction?.dataset.taskAction && byId('task-list').contains(focusedAction);
  const visible = visibleTasks();
  visible.forEach((task, index) => list.append(taskCard(task, `task-heading-${index}`)));
  byId('task-list').replaceChildren(list);
  byId('task-count').textContent = tasksLoaded ? `(${visible.length})` : '';
  byId('tasks-empty').hidden = !tasksLoaded || tasksLoading || visible.length > 0;
  const filtered = projectFilter.value || statusFilter.value || searchFilter.value;
  byId('tasks-empty-heading').textContent = filtered ? 'Nessuna attività trovata' : 'Qual è il prossimo passo?';
  byId('tasks-empty-help').textContent = filtered
    ? 'Nessuna attività corrisponde a tutti i filtri. Modificali o usa Azzera filtri per tornare alla vista generale.'
    : 'Non ci sono attività visibili. Scegli un progetto attivo e crea la prima.';
  message('task-results-status', tasksLoaded && !tasksLoading
    ? `${visible.length === 1 ? '1 attività visibile' : `${visible.length} attività visibili`}${filtered ? ' con i filtri selezionati' : ''}.`
    : '');
  if (restoreFocus) {
    restoreActionFocus(byId('task-list'), focusedAction, 'task', byId('attivita-heading'));
  }
}

function renderWeek() {
  byId('week-results').hidden = !weekPlan;
  if (!weekPlan) {
    byId('week-days').replaceChildren();
    byId('week-unscheduled-list').replaceChildren();
    return '';
  }
  const focusedAction = document.activeElement;
  const restoreFocus = focusedAction?.dataset.taskAction && byId('week-results').contains(focusedAction);
  // Hide locally archived projects immediately while the authoritative week
  // refresh is in flight. No task-list query or filter participates here.
  const active = records => records.filter(task => !task.archived
    && !projects.find(project => project.id === task.projectId)?.archived);
  const days = document.createDocumentFragment();
  const weekdays = ['Lunedì', 'Martedì', 'Mercoledì', 'Giovedì', 'Venerdì', 'Sabato', 'Domenica'];
  let scheduledCount = 0;
  weekPlan.days.forEach((day, index) => {
    const section = element('section', 'panel week-day');
    section.dataset.date = day.date;
    const heading = element('h3', '', weekdays[index]);
    heading.id = `week-day-heading-${index}`;
    section.setAttribute('aria-labelledby', heading.id);
    const date = element('time', '', formatCivilDate(day.date));
    date.dateTime = day.date;
    heading.append(date);
    section.append(heading);
    const records = active(day.tasks);
    scheduledCount += records.length;
    if (!records.length) section.append(element('p', 'muted week-day-empty', 'Nessuna attività in programma.'));
    const list = element('div', 'task-list');
    records.forEach((task, taskIndex) => list.append(taskCard(task, `week-task-${index}-${taskIndex}`)));
    section.append(list);
    days.append(section);
  });
  const unscheduled = active(weekPlan.unscheduled);
  const list = document.createDocumentFragment();
  unscheduled.forEach((task, index) => list.append(taskCard(task, `week-unscheduled-task-${index}`)));
  byId('week-days').replaceChildren(days);
  byId('week-unscheduled-list').replaceChildren(list);
  byId('week-unscheduled-empty').hidden = unscheduled.length > 0;
  byId('week-range').textContent = `Dal ${formatCivilDate(weekPlan.start)} al ${formatCivilDate(weekPlan.days[6].date)}`;
  if (restoreFocus) restoreActionFocus(byId('week-results'), focusedAction, 'task', byId('settimana-heading'));
  return `${scheduledCount} attività in programma e ${unscheduled.length} senza scadenza.`;
}

async function loadWeek(start = weekStart) {
  const read = ++weekRead;
  weekRequested = true;
  weekStart = start;
  // A previous interval must never appear under a newly requested date.
  if (weekPlan?.start !== start) {
    weekPlan = null;
    renderWeek();
  }
  byId('week-results').setAttribute('aria-busy', 'true');
  byId('week-loading').hidden = false;
  message('week-error');
  message('week-results-status');
  try {
    const plan = await api(`/api/week?${new URLSearchParams({ start })}`);
    if (read !== weekRead) return;
    weekPlan = plan;
    const counts = renderWeek();
    message('week-results-status', `Settimana dal ${formatCivilDate(plan.start)} al ${formatCivilDate(plan.days[6].date)} caricata. ${counts}`);
  } catch (error) {
    if (read === weekRead) {
      const detail = error.code === 'CONNECTION'
        ? 'Impossibile caricare la settimana. Controlla che il server Svolta sia avviato.'
        : error.message;
      message('week-error', `${detail}${weekPlan ? ' Il piano mostrato potrebbe non essere aggiornato.' : ''} Usa Mostra settimana per riprovare.`);
    }
  } finally {
    if (read === weekRead) {
      byId('week-results').removeAttribute('aria-busy');
      byId('week-loading').hidden = true;
    }
  }
}

function refreshWeek() {
  if (weekRequested) void loadWeek();
}

function applyTaskToWeek(task) {
  if (weekPlan) {
    const replace = (records, date) => {
      const belongs = !task.archived && task.dueDate === date;
      const found = records.some(item => item.id === task.id);
      const updated = records.flatMap(item => item.id === task.id ? belongs ? [task] : [] : [item]);
      if (belongs && !found) updated.push(task);
      return updated;
    };
    weekPlan = {
      ...weekPlan,
      days: weekPlan.days.map(day => ({ ...day, tasks: replace(day.tasks, day.date) })),
      unscheduled: replace(weekPlan.unscheduled, null),
    };
    renderWeek();
  }
  // A read started before a successful write cannot restore the old deadline.
  refreshWeek();
}

async function loadProjects() {
  const read = ++projectRead;
  byId('projects-loading').hidden = false;
  byId('reload-projects').setAttribute('aria-disabled', 'true');
  message('projects-error');
  try {
    const records = await api('/api/projects');
    if (read !== projectRead) return;
    projects = records;
    projectsLoaded = true;
    projectsFailed = false;
    renderProjects();
  } catch (error) {
    if (read === projectRead) {
      projectsFailed = true;
      message('projects-error', `${error.message}${projectsLoaded ? ' L’elenco mostrato potrebbe non essere aggiornato.' : ''}`);
      showAvailability();
    }
  } finally {
    if (read === projectRead) {
      byId('projects-loading').hidden = true;
      byId('reload-projects').disabled = false;
      byId('reload-projects').removeAttribute('aria-disabled');
    }
  }
}

async function loadTasks() {
  const read = ++taskRead;
  tasksLoading = true;
  byId('task-list').setAttribute('aria-busy', 'true');
  byId('tasks-loading').hidden = false;
  byId('reload-tasks').setAttribute('aria-disabled', 'true');
  message('tasks-error');
  renderTasks();
  try {
    const query = new URLSearchParams();
    if (projectFilter.value) query.set('projectId', projectFilter.value);
    if (statusFilter.value) query.set('status', statusFilter.value);
    if (searchFilter.value) query.set('q', searchFilter.value);
    const records = await api(`/api/tasks${query.size ? `?${query}` : ''}`);
    if (read !== taskRead) return;
    tasks = records;
    tasksLoaded = true;
  } catch (error) {
    if (read === taskRead) message('tasks-error', `${error.message}${tasksLoaded ? ' L’elenco mostrato potrebbe non essere aggiornato.' : ''}`);
  } finally {
    if (read === taskRead) {
      tasksLoading = false;
      byId('task-list').removeAttribute('aria-busy');
      byId('tasks-loading').hidden = true;
      byId('reload-tasks').disabled = false;
      byId('reload-tasks').removeAttribute('aria-disabled');
      renderTasks();
      if (timeHistory.records !== null) renderTimeHistory(timeHistory);
    }
  }
}

function currentTimeHistory(history) {
  return history === timeHistory || (timeDialog.open && timeEditor?.history === history);
}

function syncTimeControls() {
  byId('time-fields').disabled = timeWritePending;
  for (const button of document.querySelectorAll('[data-time-control]')) button.disabled = timeWritePending;
  if (timeWritePending && timeDialog.open) timeForm.setAttribute('aria-busy', 'true');
  else timeForm.removeAttribute('aria-busy');
}

function renderTimeHistory(history) {
  if (!currentTimeHistory(history)) return;
  const { prefix, records } = history;
  const list = byId(`${prefix}-list`);
  const focusedAction = document.activeElement;
  const restoreFocus = focusedAction?.dataset.sessionAction && list.contains(focusedAction);
  const content = document.createDocumentFragment();
  // Dates are civil strings; do not parse them as UTC instants for display.
  const ordered = [...(records ?? [])].reverse().sort((a, b) => b.date.localeCompare(a.date));
  for (const entry of ordered) {
    const card = element('li', 'session-card');
    const date = element('time', 'session-date', formatCivilDate(entry.date));
    date.dateTime = entry.date;
    const detail = `${formatCivilDate(entry.date)}, ${entry.minutes} minuti`;
    card.append(date, element('p', '', `${entry.minutes} minuti`));
    if (!history.taskId) {
      const project = projects.find(item => item.id === entry.projectId);
      const task = tasks.find(item => item.id === entry.taskId)
        ?? weekPlan?.days.flatMap(day => day.tasks).find(item => item.id === entry.taskId)
        ?? weekPlan?.unscheduled.find(item => item.id === entry.taskId);
      card.append(element('p', 'task-project', `${project?.name ?? 'Progetto non caricato'}${project?.archived ? ' (archiviato)' : ''}`));
      card.append(element('p', 'task-project', task?.title ?? `Attività non presente negli elenchi · ID: ${entry.taskId}`));
    }
    card.append(element('p', 'session-note', entry.note || 'Nessuna nota.'));
    const actions = element('div', 'session-actions');
    const button = (label, action, handler) => {
      const control = element('button', 'subtle', label);
      control.type = 'button';
      control.dataset.timeControl = '';
      control.dataset.sessionId = entry.id;
      control.dataset.sessionAction = action;
      control.disabled = timeWritePending;
      control.setAttribute('aria-label', `${label} del ${detail}`);
      control.addEventListener('click', handler);
      actions.append(control);
      return control;
    };
    if (history.confirmId === entry.id) {
      card.append(element('p', 'session-confirm', `Eliminare la sessione del ${detail}? Verrà rimosso solo questo tempo; l’attività resta invariata. L’operazione non può essere annullata.`));
      button('Conferma eliminazione sessione', 'confirm', () => { void removeTimeEntry(history, entry); });
      button('Annulla eliminazione', 'cancel', () => {
        if (timeWritePending) return;
        history.confirmId = null;
        renderTimeHistory(history);
      });
    } else {
      button('Elimina sessione', 'delete', () => {
        if (timeWritePending) return;
        history.confirmId = entry.id;
        renderTimeHistory(history);
        const cancel = [...list.querySelectorAll('[data-session-action="cancel"]')]
          .find(control => control.dataset.sessionId === entry.id);
        cancel?.focus();
      });
    }
    card.append(actions);
    content.append(card);
  }
  list.replaceChildren(content);
  byId(`${prefix}-empty`).hidden = records === null || records.length > 0;
  if (restoreFocus) restoreActionFocus(list, focusedAction, 'session', byId(`${prefix}-reload`));
}

async function loadTimeHistory(history) {
  if (!currentTimeHistory(history)) return;
  const read = ++history.read;
  history.requested = true;
  const { prefix } = history;
  byId(`${prefix}-list`).setAttribute('aria-busy', 'true');
  byId(`${prefix}-loading`).hidden = false;
  message(`${prefix}-error`);
  try {
    const query = history.taskId ? `?${new URLSearchParams({ taskId: history.taskId })}` : '';
    const records = await api(`/api/time-entries${query}`);
    if (!currentTimeHistory(history) || read !== history.read) return;
    history.records = records;
    if (!records.some(entry => entry.id === history.confirmId)) history.confirmId = null;
    renderTimeHistory(history);
  } catch (error) {
    if (currentTimeHistory(history) && read === history.read) {
      message(`${prefix}-error`, `${error.message}${history.records !== null ? ' La cronologia mostrata potrebbe non essere aggiornata.' : ''} Usa ${history.taskId ? 'Aggiorna sessioni' : 'Aggiorna cronologia'} per riprovare; la bozza è conservata.`);
    }
  } finally {
    if (currentTimeHistory(history) && read === history.read) {
      byId(`${prefix}-list`).removeAttribute('aria-busy');
      byId(`${prefix}-loading`).hidden = true;
    }
  }
}

function renderSummary() {
  byId('summary-results').hidden = !summaryData;
  if (!summaryData) return;
  const { date, weekStart, weekEnd, totals, byProject } = summaryData;
  const datedText = (id, prefix, value) => {
    const time = element('time', '', formatCivilDate(value));
    time.dateTime = value;
    byId(id).replaceChildren(document.createTextNode(prefix), time);
  };
  datedText('summary-reference', 'Data di riferimento: ', date);
  datedText('summary-range', 'Dal ', weekStart);
  const end = element('time', '', formatCivilDate(weekEnd));
  end.dateTime = weekEnd;
  byId('summary-range').append(document.createTextNode(' al '), end);
  for (const key of ['todo', 'doing', 'done', 'overdue']) {
    byId(`summary-${key}`).textContent = totals[key];
  }
  byId('summary-minutes').textContent = `${totals.minutesThisWeek} minuti totali`;
  byId('summary-tasks-empty').hidden = totals.todo + totals.doing + totals.done > 0;
  byId('summary-time-empty').hidden = totals.minutesThisWeek > 0;
  byId('summary-projects-empty').hidden = byProject.length > 0;
  const list = document.createDocumentFragment();
  // Use the complete API projection, including archived projects and zeroes.
  // Never derive these values from the filtered activity list or the week plan.
  for (const project of byProject) {
    const card = element('li', 'summary-project');
    card.append(element('h4', '', project.name));
    card.append(element('p', '', `${project.minutesThisWeek} minuti nella settimana`));
    card.append(element('p', 'field-help', `Attività completate non archiviate in un progetto attivo: ${project.done}`));
    list.append(card);
  }
  byId('summary-project-list').replaceChildren(list);
}

async function loadSummary(date = summaryDate) {
  summaryRequested = true;
  summaryDate = date;
  const read = ++summaryRead;
  // Do not show the old interval or its counts under a newly submitted date.
  if (summaryData?.date !== date) {
    summaryData = null;
    renderSummary();
  }
  byId('summary-results').setAttribute('aria-busy', 'true');
  byId('summary-loading').hidden = false;
  message('summary-error');
  message('summary-results-status');
  try {
    const summary = await api(`/api/summary?${new URLSearchParams({ date })}`);
    if (read !== summaryRead) return;
    summaryData = summary;
    renderSummary();
    message('summary-results-status', `Riepilogo aggiornato al ${formatCivilDate(summary.date)}. Tempo dal ${formatCivilDate(summary.weekStart)} al ${formatCivilDate(summary.weekEnd)}: ${summary.totals.minutesThisWeek} minuti, incluso lo storico archiviato.`);
  } catch (error) {
    if (read === summaryRead) {
      message('summary-error', `${error.message}${summaryData ? ' Il riepilogo mostrato potrebbe non essere aggiornato.' : ''} Usa Aggiorna riepilogo per riprovare. La data nel campo è conservata.`);
    }
  } finally {
    if (read === summaryRead) {
      byId('summary-results').removeAttribute('aria-busy');
      byId('summary-loading').hidden = true;
    }
  }
}

function refreshSummary() {
  if (summaryRequested) void loadSummary();
}

function refreshTimeViews(savedEntry = null, removedId = null) {
  for (const history of [timeHistory, timeEditor?.history].filter(Boolean)) {
    if (!history.requested || !currentTimeHistory(history)) continue;
    // Invalidate older reads before reconciling the confirmed write locally.
    ++history.read;
    if (history.records !== null) {
      history.records = history.records.filter(entry => entry.id !== removedId && entry.id !== savedEntry?.id);
      if (savedEntry && (!history.taskId || savedEntry.taskId === history.taskId)) history.records.push(savedEntry);
      if (history.confirmId === removedId) history.confirmId = null;
      renderTimeHistory(history);
    }
    void loadTimeHistory(history);
  }
  refreshSummary();
}

function openTimeEditor(task) {
  if (timeDialog.open || timeWritePending) return;
  const origin = document.activeElement;
  timeEditor = {
    task: Object.freeze({ ...task }), origin,
    page: byId('settimana').contains(origin) ? 'settimana' : 'attivita',
    history: { prefix: 'task-time-history', taskId: task.id, records: null, read: 0, requested: false, confirmId: null },
  };
  timeForm.reset();
  clearInvalid(timeForm);
  for (const id of ['time-form-error', 'time-form-status', 'task-time-history-error', 'task-time-history-status']) message(id);
  byId('time-date').value = currentCivilDate();
  const project = projects.find(item => item.id === task.projectId);
  byId('time-dialog-context').textContent = `${task.title}\nProgetto: ${project?.name ?? 'Progetto non disponibile'}`;
  byId('time-dialog-close').textContent = 'Annulla';
  syncTimeControls();
  timeDialog.showModal();
  renderTimeHistory(timeEditor.history);
  byId('time-date').focus();
  void loadTimeHistory(timeEditor.history);
}

async function saveTimeEntry() {
  const editor = timeEditor;
  if (!editor || timeWritePending) return;
  clearInvalid(timeForm);
  message('time-form-error');
  message('time-form-status');
  const input = {
    taskId: editor.task.id, date: byId('time-date').value,
    minutes: byId('time-minutes').valueAsNumber, note: byId('time-note').value,
  };
  if (!input.date || !byId('time-date').validity.valid) {
    invalid(timeForm, byId('time-date'), 'Inserisci una data reale con anno da 0001 a 9999.');
    return;
  }
  if (!byId('time-minutes').validity.valid || !Number.isInteger(input.minutes) || input.minutes < 1 || input.minutes > 1440) {
    invalid(timeForm, byId('time-minutes'), 'Inserisci un numero intero di minuti da 1 a 1440.');
    return;
  }
  if ([...input.note].length > 2000) {
    invalid(timeForm, byId('time-note'), 'La nota sessione può contenere al massimo 2000 caratteri.');
    return;
  }
  timeWritePending = true;
  timePendingStatus = 'time-form-status';
  message('time-form-status', 'Salvataggio della sessione…');
  byId('time-form-status').focus({ preventScroll: true });
  syncTimeControls();
  try {
    const entry = await api('/api/time-entries', input);
    // Clear the draft only after a confirmed save. Refreshes never touch it.
    byId('time-minutes').value = '';
    byId('time-note').value = '';
    refreshTimeViews(entry);
    const notice = `Sessione del ${formatCivilDate(entry.date)} salvata per «${editor.task.title}»: ${entry.minutes} minuti.`;
    timeDialog.close();
    message(editor.page === 'settimana' ? 'week-updates-status' : 'task-updates-status', notice);
    message('time-history-status', notice);
  } catch (error) {
    message('time-form-status');
    message('time-form-error', `${error.message}${error.code === 'CONNECTION' ? ' Usa Aggiorna sessioni per controllare la cronologia prima di inviare di nuovo.' : ' Gli input sono conservati.'}`);
  } finally {
    timeWritePending = false;
    syncTimeControls();
    if (timeEditor === editor && timeDialog.open) {
      byId(byId('time-form-error').hidden ? 'time-form-status' : 'time-form-error').focus();
    }
  }
}

async function removeTimeEntry(history, entry) {
  if (!currentTimeHistory(history) || timeWritePending || history.confirmId !== entry.id) return;
  const { prefix } = history;
  timeWritePending = true;
  timePendingStatus = `${prefix}-status`;
  message(`${prefix}-error`);
  message(`${prefix}-status`, 'Eliminazione della sessione…');
  byId(`${prefix}-status`).focus({ preventScroll: true });
  syncTimeControls();
  try {
    await api(`/api/time-entries/${encodeURIComponent(entry.id)}`, undefined, 'DELETE');
    history.confirmId = null;
    refreshTimeViews(null, entry.id);
    const notice = `Sessione del ${formatCivilDate(entry.date)} eliminata: ${entry.minutes} minuti rimossi. L’attività è invariata.`;
    message(`${prefix}-status`, notice);
    if (prefix !== 'time-history') message('time-history-status', notice);
  } catch (error) {
    message(`${prefix}-status`);
    if (error.code === 'TIME_ENTRY_NOT_FOUND') {
      history.confirmId = null;
      refreshTimeViews(null, entry.id);
    }
    message(`${prefix}-error`, error.code === 'TIME_ENTRY_NOT_FOUND'
      ? 'La sessione non esiste più. La cronologia viene riletta; nessun’altra sessione è stata eliminata.' : error.message);
  } finally {
    timeWritePending = false;
    syncTimeControls();
    if (currentTimeHistory(history)) {
      byId(byId(`${prefix}-error`).hidden ? `${prefix}-reload` : `${prefix}-error`).focus();
    }
  }
}

timeForm.addEventListener('submit', event => {
  event.preventDefault();
  void saveTimeEntry();
});
byId('task-time-history-reload').addEventListener('click', () => {
  if (!timeWritePending && timeEditor) {
    void loadTimeHistory(timeEditor.history);
    refreshSummary();
  }
});
byId('time-history-reload').addEventListener('click', () => {
  if (timeWritePending) return;
  void loadTimeHistory(timeHistory);
  refreshSummary();
});
byId('time-dialog-close').addEventListener('click', () => { if (!timeWritePending) timeDialog.close(); });
timeDialog.addEventListener('cancel', event => {
  if (!timeWritePending) return;
  event.preventDefault();
  message(timePendingStatus, 'Operazione in corso. Attendi la risposta prima di chiudere; gli input restano conservati in caso di errore.');
  byId(timePendingStatus).focus();
});
timeDialog.addEventListener('close', () => {
  if (timeDialog.open) return;
  const editor = timeEditor;
  timeEditor = null;
  if (!editor) return;
  const container = byId(editor.page);
  if (editor.origin?.isConnected) editor.origin.focus();
  else {
    const replacement = [...container.querySelectorAll('[data-task-action="time"]')]
      .find(button => button.dataset.taskId === editor.task.id);
    (replacement ?? byId(`${editor.page}-heading`)).focus();
  }
});

function formErrorId(form) {
  if (form === projectEditForm) return 'project-edit-error';
  if (form === taskEditForm) return 'task-edit-error';
  if (form === timeForm) return 'time-form-error';
  return `${form === projectForm ? 'project' : 'task'}-form-error`;
}

function clearInvalid(form) {
  for (const field of form.querySelectorAll('[aria-invalid]')) {
    field.removeAttribute('aria-invalid');
    const help = field.getAttribute('aria-describedby')?.split(' ').filter(id => id !== formErrorId(form));
    if (help?.length) field.setAttribute('aria-describedby', help.join(' '));
    else field.removeAttribute('aria-describedby');
  }
}

function invalid(form, field, text) {
  const errorId = formErrorId(form);
  message(errorId, text);
  field.setAttribute('aria-invalid', 'true');
  field.setAttribute('aria-describedby', `${field.getAttribute('aria-describedby') ?? ''} ${errorId}`.trim());
  field.focus();
}

function readTaskInput(prefix) {
  return {
    title: byId(`${prefix}-title`).value,
    notes: byId(`${prefix}-notes`).value,
    dueDate: byId(`${prefix}-due`).value || null,
    estimateMinutes: byId(`${prefix}-estimate`).value === '' ? 0 : byId(`${prefix}-estimate`).valueAsNumber,
  };
}

function validateTaskInput(form, prefix, input) {
  // During conflict resolution only the fields explicitly chosen from the
  // draft will be sent. An invalid value kept solely in the draft must not
  // prevent choosing the valid current value instead.
  if (Object.hasOwn(input, 'title') && (!input.title.trim() || [...input.title.trim()].length > 160)) {
    invalid(form, byId(`${prefix}-title`), 'Inserisci un titolo da 1 a 160 caratteri, esclusi gli spazi ai bordi.');
    return false;
  }
  if (Object.hasOwn(input, 'notes') && [...input.notes].length > 4000) {
    invalid(form, byId(`${prefix}-notes`), 'Le note possono contenere al massimo 4000 caratteri.');
    return false;
  }
  if (Object.hasOwn(input, 'dueDate') && !byId(`${prefix}-due`).validity.valid) {
    invalid(form, byId(`${prefix}-due`), 'Inserisci una scadenza reale con anno da 0001 a 9999, oppure lascia il campo vuoto.');
    return false;
  }
  if (Object.hasOwn(input, 'estimateMinutes') && (byId(`${prefix}-estimate`).validity.badInput || !Number.isInteger(input.estimateMinutes) || input.estimateMinutes < 0 || input.estimateMinutes > 10080)) {
    invalid(form, byId(`${prefix}-estimate`), 'La stima deve essere un numero intero di minuti da 0 a 10080.');
    return false;
  }
  return true;
}

function applySavedTask(task) {
  ++taskRead; // Invalidate every list read that began before this write.
  const exists = tasks.some(item => item.id === task.id);
  tasks = (exists ? tasks.map(item => item.id === task.id ? task : item) : [...tasks, task])
    .filter(item => !item.archived);
  tasksLoaded = true;
  renderTasks();
  applyTaskToWeek(task);
  refreshSummary();
  if (timeHistory.records !== null) renderTimeHistory(timeHistory);
}

function openTaskEditor(task, action = 'edit') {
  if (taskDialog.open) return;
  // Neither a list refresh nor a save failure may replace this baseline or
  // populate the live inputs again. projectId is context, never an edit field.
  taskEditor = {
    original: Object.freeze({ ...task }), action, current: null, conflict: false,
    choices: {}, comparedDraft: null, pending: false, reading: false, origin: document.activeElement,
    page: byId('settimana').contains(document.activeElement) ? 'settimana' : 'attivita',
  };
  taskEditForm.reset();
  clearInvalid(taskEditForm);
  byId('task-edit-fields').disabled = false;
  byId('task-dialog-heading').textContent = action === 'edit' ? 'Modifica attività' : 'Archivia attività';
  byId('task-dialog-help').textContent = action === 'edit'
    ? 'Modifica i dettagli e lo stato. Il progetto resta invariato. Annulla o Escape scartano la bozza non salvata.'
    : 'Conferma l’archiviazione: l’attività scompare da tutti gli elenchi, ma resta salvata. La riattivazione delle singole attività è disponibile solo via API. Annulla lascia tutto invariato.';
  const projectName = projects.find(item => item.id === task.projectId)?.name ?? 'Progetto non disponibile';
  byId('task-edit-context').textContent = `${task.title}\nProgetto: ${projectName} · revisione ${task.revision}`;
  byId('task-edit-details').hidden = action !== 'edit';
  byId('task-edit-title').value = task.title;
  byId('task-edit-notes').value = task.notes;
  byId('task-edit-due').value = task.dueDate ?? '';
  byId('task-edit-estimate').value = String(task.estimateMinutes);
  byId('task-edit-state').value = task.status;
  byId('task-edit-save').textContent = action === 'edit' ? 'Salva modifiche' : 'Archivia attività';
  byId('task-edit-save').hidden = false;
  byId('task-read-current').disabled = false;
  byId('task-read-current').removeAttribute('aria-disabled');
  byId('task-retry').disabled = true;
  byId('task-conflict').hidden = true;
  byId('task-conflict').removeAttribute('aria-busy');
  byId('task-comparison').hidden = true;
  byId('task-comparison-details').replaceChildren();
  message('task-retry-help');
  message('task-edit-error');
  message('task-edit-status');
  taskDialog.showModal();
  byId(action === 'edit' ? 'task-edit-title' : 'task-edit-cancel').focus();
}

function readTaskDraft(editor) {
  return editor.action === 'edit'
    ? { ...readTaskInput('task-edit'), status: byId('task-edit-state').value, archived: editor.original.archived }
    : { ...editor.original, archived: true };
}

function taskResolutionFields(editor, draft) {
  return taskComparisonFields.filter(([field]) => !Object.is(draft[field], editor.original[field])
    && !Object.is(draft[field], editor.current[field]));
}

function taskComparisonValue(field, value) {
  if (field === 'status') return taskStates[value] ?? value;
  if (field === 'archived') return value ? 'Archiviata' : 'Non archiviata';
  if (field === 'estimateMinutes') return Number.isFinite(value) ? `${value} minuti` : 'Stima non valida: correggi il campo nel modulo.';
  if (field === 'dueDate') {
    if (!value) return 'Nessuna scadenza';
    const [year, month, day] = value.split('-');
    return `${day}/${month}/${year}`;
  }
  return value === '' ? '(campo vuoto)' : value;
}

function updateTaskRetry() {
  const editor = taskEditor;
  if (!editor?.current) return;
  const fields = taskResolutionFields(editor, readTaskDraft(editor));
  const missing = fields.filter(([field]) => !editor.choices[field]).length;
  const selected = fields.filter(([field]) => editor.choices[field] === 'draft').length;
  byId('task-retry').disabled = editor.pending || editor.reading || missing > 0 || selected === 0;
  message('task-retry-help', missing
    ? `Scegli quale valore usare per ${missing === 1 ? 'il campo rimanente' : `i ${missing} campi rimanenti`}.`
    : selected
      ? `Il salvataggio invierà solo ${selected === 1 ? 'il campo scelto' : `i ${selected} campi scelti`} dalla bozza, con la revisione ${editor.current.revision}. Gli altri valori correnti saranno conservati.`
      : 'Nessuna modifica da inviare: la versione corrente sarà conservata. Puoi continuare a modificare la bozza o scegliere Annulla per chiudere senza salvarla.');
}

function renderTaskComparison() {
  const editor = taskEditor;
  if (!editor?.current) return;
  const draft = readTaskDraft(editor);
  const choicesNeeded = new Set(taskResolutionFields(editor, draft).map(([field]) => field));
  const details = document.createDocumentFragment();
  for (const [field, label] of taskComparisonFields) {
    // A choice applies only to the exact draft value the person compared.
    // Editing another field does not discard unaffected decisions.
    if (!Object.is(editor.comparedDraft?.[field], draft[field]) || !choicesNeeded.has(field)) delete editor.choices[field];
    const comparison = element('section', 'field-comparison');
    const heading = element('h4', '', label);
    heading.id = `task-compare-${field}`;
    comparison.setAttribute('aria-labelledby', heading.id);
    const values = element('dl', 'comparison-details');
    for (const [version, record] of [['Versione aperta', editor.original], ['Versione corrente letta', editor.current], ['La tua bozza', draft]]) {
      const pair = element('div');
      pair.append(element('dt', '', version), element('dd', '', taskComparisonValue(field, record[field])));
      values.append(pair);
    }
    comparison.append(heading, values);
    if (choicesNeeded.has(field)) {
      const choiceId = `task-resolve-${field}`;
      const choiceLabel = element('label', '', `Quale valore usare per ${label}?`);
      choiceLabel.htmlFor = choiceId;
      const choice = element('select');
      choice.id = choiceId;
      choice.append(new Option('Scegli un valore…', ''), new Option('Mantieni versione corrente', 'current'), new Option('Applica la mia bozza', 'draft'));
      choice.value = editor.choices[field] ?? '';
      choice.addEventListener('change', () => {
        if (taskEditor !== editor || editor.pending || editor.reading) return;
        editor.choices[field] = choice.value;
        updateTaskRetry();
      });
      comparison.append(choiceLabel, choice);
    } else {
      comparison.append(element('p', 'field-help', Object.is(draft[field], editor.current[field])
        ? 'La bozza coincide con la versione corrente: nessuna modifica da inviare.'
        : 'Non hai modificato questo campo: sarà mantenuto il valore corrente.'));
    }
    details.append(comparison);
  }
  editor.comparedDraft = { ...draft };
  byId('task-comparison-context').textContent = `Versione aperta: revisione ${editor.original.revision}. Versione corrente letta: revisione ${editor.current.revision}. La revisione iniziale della bozza resta invariata.`;
  byId('task-comparison-details').replaceChildren(details);
  byId('task-retry').textContent = `${editor.action === 'edit' ? 'Applica le modifiche scelte' : 'Archivia'} alla revisione ${editor.current.revision}`;
  byId('task-comparison').hidden = false;
  updateTaskRetry();
}

async function readCurrentTask() {
  const editor = taskEditor;
  if (!editor?.conflict || editor.pending || editor.reading) return;
  editor.reading = true;
  editor.current = null;
  editor.choices = {};
  editor.comparedDraft = null;
  byId('task-comparison').hidden = true;
  byId('task-read-current').setAttribute('aria-disabled', 'true');
  const origin = document.activeElement;
  byId('task-conflict').setAttribute('aria-busy', 'true');
  message('task-edit-status', 'Lettura della versione corrente…');
  message('task-edit-error');
  try {
    // Ignore list filters and include the original project even if archived.
    // The public API excludes archived tasks: if absent, never guess a revision.
    const query = new URLSearchParams({ projectId: editor.original.projectId });
    const records = await api(`/api/tasks?${query}`);
    if (taskEditor !== editor || !taskDialog.open) return;
    const current = records.find(task => task.id === editor.original.id);
    if (!current) {
      message('task-edit-error', 'L’attività non è più consultabile: potrebbe essere stata archiviata in un’altra scheda. La versione corrente non è disponibile per il confronto. Tutti gli input restano nella bozza; puoi copiarli prima di annullare. Nessuna modifica sarà inviata senza una versione corrente da confrontare.');
      return;
    }
    // Reading a newer record never rebases the draft or rewrites its inputs.
    editor.current = Object.freeze({ ...current });
    renderTaskComparison();
    message('task-edit-status', 'Versione corrente letta. Confronta i campi e scegli esplicitamente le modifiche da applicare.');
  } catch (error) {
    if (taskEditor === editor && taskDialog.open) message('task-edit-error', `${error.message} La bozza è conservata.`);
  } finally {
    editor.reading = false;
    if (taskEditor === editor && taskDialog.open) {
      byId('task-read-current').removeAttribute('aria-disabled');
      byId('task-conflict').removeAttribute('aria-busy');
      if (!editor.current) message('task-edit-status');
      else updateTaskRetry();
      if (document.activeElement === origin) focusDialogError('task');
    }
  }
}

async function saveTask(useCurrent = false) {
  const editor = taskEditor;
  if (!editor || editor.pending || editor.reading || (editor.conflict && !useCurrent)) return;
  const base = useCurrent ? editor.current : editor.original;
  if (!base) return;
  clearInvalid(taskEditForm);
  message('task-edit-error');
  message('task-edit-status');
  const draft = readTaskDraft(editor);
  const input = { revision: base.revision };
  if (useCurrent) {
    const fields = taskResolutionFields(editor, draft);
    // Recheck choices at the point of sending, including their draft values.
    if (fields.some(([field]) => !editor.choices[field] || !Object.is(editor.comparedDraft?.[field], draft[field]))) {
      renderTaskComparison();
      message('task-edit-error', 'Scegli quale valore usare per ogni campo modificato prima di salvare.');
      return;
    }
    for (const [field] of fields) {
      if (editor.choices[field] === 'draft') input[field] = draft[field];
    }
    if (Object.keys(input).length === 1) {
      updateTaskRetry();
      return;
    }
  } else {
    for (const [field] of taskComparisonFields) {
      if (!Object.is(draft[field], editor.original[field])) input[field] = draft[field];
    }
  }
  if (editor.action === 'edit') {
    if (!validateTaskInput(taskEditForm, 'task-edit', useCurrent ? input : draft)) return;
    if ((!useCurrent || Object.hasOwn(input, 'status')) && !Object.hasOwn(taskStates, draft.status)) {
      invalid(taskEditForm, byId('task-edit-state'), 'Scegli uno stato: Da fare, In corso oppure Completata.');
      return;
    }
  }
  editor.pending = true;
  taskEditForm.setAttribute('aria-busy', 'true');
  message('task-edit-status', 'Salvataggio dell’attività…');
  byId('task-edit-status').focus({ preventScroll: true });
  byId('task-edit-fields').disabled = true;
  try {
    const task = await api(`/api/tasks/${encodeURIComponent(base.id)}`, input, 'PATCH');
    applySavedTask(task);
    message('task-updates-status', editor.action === 'edit'
      ? `Modifiche a «${task.title}» salvate. Se non appare nell’elenco, controlla i filtri selezionati.`
      : `Attività «${task.title}» archiviata. I dati restano salvati.`);
    if (weekRequested) message('week-updates-status', editor.action === 'edit'
      ? `Modifiche a «${task.title}» salvate. Le scadenze fuori dalla settimana non compaiono nel piano.`
      : `Attività «${task.title}» archiviata e rimossa dal piano. I dati restano salvati.`);
    editor.pending = false;
    taskDialog.close();
    void loadTasks();
  } catch (error) {
    message('task-edit-status');
    if (error.status === 409 && error.code !== 'REVISION_LIMIT') {
      editor.conflict = true;
      editor.current = null;
      editor.choices = {};
      editor.comparedDraft = null;
      byId('task-conflict').hidden = false;
      byId('task-comparison').hidden = true;
      byId('task-edit-save').hidden = true;
      message('task-edit-error', 'L’attività è stata modificata in un’altra scheda. La tua modifica non è stata salvata; tutti gli input e la revisione iniziale sono conservati. Leggi la versione corrente e scegli quali modifiche applicare prima di salvare di nuovo.');
      void loadTasks();
      refreshWeek();
    } else {
      message('task-edit-error', error.message);
    }
    if (error.code === 'TASK_NOT_FOUND') { void loadTasks(); refreshWeek(); }
  } finally {
    editor.pending = false;
    byId('task-edit-fields').disabled = false;
    taskEditForm.removeAttribute('aria-busy');
    if (taskEditor === editor && taskDialog.open) {
      if (editor.current) updateTaskRetry();
      focusDialogError('task');
    }
  }
}

taskEditForm.addEventListener('submit', event => {
  event.preventDefault();
  void saveTask();
});
byId('task-read-current').addEventListener('click', () => { void readCurrentTask(); });
byId('task-retry').addEventListener('click', () => { void saveTask(true); });
byId('task-edit-details').addEventListener('input', renderTaskComparison);
byId('task-edit-details').addEventListener('change', renderTaskComparison);
byId('task-edit-cancel').addEventListener('click', () => { if (!taskEditor?.pending) taskDialog.close(); });
taskDialog.addEventListener('cancel', event => {
  if (taskEditor?.pending) {
    event.preventDefault();
    message('task-edit-status', 'Salvataggio in corso. Attendi la risposta prima di chiudere; la bozza resta conservata in caso di errore.');
    byId('task-edit-status').focus();
  }
});
taskDialog.addEventListener('close', () => {
  if (taskDialog.open) return;
  const editor = taskEditor;
  taskEditor = null;
  if (!editor) return;
  const container = byId(editor.page);
  const buttons = [...container.querySelectorAll('[data-task-action]')];
  const target = editor.origin?.isConnected ? editor.origin
    : buttons.find(button => button.dataset.taskId === editor.original.id && button.dataset.taskAction === editor.action)
      ?? byId(`${editor.page}-heading`);
  target.focus();
});

function openProjectEditor(project, action) {
  if (projectDialog.open) return;
  // The revision belongs to the record read when opening, never to a later
  // background refresh. The actual draft stays in the input until success.
  projectEditor = { original: Object.freeze({ ...project }), action, current: null, conflict: false, pending: false, reading: false, origin: document.activeElement };
  projectEditForm.reset();
  clearInvalid(projectEditForm);
  byId('project-edit-fields').disabled = false;
  byId('project-dialog-heading').textContent = { rename: 'Rinomina progetto', archive: 'Archivia progetto', restore: 'Riattiva progetto' }[action];
  byId('project-dialog-help').textContent = {
    rename: 'Il nuovo nome apparirà anche sulle attività e nei selettori. Le attività restano nello stesso progetto.',
    archive: 'Il progetto e le sue attività restano salvati. Le attività scompaiono dalla vista generale; puoi consultarle con il filtro progetto. La bozza attività resta compilata, ma non potrà essere salvata qui finché il progetto è archiviato.',
    restore: 'Il progetto torna attivo: potrai aggiungere attività e quelle già presenti torneranno nella vista generale.',
  }[action];
  byId('project-edit-context').textContent = `${project.name} · ${project.archived ? 'Archiviato' : 'Attivo'} · revisione ${project.revision}`;
  byId('project-edit-name-field').hidden = action !== 'rename';
  byId('project-edit-name').disabled = action !== 'rename';
  byId('project-edit-name').value = project.name;
  byId('project-edit-save').textContent = { rename: 'Salva nome', archive: 'Archivia progetto', restore: 'Riattiva progetto' }[action];
  byId('project-edit-save').hidden = false;
  byId('project-edit-cancel').textContent = 'Annulla';
  byId('project-read-current').disabled = false;
  byId('project-read-current').removeAttribute('aria-disabled');
  byId('project-conflict').hidden = true;
  byId('project-comparison').hidden = true;
  message('project-edit-error');
  message('project-edit-status');
  projectDialog.showModal();
  byId(action === 'rename' ? 'project-edit-name' : 'project-edit-cancel').focus();
}

function renderProjectComparison() {
  const editor = projectEditor;
  if (!editor?.current) return;
  const details = document.createDocumentFragment();
  for (const [label, project] of [['Versione aperta', editor.original], ['Versione corrente letta', editor.current]]) {
    const pair = element('div');
    pair.append(element('dt', '', `${label} · revisione ${project.revision}`),
      element('dd', '', `${project.name}\n${project.archived ? 'Archiviato' : 'Attivo'}`));
    details.append(pair);
  }
  const draft = element('div');
  draft.append(element('dt', '', 'La tua modifica'), element('dd', '', editor.action === 'rename'
    ? byId('project-edit-name').value
    : editor.action === 'archive' ? 'Archivia il progetto' : 'Riattiva il progetto'));
  details.append(draft);
  byId('project-comparison-details').replaceChildren(details);
  byId('project-retry-help').textContent = editor.action === 'rename'
    ? 'Conferma esplicitamente la tua rinomina sulla versione corrente letta. Lo stato attivo o archiviato di quella versione sarà conservato. Puoi ancora correggere il nome qui sopra.'
    : 'Conferma esplicitamente l’operazione sulla versione corrente letta. Il nome di quella versione sarà conservato.';
  byId('project-retry').textContent = `${{ rename: 'Applica la rinomina', archive: 'Archivia', restore: 'Riattiva' }[editor.action]} alla revisione ${editor.current.revision}`;
  byId('project-comparison').hidden = false;
}

async function readCurrentProject() {
  const editor = projectEditor;
  if (!editor || editor.pending || editor.reading) return;
  editor.reading = true;
  editor.current = null;
  byId('project-comparison').hidden = true;
  byId('project-read-current').setAttribute('aria-disabled', 'true');
  const origin = document.activeElement;
  message('project-edit-status', 'Lettura della versione corrente…');
  message('project-edit-error');
  try {
    const records = await api('/api/projects');
    if (projectEditor !== editor) return;
    const current = records.find(project => project.id === editor.original.id);
    if (!current) {
      message('project-edit-error', 'Il progetto non è più disponibile. La bozza resta aperta; puoi copiarne il nome prima di chiudere.');
      return;
    }
    // This snapshot is only used by the explicit retry button. It never
    // changes the original revision or any live form value.
    editor.current = Object.freeze({ ...current });
    renderProjectComparison();
    message('project-edit-status', 'Versione corrente letta. Confronta i dati e scegli se applicare la tua modifica.');
  } catch (error) {
    if (projectEditor === editor) message('project-edit-error', error.message);
  } finally {
    editor.reading = false;
    if (projectEditor === editor) {
      byId('project-read-current').removeAttribute('aria-disabled');
      if (!editor.current) message('project-edit-status');
      if (document.activeElement === origin) focusDialogError('project');
    }
  }
}

async function saveProject(useCurrent = false) {
  const editor = projectEditor;
  if (!editor || editor.pending || editor.reading || (editor.conflict && !useCurrent)) return;
  const base = useCurrent ? editor.current : editor.original;
  if (!base) return;
  clearInvalid(projectEditForm);
  message('project-edit-error');
  message('project-edit-status');
  const input = { revision: base.revision };
  if (editor.action === 'rename') {
    input.name = byId('project-edit-name').value;
    if (!input.name.trim() || [...input.name.trim()].length > 100) {
      invalid(projectEditForm, byId('project-edit-name'), 'Inserisci un nome da 1 a 100 caratteri, esclusi gli spazi ai bordi.');
      return;
    }
  } else input.archived = editor.action === 'archive';
  editor.pending = true;
  projectEditForm.setAttribute('aria-busy', 'true');
  message('project-edit-status', 'Salvataggio della modifica…');
  byId('project-edit-status').focus({ preventScroll: true });
  byId('project-edit-fields').disabled = true;
  try {
    const project = await api(`/api/projects/${encodeURIComponent(base.id)}`, input, 'PATCH');
    ++projectRead;
    projects = projects.map(item => item.id === project.id ? project : item);
    projectsLoaded = true;
    projectsFailed = false;
    renderProjects();
    refreshWeek();
    refreshSummary();
    message('project-updates-status', `${{ rename: 'Nome aggiornato', archive: 'Progetto archiviato', restore: 'Progetto riattivato' }[editor.action]}: «${project.name}».`);
    editor.pending = false;
    projectDialog.close();
    void loadProjects();
    void loadTasks();
  } catch (error) {
    message('project-edit-status');
    if (error.code === 'REVISION_CONFLICT') {
      editor.conflict = true;
      editor.current = null;
      byId('project-conflict').hidden = false;
      byId('project-comparison').hidden = true;
      byId('project-edit-save').hidden = true;
      message('project-edit-error', 'Il progetto è stato modificato in un’altra scheda. La tua modifica non è stata salvata e gli input sono conservati. Leggi la versione corrente e confrontala prima di confermare di nuovo.');
      void loadProjects();
      void loadTasks();
      refreshWeek();
    } else {
      message('project-edit-error', error.message);
    }
    if (error.code === 'PROJECT_NOT_FOUND') void loadProjects();
  } finally {
    editor.pending = false;
    byId('project-edit-fields').disabled = false;
    projectEditForm.removeAttribute('aria-busy');
    if (projectEditor === editor && projectDialog.open) {
      focusDialogError('project');
    }
  }
}

projectEditForm.addEventListener('submit', event => {
  event.preventDefault();
  void saveProject();
});
byId('project-read-current').addEventListener('click', () => { void readCurrentProject(); });
byId('project-retry').addEventListener('click', () => { void saveProject(true); });
byId('project-edit-name').addEventListener('input', renderProjectComparison);
byId('project-edit-cancel').addEventListener('click', () => { if (!projectEditor?.pending) projectDialog.close(); });
projectDialog.addEventListener('cancel', event => {
  if (projectEditor?.pending) {
    event.preventDefault();
    message('project-edit-status', 'Salvataggio in corso. Attendi la risposta prima di chiudere; la bozza resta conservata in caso di errore.');
    byId('project-edit-status').focus();
  }
});
projectDialog.addEventListener('close', () => {
  if (projectDialog.open) return;
  const editor = projectEditor;
  projectEditor = null;
  if (!editor) return;
  const buttons = [...document.querySelectorAll('[data-project-action]')];
  const focusTarget = editor.origin?.isConnected ? editor.origin
    : buttons.find(button => button.dataset.projectId === editor.original.id && button.dataset.projectAction === editor.action)
      ?? buttons.find(button => button.dataset.projectId === editor.original.id)
      ?? byId('progetti-heading');
  focusTarget.focus();
});

// Mirror the version-1 stored-record contract before enabling a destructive
// request. The server remains authoritative and validates the whole graph again.
function validateBackupFile(data) {
  const fail = detail => { throw new Error(`Backup non valido: ${detail}`); };
  const fields = (record, names, label) => {
    if (!record || typeof record !== 'object' || Array.isArray(record)
        || Object.keys(record).length !== names.length
        || names.some(name => !Object.hasOwn(record, name))) fail(`campi di ${label} non riconosciuti o mancanti.`);
  };
  const identifier = value => typeof value === 'string' && value.length > 0 && value.trim() === value;
  const revision = value => Number.isSafeInteger(value) && value >= 1;
  const normalizedText = (value, limit) => typeof value === 'string'
    && value.length > 0 && value.trim() === value && [...value].length <= limit;
  const text = (value, limit) => typeof value === 'string' && [...value].length <= limit;
  const integer = (value, min, max) => Number.isInteger(value) && value >= min && value <= max;
  const date = value => {
    if (typeof value !== 'string' || value.length !== 10 || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
    const [year, month, day] = value.split('-').map(Number);
    const leap = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
    return year >= 1 && month >= 1 && month <= 12 && day >= 1
      && day <= [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1];
  };
  fields(data, ['format', 'version', 'projects', 'tasks', 'timeEntries'], 'backup');
  if (data.format !== 'svolta' || data.version !== 1) fail('occorre il formato svolta, versione 1.');
  if (![data.projects, data.tasks, data.timeEntries].every(Array.isArray)) fail('progetti, attività e sessioni devono essere elenchi.');
  const projectIds = new Set();
  for (const project of data.projects) {
    fields(project, ['id', 'name', 'archived', 'revision'], 'un progetto');
    if (!identifier(project.id) || !normalizedText(project.name, 100)
        || typeof project.archived !== 'boolean' || !revision(project.revision)) fail('dati di un progetto non validi.');
    if (projectIds.has(project.id)) fail('identificativi di progetto duplicati.');
    projectIds.add(project.id);
  }
  const taskProjects = new Map();
  for (const task of data.tasks) {
    fields(task, ['id', 'projectId', 'title', 'notes', 'status', 'dueDate', 'estimateMinutes', 'archived', 'revision'], 'un’attività');
    if (!identifier(task.id) || !identifier(task.projectId) || !normalizedText(task.title, 160)
        || !text(task.notes, 4000) || typeof task.status !== 'string' || !Object.hasOwn(taskStates, task.status)
        || (task.dueDate !== null && !date(task.dueDate)) || !integer(task.estimateMinutes, 0, 10080)
        || typeof task.archived !== 'boolean' || !revision(task.revision)) fail('dati di un’attività non validi.');
    if (taskProjects.has(task.id)) fail('identificativi di attività duplicati.');
    if (!projectIds.has(task.projectId)) fail('un’attività fa riferimento a un progetto assente.');
    taskProjects.set(task.id, task.projectId);
  }
  const sessionIds = new Set();
  for (const entry of data.timeEntries) {
    fields(entry, ['id', 'taskId', 'projectId', 'date', 'minutes', 'note'], 'una sessione');
    if (!identifier(entry.id) || !identifier(entry.taskId) || !identifier(entry.projectId)
        || !date(entry.date) || !integer(entry.minutes, 1, 1440) || !text(entry.note, 2000)) fail('dati di una sessione non validi.');
    if (sessionIds.has(entry.id)) fail('identificativi di sessione duplicati.');
    if (!taskProjects.has(entry.taskId) || taskProjects.get(entry.taskId) !== entry.projectId) fail('riferimenti di una sessione incoerenti.');
    sessionIds.add(entry.id);
  }
}

function syncBackupControls() {
  byId('backup-fields').disabled = backupRestoring;
  byId('download-backup').disabled = backupDownloading || backupRestoring || pendingWrites > 0;
  byId('restore-backup').disabled = !backupCandidate || backupFileLoading || !backupConsent.checked
    || backupRestoring || pendingWrites > 0;
  byId('backup-restore-help').textContent = backupRestoring
    ? 'Attendi la risposta del server prima di usare le altre sezioni.'
    : pendingWrites > 0 ? 'Attendi il salvataggio in corso prima di ripristinare.'
      : backupFileLoading ? 'Controllo del file in corso…'
        : !backupCandidate ? 'Scegli un file valido e seleziona il consenso per abilitare il ripristino.'
          : !backupConsent.checked ? 'File valido. Seleziona il consenso alla sostituzione per continuare.'
            : 'Il prossimo invio sostituirà tutti i dati correnti con quelli del file.';
}

async function readBackupFile() {
  if (backupRestoring) return;
  const read = ++backupFileRead;
  backupCandidate = null;
  backupConsent.checked = false;
  backupFileLoading = false;
  backupFileInput.removeAttribute('aria-invalid');
  for (const id of ['backup-error', 'backup-status', 'backup-file-status']) message(id);
  const file = backupFileInput.files[0];
  syncBackupControls();
  if (!file) return;
  backupFileLoading = true;
  message('backup-file-status', 'Controllo del file in corso…');
  syncBackupControls();
  try {
    if (file.size > maxBackupBytes) throw new Error('Il file supera il limite di 2 MiB.');
    let data;
    try {
      const source = await file.arrayBuffer();
      if (read !== backupFileRead) return;
      data = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(source));
    } catch {
      throw new Error('Il file non contiene un JSON UTF-8 valido. Scegli un backup scaricato da Svolta.');
    }
    validateBackupFile(data);
    if (new Blob([JSON.stringify(data)]).size > maxBackupBytes) throw new Error('I dati da inviare superano il limite di 2 MiB.');
    if (read !== backupFileRead) return;
    backupCandidate = { file, data };
    message('backup-file-status', `File valido: ${data.projects.length} progetti, ${data.tasks.length} attività e ${data.timeEntries.length} sessioni, inclusi gli archivi. Nessun dato è stato inviato.`);
  } catch (error) {
    if (read !== backupFileRead) return;
    message('backup-file-status');
    message('backup-error', error.message);
    backupFileInput.setAttribute('aria-invalid', 'true');
  } finally {
    if (read === backupFileRead) {
      backupFileLoading = false;
      syncBackupControls();
    }
  }
}

function lockForRestore(locked) {
  for (const button of document.querySelectorAll('nav [data-page]')) button.disabled = locked;
  for (const page of ['progetti', 'attivita', 'settimana', 'riepilogo']) byId(page).inert = locked;
  if (locked) restoreForm.setAttribute('aria-busy', 'true');
  else restoreForm.removeAttribute('aria-busy');
  syncBackupControls();
}

async function reloadRestoredArchive() {
  // Invalidate even reads that finish after the new archive has loaded. Dialog
  // readers also compare their editor object, which is now deliberately lost.
  ++projectRead; ++taskRead; ++weekRead; ++summaryRead; ++timeHistory.read;
  if (timeEditor) ++timeEditor.history.read;
  clearTimeout(returnRefresh);
  projectEditor = null; taskEditor = null; timeEditor = null;
  for (const dialog of [projectDialog, taskDialog, timeDialog]) if (dialog.open) dialog.close();
  for (const form of [projectForm, taskForm, projectEditForm, taskEditForm, timeForm, weekForm, summaryForm]) {
    form.reset();
    clearInvalid(form);
    form.removeAttribute('aria-busy');
  }
  weekStartInput.removeAttribute('aria-invalid');
  weekStartInput.setAttribute('aria-describedby', 'week-start-help');
  summaryDateInput.removeAttribute('aria-invalid');
  summaryDateInput.setAttribute('aria-describedby', 'summary-date-help');
  projectSelect.value = ''; projectFilter.value = ''; statusFilter.value = ''; searchFilter.value = '';
  projects = []; tasks = []; projectsLoaded = false; projectsFailed = false; tasksLoaded = false;
  tasksLoading = false;
  weekPlan = null; weekStart = currentMonday(); weekStartInput.value = weekStart;
  summaryData = null; summaryDate = currentCivilDate(); summaryDateInput.value = summaryDate;
  timeHistory.records = null; timeHistory.confirmId = null;
  for (const node of document.querySelectorAll('[role="alert"], [role="status"]')) {
    if (byId('backup').contains(node) || node.id.endsWith('-loading')) continue;
    node.textContent = ''; node.hidden = true;
  }
  for (const id of ['project-comparison-details', 'task-comparison-details', 'task-time-history-list', 'summary-project-list']) byId(id).replaceChildren();
  for (const id of ['project-edit-context', 'task-edit-context', 'time-dialog-context', 'week-range', 'summary-reference', 'summary-range', 'summary-minutes', 'summary-todo', 'summary-doing', 'summary-done', 'summary-overdue']) byId(id).textContent = '';
  for (const id of ['project-conflict', 'task-conflict', 'project-comparison', 'task-comparison', 'task-time-history-loading']) byId(id).hidden = true;
  renderProjects(); renderWeek(); renderSummary(); renderTimeHistory(timeHistory);
  // Refresh every view, including those never opened, without a page reload.
  await Promise.all([loadProjects(), loadTasks(), loadWeek(), loadTimeHistory(timeHistory), loadSummary()]);
}

async function restoreSelectedBackup() {
  // Recheck at submission, so Enter or a dispatched submit cannot bypass the
  // disabled button or send a stale selection while a different file is read.
  if (backupRestoring || pendingWrites > 0 || backupFileLoading || !backupCandidate
      || !backupConsent.checked || backupFileInput.files[0] !== backupCandidate.file) return;
  const candidate = backupCandidate;
  try { validateBackupFile(candidate.data); }
  catch (error) {
    backupCandidate = null;
    message('backup-error', error.message);
    syncBackupControls();
    return;
  }
  backupRestoring = true;
  message('backup-error');
  message('backup-status', 'Sostituzione dei dati in corso…');
  byId('backup-status').focus({ preventScroll: true });
  lockForRestore(true);
  try {
    const result = await api('/api/restore', candidate.data);
    if (result?.restored !== true) throw new RequestError('Risposta di ripristino non riconosciuta.', 'CONNECTION');
    await reloadRestoredArchive();
    backupCandidate = null; ++backupFileRead;
    restoreForm.reset();
    message('backup-file-status');
    message('backup-status', 'Backup ripristinato. I dati correnti sono stati sostituiti; bozze, editor e filtri precedenti sono stati azzerati. Progetti, attività, settimana, cronologia e riepilogo sono stati riletti. Se una vista segnala un errore di caricamento, usa il suo comando Aggiorna per riprovare.');
  } catch (error) {
    message('backup-status');
    if (error.code === 'CONNECTION') {
      // A lost response can follow a successful replacement. Discard old
      // baselines even in this ambiguous case; never retry a restore silently.
      await reloadRestoredArchive();
      message('backup-error', 'Impossibile confermare il ripristino: i dati potrebbero essere già stati sostituiti. Le viste sono state rilette e le bozze azzerate. Controlla i dati, eventualmente con Scarica backup, prima di dare nuovamente il consenso. Nessun tentativo automatico.');
    } else message('backup-error', `${error.message} Il ripristino non è stato applicato; i dati e le bozze correnti sono conservati.`);
  } finally {
    backupConsent.checked = false;
    backupRestoring = false;
    lockForRestore(false);
    byId(byId('backup-error').hidden ? 'backup-status' : 'backup-error').focus({ preventScroll: true });
  }
}

byId('download-backup').addEventListener('click', async () => {
  if (backupDownloading || backupRestoring || pendingWrites > 0) return;
  backupDownloading = true;
  message('backup-download-error');
  message('backup-download-status', 'Preparazione del file…');
  syncBackupControls();
  try {
    const data = await api('/api/backup');
    const url = URL.createObjectURL(new Blob([JSON.stringify(data)], { type: 'application/json' }));
    const link = element('a');
    link.href = url; link.download = `svolta-backup-${currentCivilDate()}.json`;
    document.body.append(link); link.click(); link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    message('backup-download-status', 'Backup preparato. Controlla i download del browser e conserva il file JSON.');
  } catch (error) {
    message('backup-download-status');
    message('backup-download-error', error.message);
    byId('backup-download-error').focus();
  } finally {
    backupDownloading = false;
    syncBackupControls();
  }
});
backupFileInput.addEventListener('change', () => { void readBackupFile(); });
backupConsent.addEventListener('change', syncBackupControls);
restoreForm.addEventListener('submit', event => { event.preventDefault(); void restoreSelectedBackup(); });

projectForm.addEventListener('submit', async event => {
  event.preventDefault();
  if (creatingProject) return;
  message('project-form-error');
  message('project-form-status');
  clearInvalid(projectForm);
  const name = byId('project-name').value;
  if (!name.trim() || [...name.trim()].length > 100) {
    invalid(projectForm, byId('project-name'), 'Inserisci un nome da 1 a 100 caratteri, esclusi gli spazi ai bordi.');
    return;
  }
  creatingProject = true;
  projectForm.setAttribute('aria-busy', 'true');
  message('project-form-status', 'Salvataggio del progetto…');
  const progress = byId('project-form-status');
  if (projectForm.contains(document.activeElement)) progress.focus({ preventScroll: true });
  byId('project-fields').disabled = true;
  try {
    const project = await api('/api/projects', { name });
    ++projectRead; // A read started before the save must not hide its result.
    projects = [...projects.filter(item => item.id !== project.id), project];
    projectsLoaded = true;
    renderProjects();
    refreshSummary();
    if (!projectSelect.value) {
      projectSelect.value = project.id;
      showAvailability();
    }
    projectForm.reset();
    message('project-form-status', `Progetto «${project.name}» creato. Puoi aggiungere la prima attività.`);
    void loadProjects();
  } catch (error) {
    const ownsFocus = document.activeElement === progress;
    message('project-form-status');
    message('project-form-error', error.message);
    if (ownsFocus) byId('project-form-error').focus();
  } finally {
    creatingProject = false;
    byId('project-fields').disabled = false;
    projectForm.removeAttribute('aria-busy');
    if (document.activeElement === progress && !progress.hidden) byId('project-name').focus({ preventScroll: true });
  }
});

taskForm.addEventListener('submit', async event => {
  event.preventDefault();
  if (creatingTask) return;
  message('task-form-error');
  message('task-form-status');
  clearInvalid(taskForm);
  const input = { projectId: projectSelect.value, ...readTaskInput('task') };
  if (!projectsLoaded || !projects.some(item => item.id === input.projectId && !item.archived)) {
    invalid(taskForm, projectSelect, 'Scegli un progetto attivo. Se manca, crealo o aggiorna l’elenco in Progetti. Gli altri input sono conservati.');
    return;
  }
  if (!validateTaskInput(taskForm, 'task', input)) return;
  creatingTask = true;
  taskForm.setAttribute('aria-busy', 'true');
  message('task-form-status', 'Salvataggio dell’attività…');
  const progress = byId('task-form-status');
  if (taskForm.contains(document.activeElement)) progress.focus({ preventScroll: true });
  byId('task-fields').disabled = true;
  try {
    const task = await api('/api/tasks', input);
    applySavedTask(task);
    taskForm.reset();
    projectSelect.value = input.projectId;
    showAvailability();
    message('task-form-status', `Attività «${task.title}» creata e salvata.`);
    void loadTasks();
  } catch (error) {
    const ownsFocus = document.activeElement === progress;
    message('task-form-status');
    message('task-form-error', error.message);
    if (ownsFocus) byId('task-form-error').focus();
    if (error.code === 'PROJECT_ARCHIVED' || error.code === 'PROJECT_NOT_FOUND') void loadProjects();
  } finally {
    creatingTask = false;
    byId('task-fields').disabled = false;
    taskForm.removeAttribute('aria-busy');
    if (document.activeElement === progress && !progress.hidden) byId('task-title').focus({ preventScroll: true });
  }
});

for (const button of document.querySelectorAll('nav [data-page]')) {
  button.addEventListener('click', () => navigate(button.dataset.page));
}
weekStartInput.value = weekStart;
weekForm.addEventListener('submit', event => {
  event.preventDefault();
  message('week-form-error');
  message('week-updates-status');
  weekStartInput.removeAttribute('aria-invalid');
  weekStartInput.setAttribute('aria-describedby', 'week-start-help');
  if (!weekStartInput.value || !weekStartInput.validity.valid) {
    message('week-form-error', 'Inserisci un lunedì reale con anno da 0001 a 9999, poi usa Mostra settimana.');
    weekStartInput.setAttribute('aria-invalid', 'true');
    weekStartInput.setAttribute('aria-describedby', 'week-start-help week-form-error');
    weekStartInput.focus();
    return;
  }
  // The API validates Monday and calendar limits. No silent date adjustment.
  void loadWeek(weekStartInput.value);
});
summaryDateInput.value = summaryDate;
summaryForm.addEventListener('submit', event => {
  event.preventDefault();
  message('summary-form-error');
  summaryDateInput.removeAttribute('aria-invalid');
  summaryDateInput.setAttribute('aria-describedby', 'summary-date-help');
  if (!summaryDateInput.value || !summaryDateInput.validity.valid) {
    message('summary-form-error', 'Inserisci una data di riferimento reale con anno da 0001 a 9999, poi usa Aggiorna riepilogo.');
    summaryDateInput.setAttribute('aria-invalid', 'true');
    summaryDateInput.setAttribute('aria-describedby', 'summary-date-help summary-form-error');
    summaryDateInput.focus();
    return;
  }
  // Calendar boundaries and the included week are validated by the API.
  void loadSummary(summaryDateInput.value);
});
byId('go-to-projects').addEventListener('click', () => navigate('progetti'));
projectSelect.addEventListener('change', showAvailability);
function changeTaskFilters() {
  // Clearing the old result immediately avoids presenting results for a
  // previous query as the new one. loadTasks owns a monotonically newer read.
  tasks = [];
  tasksLoaded = false;
  renderProjectFilter();
  void loadTasks();
}
projectFilter.addEventListener('change', changeTaskFilters);
statusFilter.addEventListener('change', changeTaskFilters);
searchFilter.addEventListener('input', changeTaskFilters);
byId('reset-task-filters').addEventListener('click', () => {
  projectFilter.value = '';
  statusFilter.value = '';
  searchFilter.value = '';
  changeTaskFilters();
});
byId('reload-projects').addEventListener('click', () => {
  if (byId('reload-projects').getAttribute('aria-disabled') === 'true') return;
  void loadProjects(); void loadTasks(); refreshWeek();
  refreshSummary();
});
byId('reload-tasks').addEventListener('click', () => {
  if (byId('reload-tasks').getAttribute('aria-disabled') === 'true') return;
  void loadTasks(); void loadProjects(); refreshWeek();
  refreshSummary();
});
// A returning tab refreshes saved records, never an editor's baseline or draft.
let returnRefresh;
function refreshOnReturn() {
  if (document.hidden || backupRestoring) return;
  clearTimeout(returnRefresh);
  returnRefresh = setTimeout(() => {
    if (backupRestoring) return;
    void loadProjects(); void loadTasks(); refreshWeek();
    if (timeHistory.requested) void loadTimeHistory(timeHistory);
    if (timeEditor) void loadTimeHistory(timeEditor.history);
    refreshSummary();
  }, 100);
}
window.addEventListener('focus', refreshOnReturn);
document.addEventListener('visibilitychange', refreshOnReturn);
byId('project-fields').disabled = false;
byId('task-fields').disabled = false;
syncBackupControls();
void loadProjects();
void loadTasks();
