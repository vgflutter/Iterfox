import { randomUUID } from 'node:crypto';
import { lstat, mkdir, open, readFile, rename, unlink } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { AppError } from './errors.mjs';
import { validateStoredProject } from './projects.mjs';
import { validateStoredTask } from './tasks.mjs';
import { validateStoredTimeEntry } from './time-entries.mjs';

export function validateArchive(archive) {
  if (archive === null || typeof archive !== 'object' || Array.isArray(archive)
      || archive.version !== 1 || !Array.isArray(archive.projects) || !Array.isArray(archive.tasks)
      || !Array.isArray(archive.timeEntries)
      || Object.keys(archive).some(key => !['version', 'projects', 'tasks', 'timeEntries'].includes(key))) {
    throw new Error('Formato dell’archivio non riconosciuto.');
  }
  const ids = new Set();
  for (const project of archive.projects) {
    validateStoredProject(project);
    if (ids.has(project.id)) throw new Error('Identificativi di progetto duplicati.');
    ids.add(project.id);
  }
  const tasksById = new Map();
  for (const task of archive.tasks) {
    validateStoredTask(task);
    if (tasksById.has(task.id)) throw new Error('Identificativi di attività duplicati.');
    if (!ids.has(task.projectId)) throw new Error('Attività con riferimento a un progetto inesistente.');
    tasksById.set(task.id, task);
  }
  const entryIds = new Set();
  for (const entry of archive.timeEntries) {
    validateStoredTimeEntry(entry);
    if (entryIds.has(entry.id)) throw new Error('Identificativi di sessione duplicati.');
    const task = tasksById.get(entry.taskId);
    if (!task) throw new Error('Sessione con riferimento a un’attività inesistente.');
    if (task.projectId !== entry.projectId) {
      throw new Error('Il progetto della sessione non corrisponde a quello dell’attività.');
    }
    entryIds.add(entry.id);
  }
}

async function writeAtomic(directory, archive) {
  // Same filesystem: readers see either the previous file or the complete new file.
  const temporary = join(directory, `.archive-${randomUUID()}.tmp`);
  let handle;
  let created = false;
  try {
    handle = await open(temporary, 'wx', 0o600);
    created = true;
    await handle.writeFile(`${JSON.stringify(archive)}\n`, 'utf8');
    await handle.sync();
    await handle.close();
    handle = undefined;
    await rename(temporary, join(directory, 'archive.json'));
    // Nothing fallible after rename: the caller can now publish the new state.
  } catch (error) {
    if (handle) await handle.close().catch(() => {});
    if (created) await unlink(temporary).catch(() => {});
    throw error;
  }
}

export class Archive {
  #directory;
  #data;
  #pending = Promise.resolve();

  constructor(directory, data) {
    this.#directory = directory;
    this.#data = data;
  }

  static async open(directory) {
    const absolute = resolve(directory);
    await mkdir(absolute, { recursive: true, mode: 0o700 });
    const file = join(absolute, 'archive.json');
    let source;
    let exists = false;
    try {
      const info = await lstat(file);
      exists = true;
      if (!info.isFile()) throw new Error('archive.json deve essere un file regolare, non un collegamento o una cartella.');
      source = await readFile(file);
    } catch (cause) {
      if (exists || cause.code !== 'ENOENT') {
        throw new Error(`Impossibile leggere l’archivio ${file}. Nessun dato è stato sostituito.`, { cause });
      }
    }

    let data;
    if (source === undefined) {
      data = { version: 1, projects: [], tasks: [], timeEntries: [] };
      await writeAtomic(absolute, data);
    } else {
      try {
        const text = new TextDecoder('utf-8', { fatal: true }).decode(source);
        data = JSON.parse(text);
        // The projects-only version used the same format without a tasks key.
        // Upgrade in memory; opening an archive never overwrites its contents.
        if (data !== null && typeof data === 'object' && !Array.isArray(data)
            && data.version === 1 && !Object.hasOwn(data, 'tasks')) data.tasks = [];
        if (data !== null && typeof data === 'object' && !Array.isArray(data)
            && data.version === 1 && !Object.hasOwn(data, 'timeEntries')) data.timeEntries = [];
        validateArchive(data);
      } catch (cause) {
        throw new Error(`L’archivio ${file} è illeggibile o non valido. Avvio interrotto; il file è conservato.`, { cause });
      }
    }
    return new Archive(absolute, data);
  }

  snapshot() {
    return structuredClone(this.#data);
  }

  mutate(change) {
    const operation = this.#pending.then(async () => {
      const next = this.snapshot();
      // Lookup, revision comparison and saving share this queue. Never mutate
      // the published snapshot before the replacement file has been saved.
      const result = await change(next);
      validateArchive(next);
      const response = structuredClone(result);
      try {
        await writeAtomic(this.#directory, next);
      } catch (cause) {
        throw new AppError(503, 'SAVE_FAILED',
          'Impossibile salvare i dati. Nessuna modifica è stata applicata; controlla la cartella dati e riprova.',
          { cause });
      }
      this.#data = next;
      return response;
    });
    // An invalid request or failed save must not poison subsequent operations.
    this.#pending = operation.then(() => undefined, () => undefined);
    return operation;
  }
}
