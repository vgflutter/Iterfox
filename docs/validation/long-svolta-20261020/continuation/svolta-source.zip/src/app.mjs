import { AppError, sendError, sendJSON, sendNoContent } from './errors.mjs';
import { createProject, updateProject } from './projects.mjs';
import { createTask, listTasks, updateTask } from './tasks.mjs';
import { getWeek } from './week.mjs';
import { createTimeEntry, deleteTimeEntry, listTimeEntries } from './time-entries.mjs';
import { getSummary } from './summary.mjs';
import { createBackup, restoreBackup } from './backup.mjs';
import { servePublic } from './public.mjs';

const MAX_BODY_BYTES = 2 * 1024 * 1024;

function readJSON(request) {
  const contentType = request.headers['content-type']?.split(';', 1)[0].trim().toLowerCase();
  if (contentType !== 'application/json') {
    throw new AppError(415, 'JSON_REQUIRED', 'Invia i dati con Content-Type: application/json.');
  }
  return new Promise((resolve, reject) => {
    let chunks = [];
    let bytes = 0;
    let settled = false;
    const fail = error => {
      if (settled) return;
      settled = true;
      chunks = [];
      reject(error);
    };
    request.on('data', chunk => {
      if (settled) return;
      bytes += chunk.length;
      if (bytes > MAX_BODY_BYTES) {
        // Keep draining without retaining bytes, so the 413 can reach the client.
        fail(new AppError(413, 'BODY_TOO_LARGE', 'Il corpo della richiesta supera il limite di 2 MiB.'));
      } else {
        chunks.push(chunk);
      }
    });
    request.once('aborted', () => fail(new AppError(400, 'INCOMPLETE_REQUEST', 'La richiesta è stata interrotta.')));
    request.once('error', () => fail(new AppError(400, 'INCOMPLETE_REQUEST', 'Impossibile leggere la richiesta.')));
    request.once('end', () => {
      if (settled) return;
      let value;
      try {
        const text = new TextDecoder('utf-8', { fatal: true }).decode(Buffer.concat(chunks));
        value = JSON.parse(text);
      } catch {
        fail(new AppError(400, 'INVALID_JSON', 'Il corpo della richiesta non contiene un JSON valido.'));
        return;
      }
      settled = true;
      chunks = [];
      resolve(value);
    });
  });
}

function methodNotAllowed(response, methods) {
  sendJSON(response, 405, {
    error: 'Metodo non disponibile per questo indirizzo.',
    code: 'METHOD_NOT_ALLOWED',
  }, { allow: methods.join(', ') });
}

export function createRequestHandler(archive) {
  return async (request, response) => {
    try {
      let url;
      try {
        url = new URL(request.url, 'http://127.0.0.1');
      } catch {
        throw new AppError(400, 'INVALID_URL', 'L’indirizzo della richiesta non è valido.');
      }
      const path = url.pathname.replace(/\/+$/, '') || '/';
      if (path === '/api/backup') {
        if (request.method === 'GET') {
          sendJSON(response, 200, createBackup(archive.snapshot()), {
            'content-disposition': 'attachment; filename="svolta-backup.json"',
          });
        } else {
          methodNotAllowed(response, ['GET']);
        }
        return;
      }
      if (path === '/api/restore') {
        if (request.method === 'POST') {
          const input = await readJSON(request);
          const result = await archive.mutate(data => restoreBackup(data, input));
          sendJSON(response, 200, result);
        } else {
          methodNotAllowed(response, ['POST']);
        }
        return;
      }
      if (path === '/api/projects') {
        if (request.method === 'GET') {
          sendJSON(response, 200, archive.snapshot().projects);
        } else if (request.method === 'POST') {
          const input = await readJSON(request);
          const project = await archive.mutate(data => {
            const next = createProject(input);
            data.projects.push(next);
            return next;
          });
          sendJSON(response, 201, project);
        } else {
          methodNotAllowed(response, ['GET', 'POST']);
        }
        return;
      }
      if (path === '/api/tasks') {
        if (request.method === 'GET') {
          sendJSON(response, 200, listTasks(archive.snapshot(), url.searchParams));
        } else if (request.method === 'POST') {
          const input = await readJSON(request);
          const task = await archive.mutate(data => {
            const next = createTask(input, data.projects);
            data.tasks.push(next);
            return next;
          });
          sendJSON(response, 201, task);
        } else {
          methodNotAllowed(response, ['GET', 'POST']);
        }
        return;
      }
      if (path === '/api/week') {
        if (request.method === 'GET') {
          sendJSON(response, 200, getWeek(archive.snapshot(), url.searchParams.get('start')));
        } else {
          methodNotAllowed(response, ['GET']);
        }
        return;
      }
      if (path === '/api/time-entries') {
        if (request.method === 'GET') {
          sendJSON(response, 200, listTimeEntries(archive.snapshot(), url.searchParams));
        } else if (request.method === 'POST') {
          const input = await readJSON(request);
          const entry = await archive.mutate(data => {
            const next = createTimeEntry(input, data);
            data.timeEntries.push(next);
            return next;
          });
          sendJSON(response, 201, entry);
        } else {
          methodNotAllowed(response, ['GET', 'POST']);
        }
        return;
      }
      if (path === '/api/summary') {
        if (request.method === 'GET') {
          sendJSON(response, 200, getSummary(archive.snapshot(), url.searchParams.get('date')));
        } else {
          methodNotAllowed(response, ['GET']);
        }
        return;
      }
      const entryMatch = path.match(/^\/api\/time-entries\/([^/]+)$/);
      if (entryMatch) {
        if (request.method !== 'DELETE') {
          methodNotAllowed(response, ['DELETE']);
          return;
        }
        let id;
        try {
          id = decodeURIComponent(entryMatch[1]);
        } catch {
          throw new AppError(400, 'INVALID_ID', 'L’identificativo della sessione non è valido.');
        }
        await archive.mutate(data => deleteTimeEntry(data, id));
        sendNoContent(response);
        return;
      }
      const taskMatch = path.match(/^\/api\/tasks\/([^/]+)$/);
      if (taskMatch) {
        if (request.method !== 'PATCH') {
          methodNotAllowed(response, ['PATCH']);
          return;
        }
        let id;
        try {
          id = decodeURIComponent(taskMatch[1]);
        } catch {
          throw new AppError(400, 'INVALID_ID', 'L’identificativo dell’attività non è valido.');
        }
        const input = await readJSON(request);
        const task = await archive.mutate(data => {
          const index = data.tasks.findIndex(item => item.id === id);
          if (index === -1) throw new AppError(404, 'TASK_NOT_FOUND', 'L’attività richiesta non esiste.');
          const next = updateTask(data.tasks[index], input);
          data.tasks[index] = next;
          return next;
        });
        sendJSON(response, 200, task);
        return;
      }
      const match = path.match(/^\/api\/projects\/([^/]+)$/);
      if (match) {
        if (request.method !== 'PATCH') {
          methodNotAllowed(response, ['PATCH']);
          return;
        }
        let id;
        try {
          id = decodeURIComponent(match[1]);
        } catch {
          throw new AppError(400, 'INVALID_ID', 'L’identificativo del progetto non è valido.');
        }
        const input = await readJSON(request);
        const project = await archive.mutate(data => {
          const index = data.projects.findIndex(item => item.id === id);
          if (index === -1) throw new AppError(404, 'PROJECT_NOT_FOUND', 'Il progetto richiesto non esiste.');
          const next = updateProject(data.projects[index], input);
          data.projects[index] = next;
          return next;
        });
        sendJSON(response, 200, project);
        return;
      }
      if (await servePublic(request, response, path)) return;
      throw new AppError(404, 'NOT_FOUND', 'Indirizzo non trovato.');
    } catch (error) {
      sendError(response, error);
    } finally {
      // Drain unused bodies (including on 404/405/415) for HTTP keep-alive.
      request.resume();
    }
  };
}
