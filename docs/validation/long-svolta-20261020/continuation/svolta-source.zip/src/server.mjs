import { createServer } from 'node:http';
import { homedir } from 'node:os';
import { join } from 'node:path';
import { Archive } from './archive.mjs';
import { createRequestHandler } from './app.mjs';

function settings() {
  const rawPort = process.env.PORT ?? '4386';
  if (!/^\d+$/.test(rawPort) || !Number.isSafeInteger(Number(rawPort)) || Number(rawPort) > 65535) {
    throw new Error('PORT deve essere un intero tra 0 e 65535.');
  }
  const directory = process.env.SVOLTA_DATA_DIR ?? join(homedir(), '.local', 'share', 'svolta');
  if (directory.trim() === '') throw new Error('SVOLTA_DATA_DIR non può essere vuota.');
  return { port: Number(rawPort), directory };
}

try {
  const { port, directory } = settings();
  const archive = await Archive.open(directory);
  const server = createServer(createRequestHandler(archive));
  server.requestTimeout = 30_000;
  server.headersTimeout = 15_000;
  const shutdown = () => server.close();
  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(port, '127.0.0.1', () => {
      server.removeListener('error', reject);
      resolve();
    });
  });
  server.on('error', error => {
    console.error('Svolta: errore del server.', error);
    process.exitCode = 1;
    server.close();
  });
  process.once('SIGINT', shutdown);
  process.once('SIGTERM', shutdown);
  console.log(`SVOLTA_READY http://127.0.0.1:${server.address().port}`);
} catch (error) {
  console.error('Svolta: avvio non riuscito.', error);
  process.exitCode = 1;
}
