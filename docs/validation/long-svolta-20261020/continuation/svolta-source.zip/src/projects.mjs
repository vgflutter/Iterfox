import { randomUUID } from 'node:crypto';
import { AppError } from './errors.mjs';

function invalid(message) {
  throw new AppError(400, 'INVALID_PROJECT', message);
}

function objectWithFields(value, allowed) {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) {
    invalid('Invia un oggetto JSON con i campi del progetto.');
  }
  if (Object.keys(value).some(key => !allowed.includes(key))) {
    invalid('Il progetto contiene campi non previsti per questa operazione.');
  }
}

function projectName(value) {
  if (typeof value !== 'string') invalid('Il nome del progetto deve essere un testo.');
  const name = value.trim();
  if (name.length === 0 || [...name].length > 100) {
    invalid('Il nome del progetto deve contenere da 1 a 100 caratteri, esclusi gli spazi ai bordi.');
  }
  return name;
}

function validRevision(value) {
  return Number.isSafeInteger(value) && value >= 1;
}

export function validateStoredProject(project) {
  objectWithFields(project, ['id', 'name', 'archived', 'revision']);
  if (typeof project.id !== 'string' || project.id.length === 0 || project.id.trim() !== project.id) {
    invalid('Identificativo del progetto non valido.');
  }
  if (projectName(project.name) !== project.name) invalid('Il nome salvato non è normalizzato.');
  if (typeof project.archived !== 'boolean') invalid('Lo stato di archiviazione deve essere vero o falso.');
  if (!validRevision(project.revision)) invalid('La revisione del progetto deve essere un intero positivo.');
}

export function createProject(input) {
  objectWithFields(input, ['name']);
  return {
    id: randomUUID(),
    name: projectName(input.name),
    archived: false,
    revision: 1,
  };
}

export function updateProject(current, input) {
  objectWithFields(input, ['revision', 'name', 'archived']);
  if (!validRevision(input.revision)) {
    invalid('La revisione è obbligatoria e deve essere un intero positivo.');
  }
  if (input.revision !== current.revision) {
    throw new AppError(409, 'REVISION_CONFLICT',
      'Il progetto è stato modificato. Rileggi i dati e applica le modifiche alla revisione aggiornata.');
  }
  if (current.revision === Number.MAX_SAFE_INTEGER) {
    throw new AppError(409, 'REVISION_LIMIT', 'Il progetto ha raggiunto il limite delle revisioni.');
  }
  const next = { ...current, revision: current.revision + 1 };
  if (Object.hasOwn(input, 'name')) next.name = projectName(input.name);
  if (Object.hasOwn(input, 'archived')) {
    if (typeof input.archived !== 'boolean') invalid('Archiviato deve essere vero o falso.');
    next.archived = input.archived;
  }
  return next;
}
