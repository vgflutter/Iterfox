import { validateArchive } from './archive.mjs';
import { AppError } from './errors.mjs';

const BACKUP_FIELDS = ['format', 'version', 'projects', 'tasks', 'timeEntries'];

export function createBackup(data) {
  return { format: 'svolta', ...data };
}

export function restoreBackup(data, input) {
  if (input === null || typeof input !== 'object' || Array.isArray(input)
      || input.format !== 'svolta' || input.version !== 1
      || Object.keys(input).some(key => !BACKUP_FIELDS.includes(key))) {
    throw new AppError(400, 'INVALID_BACKUP',
      'Il backup deve avere formato svolta, versione 1 e soltanto i campi previsti.');
  }

  const next = {
    version: input.version,
    projects: input.projects,
    tasks: input.tasks,
    timeEntries: input.timeEntries,
  };
  try {
    // Reuse the stored-record rules, including archived records and all links.
    // No defaults, normalization, ID generation or revision increments on import.
    validateArchive(next);
  } catch (cause) {
    throw new AppError(400, 'INVALID_BACKUP', `Backup non valido: ${cause.message}`, { cause });
  }

  // Called within Archive.mutate: validate the whole graph before replacing
  // any collection, then use the same queue and atomic write as every edit.
  // Keep the candidate independent from the request object as well.
  const restored = structuredClone(next);
  data.projects = restored.projects;
  data.tasks = restored.tasks;
  data.timeEntries = restored.timeEntries;
  return { restored: true };
}
