import { randomUUID } from 'node:crypto';
import { AppError } from './errors.mjs';
import { isCivilDate } from './dates.mjs';

const STATUSES = new Set(['todo', 'doing', 'done']);
const EDITABLE_FIELDS = ['title', 'notes', 'dueDate', 'estimateMinutes', 'status', 'archived'];

function invalid(message) {
  throw new AppError(400, 'INVALID_TASK', message);
}

function objectWithFields(value, allowed) {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) {
    invalid('Invia un oggetto JSON con i campi dell’attività.');
  }
  if (Object.keys(value).some(key => !allowed.includes(key))) {
    invalid('L’attività contiene campi non previsti per questa operazione.');
  }
}

function identifier(value) {
  return typeof value === 'string' && value.length > 0 && value.trim() === value;
}

function validRevision(value) {
  return Number.isSafeInteger(value) && value >= 1;
}

function fieldValue(field, value) {
  switch (field) {
    case 'title': {
      if (typeof value !== 'string') invalid('Il titolo dell’attività deve essere un testo.');
      const title = value.trim();
      if (title.length === 0 || [...title].length > 160) {
        invalid('Il titolo deve contenere da 1 a 160 caratteri, esclusi gli spazi ai bordi.');
      }
      return title;
    }
    case 'notes':
      if (typeof value !== 'string' || [...value].length > 4000) {
        invalid('Le note devono essere un testo di massimo 4000 caratteri.');
      }
      break;
    case 'dueDate':
      if (value !== null && !isCivilDate(value)) {
        invalid('La scadenza deve essere null oppure una data reale nel formato YYYY-MM-DD, con anno da 0001 a 9999.');
      }
      break;
    case 'estimateMinutes':
      if (!Number.isInteger(value) || value < 0 || value > 10080) {
        invalid('La stima deve essere un numero intero di minuti tra 0 e 10080.');
      }
      break;
    case 'status':
      if (!STATUSES.has(value)) invalid('Lo stato deve essere todo, doing oppure done.');
      break;
    case 'archived':
      if (typeof value !== 'boolean') invalid('Archiviato deve essere vero o falso.');
      break;
  }
  return value;
}

export function validateStoredTask(task) {
  objectWithFields(task, ['id', 'projectId', 'revision', ...EDITABLE_FIELDS]);
  if (!identifier(task.id)) invalid('Identificativo dell’attività non valido.');
  if (!identifier(task.projectId)) invalid('Identificativo del progetto non valido.');
  if (!validRevision(task.revision)) invalid('La revisione dell’attività deve essere un intero positivo.');
  for (const field of EDITABLE_FIELDS) {
    if (fieldValue(field, task[field]) !== task[field]) invalid('Il titolo salvato non è normalizzato.');
  }
}

export function createTask(input, projects) {
  objectWithFields(input, ['projectId', 'title', 'notes', 'dueDate', 'estimateMinutes']);
  if (!identifier(input.projectId)) invalid('Scegli un progetto per l’attività.');
  const project = projects.find(item => item.id === input.projectId);
  if (!project) throw new AppError(404, 'PROJECT_NOT_FOUND', 'Il progetto richiesto non esiste.');
  if (project.archived) {
    throw new AppError(400, 'PROJECT_ARCHIVED', 'Il progetto è archiviato. Riattivalo prima di aggiungere un’attività.');
  }
  const task = {
    id: randomUUID(),
    projectId: project.id,
    title: fieldValue('title', input.title),
    notes: '',
    status: 'todo',
    dueDate: null,
    estimateMinutes: 0,
    archived: false,
    revision: 1,
  };
  for (const field of ['notes', 'dueDate', 'estimateMinutes']) {
    if (Object.hasOwn(input, field)) task[field] = fieldValue(field, input[field]);
  }
  return task;
}

export function updateTask(current, input) {
  objectWithFields(input, ['revision', ...EDITABLE_FIELDS]);
  if (!validRevision(input.revision)) {
    invalid('La revisione è obbligatoria e deve essere un intero positivo.');
  }
  if (input.revision !== current.revision) {
    throw new AppError(409, 'REVISION_CONFLICT',
      'L’attività è stata modificata. Rileggi i dati e applica le modifiche alla revisione aggiornata.');
  }
  if (current.revision === Number.MAX_SAFE_INTEGER) {
    throw new AppError(409, 'REVISION_LIMIT', 'L’attività ha raggiunto il limite delle revisioni.');
  }
  const next = { ...current, revision: current.revision + 1 };
  for (const field of EDITABLE_FIELDS) {
    if (Object.hasOwn(input, field)) next[field] = fieldValue(field, input[field]);
  }
  return next;
}

export function listTasks(data, searchParams) {
  const projectId = searchParams.get('projectId');
  const status = searchParams.get('status');
  const query = (searchParams.get('q') ?? '').toLowerCase();
  if (status !== null && !STATUSES.has(status)) {
    throw new AppError(400, 'INVALID_TASK_FILTER', 'Il filtro stato deve essere todo, doing oppure done.');
  }
  if (projectId !== null) {
    if (!identifier(projectId)) {
      throw new AppError(400, 'INVALID_TASK_FILTER', 'Il filtro progetto richiede un identificativo non vuoto.');
    }
    if (!data.projects.some(project => project.id === projectId)) {
      throw new AppError(404, 'PROJECT_NOT_FOUND', 'Il progetto richiesto non esiste.');
    }
  }
  const activeProjects = new Set(data.projects.filter(project => !project.archived).map(project => project.id));
  return data.tasks.filter(task => !task.archived
    && (projectId === null ? activeProjects.has(task.projectId) : task.projectId === projectId)
    && (status === null || task.status === status)
    && (task.title.toLowerCase().includes(query) || task.notes.toLowerCase().includes(query)));
}
