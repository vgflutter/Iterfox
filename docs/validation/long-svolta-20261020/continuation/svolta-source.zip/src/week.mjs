import { addCivilDays, civilWeekday, isCivilDate } from './dates.mjs';
import { AppError } from './errors.mjs';
import { listTasks } from './tasks.mjs';

export function getWeek(data, start) {
  if (!isCivilDate(start) || civilWeekday(start) !== 0) {
    throw new AppError(400, 'INVALID_WEEK_START',
      'L’inizio settimana deve essere un lunedì reale nel formato YYYY-MM-DD, con anno da 0001 a 9999.');
  }

  let days;
  try {
    days = Array.from({ length: 7 }, (_, offset) => ({
      date: addCivilDays(start, offset),
      tasks: [],
    }));
  } catch (error) {
    if (!(error instanceof RangeError)) throw error;
    throw new AppError(400, 'WEEK_OUT_OF_RANGE',
      'Tutti e sette i giorni della settimana devono avere un anno da 0001 a 9999.');
  }

  const tasksByDate = new Map(days.map(day => [day.date, day.tasks]));
  const unscheduled = [];
  // The general task list excludes archived tasks and archived projects,
  // while retaining completed tasks and their status, revision and other fields.
  for (const task of listTasks(data, new URLSearchParams())) {
    if (task.dueDate === null) unscheduled.push(task);
    else tasksByDate.get(task.dueDate)?.push(task);
  }
  return { start, days, unscheduled };
}
