import { addCivilDays, civilWeekday, isCivilDate } from './dates.mjs';
import { AppError } from './errors.mjs';
import { listTasks } from './tasks.mjs';

export function getSummary(data, date) {
  if (!isCivilDate(date)) {
    throw new AppError(400, 'INVALID_SUMMARY_DATE',
      'La data di riferimento deve essere reale nel formato YYYY-MM-DD, con anno da 0001 a 9999.');
  }

  let weekStart;
  let weekEnd;
  try {
    weekStart = addCivilDays(date, -civilWeekday(date));
    weekEnd = addCivilDays(weekStart, 6);
  } catch (error) {
    if (!(error instanceof RangeError)) throw error;
    throw new AppError(400, 'WEEK_OUT_OF_RANGE',
      'Tutti e sette i giorni della settimana devono avere un anno da 0001 a 9999.');
  }

  const totals = { todo: 0, doing: 0, done: 0, overdue: 0, minutesThisWeek: 0 };
  // Include archived projects too: their saved time still belongs to them.
  const byProject = data.projects.map(project => ({
    projectId: project.id,
    name: project.name,
    minutesThisWeek: 0,
    done: 0,
  }));
  const projectsById = new Map(byProject.map(project => [project.projectId, project]));

  for (const task of listTasks(data, new URLSearchParams())) {
    totals[task.status]++;
    if (task.status === 'done') projectsById.get(task.projectId).done++;
    else if (task.dueDate !== null && task.dueDate < date) totals.overdue++;
  }

  // Valid fixed-width civil dates compare in calendar order, without timezones.
  for (const entry of data.timeEntries) {
    if (entry.date >= weekStart && entry.date <= weekEnd) {
      totals.minutesThisWeek += entry.minutes;
      projectsById.get(entry.projectId).minutesThisWeek += entry.minutes;
    }
  }
  return { date, weekStart, weekEnd, totals, byProject };
}
