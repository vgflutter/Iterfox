import { randomUUID } from 'node:crypto';
import { isCivilDate } from './dates.mjs';
import { AppError } from './errors.mjs';

const INPUT_FIELDS = ['taskId', 'date', 'minutes', 'note'];

function invalid(message) {
  throw new AppError(400, 'INVALID_TIME_ENTRY', message);
}

function objectWithFields(value, allowed) {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) {
    invalid('Invia un oggetto JSON con i campi della sessione.');
  }
  if (Object.keys(value).some(key => !allowed.includes(key))) {
    invalid('La sessione contiene campi non previsti per questa operazione.');
  }
}

function identifier(value) {
  return typeof value === 'string' && value.length > 0 && value.trim() === value;
}

export function validateStoredTimeEntry(entry) {
  objectWithFields(entry, ['id', 'projectId', ...INPUT_FIELDS]);
  if (!identifier(entry.id)) invalid('Identificativo della sessione non valido.');
  if (!identifier(entry.taskId)) invalid('Identificativo dell’attività non valido.');
  if (!identifier(entry.projectId)) invalid('Identificativo del progetto non valido.');
  if (!isCivilDate(entry.date)) {
    invalid('La data della sessione deve essere reale nel formato YYYY-MM-DD, con anno da 0001 a 9999.');
  }
  if (!Number.isInteger(entry.minutes) || entry.minutes < 1 || entry.minutes > 1440) {
    invalid('I minuti della sessione devono essere un numero intero tra 1 e 1440.');
  }
  if (typeof entry.note !== 'string' || [...entry.note].length > 2000) {
    invalid('La nota della sessione deve essere un testo di massimo 2000 caratteri.');
  }
}

export function createTimeEntry(input, data) {
  objectWithFields(input, INPUT_FIELDS);
  if (!identifier(input.taskId)) invalid('Scegli un’attività per la sessione.');
  const task = data.tasks.find(item => item.id === input.taskId);
  if (!task) throw new AppError(404, 'TASK_NOT_FOUND', 'L’attività richiesta non esiste.');
  if (task.archived) {
    throw new AppError(400, 'TASK_ARCHIVED', 'L’attività è archiviata. Riattivala prima di registrare tempo.');
  }
  const project = data.projects.find(item => item.id === task.projectId);
  if (!project) throw new AppError(404, 'PROJECT_NOT_FOUND', 'Il progetto richiesto non esiste.');
  if (project.archived) {
    throw new AppError(400, 'PROJECT_ARCHIVED', 'Il progetto è archiviato. Riattivalo prima di registrare tempo.');
  }

  const entry = {
    id: randomUUID(),
    taskId: task.id,
    projectId: project.id,
    date: input.date,
    minutes: input.minutes,
    note: Object.hasOwn(input, 'note') ? input.note : '',
  };
  validateStoredTimeEntry(entry);
  return entry;
}

export function listTimeEntries(data, searchParams) {
  const taskId = searchParams.get('taskId');
  if (taskId === null) return data.timeEntries;
  if (!identifier(taskId)) {
    throw new AppError(400, 'INVALID_TIME_ENTRY_FILTER', 'Il filtro attività richiede un identificativo non vuoto.');
  }
  if (!data.tasks.some(task => task.id === taskId)) {
    throw new AppError(404, 'TASK_NOT_FOUND', 'L’attività richiesta non esiste.');
  }
  // History remains readable even when the task or its project is archived.
  return data.timeEntries.filter(entry => entry.taskId === taskId);
}

export function deleteTimeEntry(data, id) {
  const index = data.timeEntries.findIndex(entry => entry.id === id);
  if (index === -1) {
    throw new AppError(404, 'TIME_ENTRY_NOT_FOUND', 'La sessione richiesta non esiste.');
  }
  data.timeEntries.splice(index, 1);
}
