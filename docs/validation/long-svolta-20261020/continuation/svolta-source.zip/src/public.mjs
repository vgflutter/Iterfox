import { readFile } from 'node:fs/promises';
import { sendJSON } from './errors.mjs';

// Deliberately serve only these bundled files. Never turn a request path into a
// filesystem path, and never fall back to the application for unknown URLs.
const assets = new Map([
  ['/', ['index.html', 'text/html; charset=utf-8']],
  ['/assets/svolta.css', ['svolta.css', 'text/css; charset=utf-8']],
  ['/assets/svolta.js', ['svolta.js', 'text/javascript; charset=utf-8']],
]);

export async function servePublic(request, response, path) {
  const asset = assets.get(path);
  if (!asset) return false;
  if (request.method !== 'GET' && request.method !== 'HEAD') {
    sendJSON(response, 405, {
      error: 'Metodo non disponibile per questo indirizzo.',
      code: 'METHOD_NOT_ALLOWED',
    }, { allow: 'GET, HEAD' });
    return true;
  }
  const [filename, contentType] = asset;
  const body = await readFile(new URL(`../public/${filename}`, import.meta.url));
  response.writeHead(200, {
    'content-type': contentType,
    'content-length': body.length,
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff',
    'referrer-policy': 'no-referrer',
    'x-frame-options': 'DENY',
    'content-security-policy': "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'",
  });
  response.end(request.method === 'HEAD' ? undefined : body);
  return true;
}
