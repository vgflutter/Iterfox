// Civil dates are calendar values, never instants in the machine's timezone.
const MONTH_DAYS = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

function daysInMonth(year, month) {
  const leap = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  return month === 2 && leap ? 29 : MONTH_DAYS[month - 1];
}

export function isCivilDate(value) {
  if (typeof value !== 'string' || value.length !== 10 || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const year = Number(value.slice(0, 4));
  const month = Number(value.slice(5, 7));
  const day = Number(value.slice(8, 10));
  if (year < 1 || month < 1 || month > 12 || day < 1) return false;
  return day <= daysInMonth(year, month);
}

function daysBeforeYear(year) {
  const previous = year - 1;
  return previous * 365 + Math.floor(previous / 4)
    - Math.floor(previous / 100) + Math.floor(previous / 400);
}

// Zero is 0001-01-01, a Monday in the proleptic Gregorian calendar.
function civilDayNumber(value) {
  if (!isCivilDate(value)) {
    throw new RangeError('La data deve essere reale nel formato YYYY-MM-DD, con anno da 0001 a 9999.');
  }
  const [year, month, day] = value.split('-').map(Number);
  let number = daysBeforeYear(year) + day - 1;
  for (let current = 1; current < month; current++) number += daysInMonth(year, current);
  return number;
}

// Monday = 0, ..., Sunday = 6. No Date, UTC conversion or daylight-saving rules.
export function civilWeekday(value) {
  return civilDayNumber(value) % 7;
}

export function addCivilDays(value, amount) {
  if (!Number.isSafeInteger(amount)) throw new RangeError('Il numero di giorni deve essere un intero sicuro.');
  const number = civilDayNumber(value) + amount;
  if (!Number.isSafeInteger(number) || number < 0 || number >= daysBeforeYear(10000)) {
    throw new RangeError('La data risultante deve avere un anno da 0001 a 9999.');
  }

  // Find the year with integer comparisons, including years 0001–0099.
  let year = 1;
  let upper = 10000;
  while (year + 1 < upper) {
    const middle = Math.floor((year + upper) / 2);
    if (daysBeforeYear(middle) <= number) year = middle;
    else upper = middle;
  }
  let day = number - daysBeforeYear(year);
  let month = 1;
  while (day >= daysInMonth(year, month)) {
    day -= daysInMonth(year, month);
    month++;
  }
  return `${String(year).padStart(4, '0')}-${String(month).padStart(2, '0')}-${String(day + 1).padStart(2, '0')}`;
}
