export class AppError extends Error {
  constructor(status, code, message, options) {
    super(message, options);
    this.name = 'AppError';
    this.status = status;
    this.code = code;
  }
}

export function sendJSON(response, status, value, headers = {}) {
  if (response.destroyed || response.writableEnded) return;
  const body = JSON.stringify(value);
  response.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(body),
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff',
    ...headers,
  });
  response.end(body);
}

export function sendNoContent(response) {
  if (response.destroyed || response.writableEnded) return;
  response.writeHead(204, {
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff',
  });
  response.end();
}

export function sendError(response, error) {
  const known = error instanceof AppError;
  if (!known || error.status >= 500) console.error('Svolta:', error);
  sendJSON(response, known ? error.status : 500, {
    error: known ? error.message : 'Errore interno. La richiesta non è stata completata.',
    code: known ? error.code : 'INTERNAL_ERROR',
  });
}
