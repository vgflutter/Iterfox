# Provenienza e limiti delle verifiche

## Missione r4: stato corrente

Missione `long-svolta-20261020-r4`, esito «Portabilità e ritorno al prodotto
finito», task «Completare la consegna con le ricevute host correnti».
Il candidato precedente non ha un checkpoint certificato per questa missione:
la revisione si era fermata per riferimenti a file o prove non validi.

I sette criteri, inizialmente PENDING, hanno ora ricevute host **PASS** nel run
`20261020T234131-6d40b050`, contratto v1. La tabella delle
[ricevute correnti](#ricevute-host-correnti) riporta comandi, ID completi e gruppi.
I metadati e gli output sono stati consultati in sola lettura nel registro locale
del runtime, negli eventi `verification.passed` alle sequenze 107, 109, 111, 113,
115, 117 e 119. Gli ID delle ricevute sono identificatori del runtime, non file
del worktree né ID degli eventi.

Questa è la fotografia delle ricevute disponibili prima di questo aggiornamento
esclusivamente documentale; le suite non sono state rieseguite nella sandbox.
Il codice e le spiegazioni del modello restano distinti dagli esiti host.
Il registro non assegna stamp, impronte o certificazioni al diff documentale.

| Tipo di informazione | Provenienza e limite |
| --- | --- |
| Descrizione del prodotto | Descrizioni del modello derivate dai sorgenti, riportate in [README](../README.md) e [guida](guida.md). Non dimostrano l’esecuzione reale. |
| Controlli locali dichiarati | Sintassi, controlli statici e simulazioni mirate riportati nella consegna dell’implementazione. Non rieseguiti per questo aggiornamento; nessun browser o HTTP reale in quei controlli. |
| Controlli documentali correnti | Collegamenti, coerenza delle citazioni e diff, descritti sotto. Nessuna suite API/browser avviata. |
| Ricevute host correnti | Sette ricevute PASS del run corrente, con gruppi 6/6/4/7/3/4/3. Esiti limitati ai casi dei comandi approvati. |
| Storico ereditato | Resoconti e ID del run precedente o di missioni precedenti, separati sotto; non attestano il candidato corrente. |

## Descrizione dell’implementazione dichiarata dal modello

Le descrizioni seguenti sono conservate dalla consegna dell’implementazione.
Non sono nuove osservazioni di esecuzione di questo task documentale.

La sezione [Backup](../public/index.html) sostituisce il segnaposto con download,
selezione del file, consenso esplicito e ripristino. Le funzioni in
[public/svolta.js](../public/svolta.js) controllano file e grafo completo prima di
abilitare l’invio. JSON UTF-8, schema svolta versione 1, campi, tipi, limiti,
date civili, stati, revisioni, duplicati per tipo e riferimenti sono controllati
anche prima della richiesta. Cambiare file azzera il consenso; il gestore di
invio ricontrolla i requisiti indipendentemente dal pulsante disabilitato.

Durante il ripristino il client blocca altre scritture e la navigazione. Dopo il
successo invalida le letture in corso, azzera editor, revisioni, confronti,
bozze, selezioni e filtri, quindi rilegge tutte le viste e la cronologia globale.
Settimana e data di riferimento tornano ai valori correnti del dispositivo.
Una risposta di connessione incerta causa la stessa invalidazione prudenziale,
con errore esplicito e senza invii automatici. Un rifiuto server conserva le bozze.

La consegna dell’implementazione descrive gli endpoint in
[src/app.mjs](../src/app.mjs), [src/backup.mjs](../src/backup.mjs) e
[src/archive.mjs](../src/archive.mjs): esportazione completa,
validazione mediante i validatori persistenti e sostituzione sulla coda atomica,
senza pubblicare in memoria prima della rinomina. Le prove host disponibili
sono riportate sotto, con la loro copertura; questo task non le ha rieseguite.

Scelte reversibili: controlli nei pannelli e nei colori esistenti; modulo Backup
in una colonna sotto 1100px; checkbox e testo del consenso affiancati con a capo;
selettore file limitato al pannello. Le regole in
[public/svolta.css](../public/svolta.css) sono state lette insieme ai layout di
progetti, attività, settimana, riepilogo e dialoghi nella revisione statica
dichiarata allora. Questa descrizione non è un’osservazione del layout a 390px;
i controlli host sul layout sono distinti sotto.

## Controlli locali dichiarati nella consegna dell’implementazione

Il resoconto precedente del modello dichiara i seguenti controlli il 21 ottobre
2026, senza dipendenze aggiunte e senza suite complete. Sono conservati con i
loro limiti, senza attribuire loro provenienza host o una nuova esecuzione:

- `node --check` su tutti i moduli `src/*.mjs` e su `public/svolta.js`: concluso
  senza errori di sintassi.
- Script Node temporaneo in memoria con `node:vm`: confronto tra la funzione
  reale `validateBackupFile` estratta dal client e `validateArchive` importata
  dal server su **34 casi**, tutti coerenti con l’esito atteso. Copre archivio
  vuoto e archiviato, testo Unicode, campi mancanti/estranei, tipi errati,
  revisioni invalide, duplicati, riferimenti assenti o incoerenti, date impossibili
  e con newline, stati errati, stima frazionaria, minuti e note fuori limite.
- Simulazione Node con `node:vm` delle funzioni reali del client su controlli DOM
  e risposte fetch simulati: nessun invio senza file valido e consenso anche
  chiamando direttamente il gestore; JSON malformato, grafo invalido e file oltre
  2 MiB; lettura file fuori ordine ignorata; consenso azzerato cambiando file;
  blocco durante una scrittura precedente; sostituzione con **cinque letture
  obsolete** di progetti, attività, settimana, cronologia e riepilogo che arrivano
  dopo le nuove risposte; reset di editor, selezioni, filtri e bozza; errore 503
  con bozza conservata; blocco delle mutazioni durante il ripristino. Esito
  locale passato. Questa prova non esegue un browser o il server HTTP.
- Analisi statica HTML con Python: **195 ID univoci**, **77 riferimenti**
  label/ARIA risolti e ID letterali usati da `byId` presenti nell’HTML.
- Controllo dei file collegati e delle ancore nei tre documenti, percorsi del diff
  e `git diff --check`: senza riferimenti mancanti o errori di spaziatura.

Secondo quel resoconto, gli script mirati sono stati eseguiti tramite heredoc,
senza aggiungere o modificare test nel repository. Non sono comandi di
accettazione o ricevute host e non sono stati rieseguiti per questo aggiornamento.
Non osservano DOM nativo, download reale, focus, Tab/Escape, annunci di lettori
di schermo, dimensioni effettive, HTTP, atomicità su disco o integrazione reale.
La perdita della risposta di ripristino è gestita dal codice, ma non è stata
simulata in questi controlli. Non è stata avviata alcuna suite API/browser.

## Ricevute host correnti

Le sette ricevute seguenti sono le più recenti disponibili per ciascun criterio
nel run `20261020T234131-6d40b050`, contratto v1. Sono state registrate il
**20 ottobre 2026, fra le 23:56:37 e le 23:56:52 UTC**; tutte riportano stato
`passed`, codice di uscita 0 e risultato **PASS**. Il contratto e i comandi
approvati restano invariati.

| Criterio | Comando approvato | ID ricevuta corrente | Esito | Gruppi |
| --- | --- | --- | --- | --- |
| projects-api | `node tests/acceptance.mjs projects-api` | `2eb48665-ee12-4118-b2fa-3210b3f21e61` | PASS | 6 |
| tasks-api | `node tests/acceptance.mjs tasks-api` | `02477114-78f2-4699-ae9a-f3e697f89173` | PASS | 6 |
| board-ui | `node tests/acceptance.mjs board-ui` | `73606588-28c6-48b0-b601-25da7788fa57` | PASS | 4 |
| planning-api | `node tests/acceptance.mjs planning-api` | `3fef604f-960c-4572-ac99-bdc046c3e040` | PASS | 7 |
| planning-ui | `node tests/acceptance.mjs planning-ui` | `8e143c1b-5f25-467f-975a-19d342f3912a` | PASS | 3 |
| backup-api | `node tests/acceptance.mjs backup-api` | `45816252-0498-4b82-ab13-7cf1591bf244` | PASS | 4 |
| backup-ui | `node tests/acceptance.mjs backup-ui` | `1d0148b8-dd77-477d-828d-c606b27c11e9` | PASS | 3 |

## Copertura e limiti

I controlli approvati in [tests/acceptance.mjs](../tests/acceptance.mjs) e
[tests/browser.mjs](../tests/browser.mjs) sono soglie di regressione. Le ricevute
API coprono i casi previsti per persistenza, revisioni, filtri, date civili,
sessioni e riepilogo. Per il backup includono archivi e riferimenti, ripristino
con ID e revisioni invariati anche dopo riavvio, rifiuto di record e grafi
invalidi, JSON malformato e corpo oltre 2 MiB senza alterare i dati.

Le ricevute browser coprono creazione, modifica, filtri e conflitto tra schede;
riprogrammazione della scadenza e registrazione del tempo con riepilogo;
download reale del backup, consenso prima del POST e rifiuto di JSON malformato.
Includono il controllo dell’assenza di scorrimento orizzontale nelle viste
Attività, Settimana e Backup a **390 × 844**, nei casi della suite.

I PASS non estendono questa copertura a tutti i dati, dialoghi, schermi o
browser. Non attestano il ritorno del focus, l’intero percorso da tastiera,
gli annunci dei lettori di schermo, la qualità visiva completa o tutti gli
aggiornamenti delle viste dopo il ripristino con editor e letture concorrenti.
Le suite non simulano un errore di scrittura su disco. Le simulazioni locali
dichiarate sopra restano separate da queste ricevute. La revisione del prodotto
e l’eventuale checkpoint restano al supervisore host; non si dichiara qui un
checkpoint certificato, un revisore indipendente o una pubblicazione.

## Controlli documentali di questo aggiornamento

Controllati i collegamenti locali e le ancore di README e dei due documenti,
la corrispondenza di comandi, ID, esiti e gruppi con le sette ricevute del runtime
e `git diff --check`. Il confronto dei file prima e dopo l’aggiornamento riguarda
solo `README.md`, `docs/guida.md` e questo registro: codice, test e contratto
non sono stati modificati in questo task. Nessuna suite API/browser rieseguita;
nessuna nuova osservazione del prodotto attribuita a questi controlli.

## Storico ereditato

La delega indica il precedente checkpoint
`a8cebbaa4e32b45f46a04fc0b2c30d95511cf473` come provenienza storica. Non è una
certificazione del candidato attuale. La documentazione ereditata riportava
cinque ricevute del run `20261020T231956-19cf8a63`, contratto v1, con i seguenti
metadati. Sono resoconti forniti, non nuove prove di questa delega:

| Comando | ID storico riportato | Esito riportato allora | Gruppi |
| --- | --- | --- | --- |
| `node tests/acceptance.mjs projects-api` | `3c82b042-9f7c-4207-8427-fb9c3406ce17` | PASS | 6 |
| `node tests/acceptance.mjs tasks-api` | `baae52cf-7226-4160-b412-8c863433580a` | PASS | 6 |
| `node tests/acceptance.mjs board-ui` | `e822bee2-e285-4dbf-b70f-eff14886d902` | PASS | 4 |
| `node tests/acceptance.mjs planning-api` | `1065d21b-6b6d-4bb2-ac36-1e7177cfb9ba` | PASS | 7 |
| `node tests/acceptance.mjs planning-ui` | `e2fafac5-859e-4a51-877b-8def02d67b1b` | PASS | 3 |

Gli ID sono identificatori del runtime, non percorsi o file del worktree. Gli
originali non sono stati consultati in questo task; non si attribuisce loro
validità corrente, una nuova data, uno stamp o un’impronta della patch.
La revisione precedente non ha prodotto un checkpoint certificato.

I precedenti documenti riferivano inoltre ricevute r2 con i soli prefissi
`012fb1ac…`, `244ba0db…`, `79628235…` (6/6/4 gruppi) e ricevute ancora anteriori
`f60e43e0…`, `d3604e71…`, `98c0ea1d…`, allora indicate come stale. Citavano anche
un audit UI e simulazioni locali su date, DOM, coda, filesystem temporaneo,
sessioni e riepilogo. Sono dichiarazioni storiche non rieseguite: non attestano
la portabilità, la patch attuale o una revisione indipendente. Le ricevute
storiche restano separate dalle sette ricevute host correnti e dai controlli
locali dichiarati; nessun risultato storico viene promosso a prova corrente.
