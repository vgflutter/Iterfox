# Usare Svolta, dal primo progetto al backup

Questa guida descrive il candidato presente: le istruzioni derivano dal codice.
Il [registro delle verifiche](verifiche.md#ricevute-host-correnti) riporta sette
ricevute host correnti PASS, con comandi, ID e gruppi 6/6/4/7/3/4/3. Distingue
questi esiti dai controlli locali dichiarati e dalle ricevute storiche, con i
rispettivi limiti. Non si dichiara un checkpoint certificato della missione.

Occorre Node.js 22.13 o successivo. Dalla cartella del progetto avviare
`node src/server.mjs` oppure `npm start`, senza installare dipendenze. Aprire nel
browser l’indirizzo della riga `SVOLTA_READY http://127.0.0.1:…` e lasciare il
terminale aperto. **Ctrl+C** ferma il server. Per porta e cartella personalizzate,
vedere [Avvio](../README.md#avvio).

## Creare un progetto e la prima attività

1. Aprire **Progetti**, scrivere **Nome progetto** (1–100 caratteri) e premere
   **Crea progetto**. Il messaggio di successo conferma il salvataggio.
2. Sul progetto premere **Aggiungi un’attività**. Si apre **Attività** con il
   progetto scelto; si può anche arrivare dalla navigazione e scegliere **Progetto**.
3. Compilare **Titolo attività** (1–160 caratteri), ed eventualmente **Note**
   (fino a 4000 caratteri), **Scadenza** e **Stima (minuti)**. La stima accetta
   interi 0–10080; 0 significa senza stima. Nome e titolo vengono ripuliti dagli
   spazi ai bordi; le note conservano spazi e a capo.
4. Premere **Crea attività**. Dopo il successo compare una scheda «Da fare» e
   si svuotano i dettagli, mantenendo il progetto per l’attività successiva.

Le schede mostrano progetto, stato, note se presenti, scadenza e stima. Nomi,
titoli e note sono testo letterale: eventuali tag HTML non vengono interpretati.
Se non ci sono progetti attivi, crearne uno o riattivarne uno archiviato.

## Modificare e filtrare

**Modifica** sulla scheda apre **Modifica attività**. Cambiare titolo, note,
scadenza, stima o **Stato** (Da fare, In corso, Completata), poi **Salva modifiche**.
Il progetto rimane lo stesso; una scadenza vuota rimuove quella precedente.
Il dialogo si chiude dopo il successo. Gli errori conservano i campi;
**Annulla** o **Escape** scartano la bozza. Durante il salvataggio occorre attendere.

**Filtra per progetto**, **Filtra per stato** e **Cerca attività** si applicano
insieme e aggiornano l’elenco senza invio. La ricerca trova sottostringhe nel
titolo o nelle note ignorando maiuscole e minuscole; gli spazi digitati contano.
**Azzera filtri** torna alle attività non archiviate di tutti i progetti attivi,
comprese quelle completate. Se un’attività appena salvata non appare, controllare
i filtri; il messaggio di successo conferma comunque il salvataggio.

Il filtro progetto non cambia il progetto scelto nel modulo di creazione.
**Filtra per progetto** include anche progetti archiviati: selezionarne uno
per consultare le sue attività non archiviate.

## Dalle scadenze al piano settimanale

1. Aprire **Settimana**. Il primo piano parte dal lunedì della settimana corrente
   sul dispositivo. Per un altro intervallo compilare **Inizio settimana** con
   un lunedì e premere **Mostra settimana**. La data non viene spostata
   automaticamente: un martedì o una settimana oltre il calendario ammesso
   generano un errore, senza cambiare le attività.
2. Leggere l’intervallo e i sette giorni da lunedì a domenica. Ogni giorno
   mostra la data e le attività in scadenza, oppure «Nessuna attività in programma».
   Le completate rimangono visibili con lo stato scritto in italiano.
3. Consultare **Senza scadenza** sotto i giorni. Il piano include tutti i progetti
   attivi e non dipende da progetto, stato o ricerca impostati in **Attività**.
4. Scegliere **Modifica** su una scheda, cambiare **Scadenza** e premere
   **Salva modifiche**. L’attività si sposta al nuovo giorno o in **Senza scadenza**
   se il campo è vuoto. Se la nuova scadenza è fuori settimana, scompare da questo
   intervallo ma resta nell’elenco Attività. Per cambiare soltanto la scadenza
   non serve modificare lo stato.

Si usa lo stesso dialogo **Modifica attività**, con conservazione degli input
in caso di errore e confronto esplicito delle revisioni su conflitto. **Annulla**
o **Escape** scartano la bozza. Alla chiusura il focus torna al comando della
scheda nel piano, anche se ha cambiato giorno; se la scheda non c’è più torna
al titolo **Settimana**. **Archivia** richiede conferma e rimuove la scheda dal
piano; archiviare un progetto ne nasconde tutte le attività.

Il caricamento e l’esito della lettura sono annunciati. **Mostra settimana**
permette di riprovare dopo un errore; se resta un piano precedente per lo stesso
intervallo, un messaggio avverte che potrebbe non essere aggiornato. Tornare
nella sezione o nella scheda del browser rilegge l’ultima settimana richiesta,
senza sostituire le bozze aperte o inviare una data ancora in preparazione.
Non c’è sincronizzazione continua. Su schermi stretti i giorni sono disposti
in un’unica colonna. La ricevuta `planning-ui` comprende il controllo dell’assenza
di scorrimento orizzontale a 390 × 844 nei casi della suite; copertura e limiti
sono nel [registro](verifiche.md#copertura-e-limiti).

## Registrare e consultare il tempo

1. Nella lista **Attività** o nel piano **Settimana**, premere **Registra tempo**
   sulla scheda desiderata. Il dialogo indica l’attività e il progetto.
2. Compilare **Data** e **Minuti** (un intero da 1 a 1440). La data proposta è
   oggi sul dispositivo: per lavoro svolto in altri giorni cambiarla esplicitamente,
   anche quando il piano mostra un’altra settimana. **Nota sessione** è facoltativa,
   fino a 2000 caratteri, e conserva spazi, a capo e testo letterale.
3. Premere **Salva sessione** e attendere la conferma. Solo dopo il salvataggio
   confermato il dialogo si chiude automaticamente e il successo è annunciato
   nella pagina di origine. Il focus torna al comando della scheda o al titolo
   della sezione. Cronologia e riepilogo già consultati si aggiornano. Riaprire
   **Registra tempo** per consultare le **Sessioni di questa attività**: mostrano
   data, minuti e nota, ordinate per data dalla più recente. Non serve cambiare
   lo stato, neppure per una completata; registrare tempo non cambia stato o
   revisione dell’attività.
4. Per correggere un errore scegliere **Elimina sessione**, controllare data e
   minuti nella conferma, poi **Conferma eliminazione sessione**. Il focus iniziale
   va a **Annulla eliminazione**, che lascia tutto invariato. L’eliminazione è
   definitiva e rimuove solo quella sessione; si può poi registrarne una corretta.

Gli errori mantengono aperto il dialogo, conservano la bozza e non avviano
tentativi automatici. Se manca la conferma per un’interruzione della connessione,
la sessione potrebbe essere stata
salvata o eliminata: usare **Aggiorna sessioni** e controllare prima di riprovare.
Una rilettura non sostituisce Data, Minuti o Nota sessione. Durante un inserimento
o un’eliminazione i comandi di modifica sono bloccati e Escape attende la risposta.
**Annulla** o Escape scartano solo la bozza non salvata; le sessioni
confermate restano. Il focus torna al comando della scheda o al titolo della sezione.

In **Riepilogo**, **Cronologia sessioni** mostra tutte le registrazioni,
indipendentemente dai filtri Attività e anche dopo l’archiviazione. Se il titolo
non è negli elenchi caricati, appare l’ID dell’attività per distinguerla; data,
minuti e nota restano disponibili. L’eliminazione funziona anche sullo storico
archiviato. Per registrare nuovo tempo occorrono attività e progetto attivi.

## Leggere il Riepilogo

1. Aprire **Riepilogo**, scegliere **Data di riferimento** e premere
   **Aggiorna riepilogo**. La data iniziale è oggi sul dispositivo; qualunque
   giorno reale è ammesso se tutta la settimana rientra negli anni 0001–9999.
   L’intervallo mostrato va dal lunedì alla domenica contenenti la data, inclusi.
2. Leggere **Da fare**, **In corso**, **Completate** e **Scadute**. I primi tre
   conteggi riguardano tutte le attività non archiviate di progetti attivi,
   comprese quelle fuori settimana o senza scadenza. Sono gli stati attuali:
   scegliere una data passata non ricostruisce gli stati di quel giorno.
   **Scadute** conta quelle Da fare o In corso con scadenza precedente alla data
   scelta; esclude completate, senza scadenza e archivi.
3. **Tempo della settimana** mostra il totale e i minuti per ogni progetto,
   compresi progetti a zero e storico di attività o progetti archiviati.
   L’archiviazione non cancella il tempo. Una sessione fuori intervallo rimane
   nella cronologia ma non aumenta questo totale; una stima non registra tempo.
4. **Cronologia sessioni**, sotto il riepilogo, rimane globale: la data scelta,
   la settimana del piano e i filtri Attività non la limitano. Consente di
   consultare o eliminare esplicitamente anche sessioni archiviate. **Aggiorna
   cronologia** rilegge le sessioni e il riepilogo dell’ultima data richiesta.

Salvare attività, rinominare o archiviare progetti, registrare o eliminare
sessioni aggiorna un riepilogo già aperto. Tornare nella sezione o nella
scheda/finestra rilegge l’ultima data richiesta, conservando una nuova data
ancora in preparazione nel campo. Non c’è sincronizzazione continua.
Per applicare la nuova data occorre **Aggiorna riepilogo**.

In assenza di attività, progetti o tempo compaiono messaggi dedicati e conteggi
a zero. Gli errori sono visibili e la data digitata è conservata: correggerla o
riprovare con **Aggiorna riepilogo**. Se una rilettura della stessa data fallisce,
il risultato precedente è segnalato come potenzialmente non aggiornato. Dopo
l’invio di una data diversa il vecchio risultato viene nascosto per evitare
di confondere gli intervalli. La cronologia resta utilizzabile anche se il
riepilogo non si carica. Le date si leggono come giorno/mese/anno, senza
conversioni di fuso; caricamento ed esito della lettura sono annunciati.

## Rinomina, archiviazione e riattivazione

In **Progetti**, **Rinomina** apre **Nuovo nome progetto**: correggerlo e premere
**Salva nome**. Il nome cambia anche sulle attività e nei selettori, conservando
l’associazione allo stesso progetto.

**Archivia** richiede **Archivia progetto** per confermare. Il progetto passa
negli **Archiviati**, conserva i dati e nasconde le sue attività dalla vista
generale. Non accetta nuove attività. **Riattiva** e poi **Riattiva progetto**
lo rendono disponibile e mostrano di nuovo le attività non archiviate.

**Archivia** su un’attività richiede **Archivia attività** e la nasconde da tutti
gli elenchi, anche usando il filtro progetto. I dati restano salvati. Riattivare
il progetto non riattiva le singole attività archiviate: questa versione non
offre un comando visuale per recuperarle. Le API permettono la riattivazione
solo conoscendo ID e revisione corrente; vedere [Attività](../README.md#attività).
Annullare una conferma non modifica i dati.

## Errori e bozze

Gli errori non svuotano gli input. Correggere il campo indicato o verificare che
il server sia attivo. Se una connessione interrotta impedisce la conferma, il
server potrebbe avere già salvato: usare **Aggiorna progetti** o **Aggiorna attività**
e controllare i dati prima di inviare di nuovo, soprattutto per evitare duplicati.

Questi comandi e il ritorno nella scheda/finestra aggiornano gli elenchi senza
cambiare gli editor aperti. Non c’è sincronizzazione continua. Cambiare sezione
conserva i campi; **ricaricare o chiudere la pagina perde le bozze non salvate**.

Se un progetto scelto viene archiviato in un’altra scheda, una nuova attività
viene rifiutata e il progetto risulta «non disponibile» dopo l’aggiornamento.
Gli altri input restano compilati: scegliere esplicitamente un progetto attivo
oppure riattivare quello originale. Svolta non ne sceglie un altro automaticamente.

## Conflitti tra schede

Un conflitto significa che il record salvato è cambiato da quando si è aperto
l’editor. Il salvataggio viene rifiutato e il dialogo conserva la bozza e la
revisione iniziale. Aggiornare l’elenco non risolve il conflitto e non modifica
la bozza. Nessun nuovo tentativo parte automaticamente.

Per un’attività:

1. Premere **Leggi versione corrente**. Confrontare **Versione aperta**,
   **Versione corrente letta** e **La tua bozza** per titolo, note, scadenza,
   stima, stato e archiviazione. La lettura non cambia i campi del modulo.
2. Per ogni campo modificato nella bozza che differisce anche dalla versione
   corrente, scegliere **Mantieni versione corrente** oppure **Applica la mia bozza**.
   I campi non modificati conservano i dati correnti. Per esempio, applicare solo
   le proprie note conserva il titolo cambiato nell’altra scheda.
3. Premere **Applica le modifiche scelte alla revisione…**. Sono inviati solo
   i campi scelti dalla bozza sulla versione confrontata. Per un conflitto durante
   l’archiviazione, scegliere **Archiviazione** e confermare **Archivia alla revisione…**.

Si può ancora correggere la bozza: cambiare un campo richiede una nuova scelta
per quel campo. Se si mantengono tutti i dati correnti, o coincidono già con la
bozza, non c’è nulla da inviare e il pulsante resta disabilitato: **Annulla**
chiude senza salvare la bozza. Un ulteriore conflitto conserva gli input e
richiede una nuova lettura e nuove scelte. Se la lettura fallisce, si può riprovare.

Il confronto ignora i filtri e funziona anche nei progetti archiviati. Se invece
è stata archiviata l’attività stessa, la versione corrente non è più consultabile
tramite gli elenchi: il dialogo lo segnala e non permette un invio senza confronto.
Copiare i valori utili dalla bozza prima di annullare.

Per un progetto, **Leggi versione corrente** confronta nome, stato e revisioni.
**Applica la rinomina alla revisione…** conferma solo il nome digitato, conservando
lo stato corrente. **Archivia alla revisione…** o **Riattiva alla revisione…**
cambiano solo lo stato, conservando il nome corrente. Si può annullare oppure,
se arriva un altro conflitto, leggere e confrontare di nuovo.

## Conservare e ripristinare un backup

1. Aprire **Backup** e premere **Scarica backup**. Cercare nei download del
   browser un file `svolta-backup-AAAA-MM-GG.json`. Conservarlo in un posto adatto:
   include note e dati personali in chiaro, senza cifratura. La copia contiene
   tutti i progetti, attività e sessioni, anche archiviati, con ID e revisioni.
   Le bozze non salvate non fanno parte della copia.
2. Prima di sostituire i dati, scaricare anche il backup dello stato corrente
   se si vuole poter tornare indietro. Chiudere le altre schede di Svolta.
3. In **File di backup**, scegliere il JSON. Attendere «File valido» e i conteggi
   di progetti, attività e sessioni. Scegliere il file non modifica l’archivio:
   un JSON malformato, un record incoerente o un file oltre 2 MiB mostra un errore
   e lascia disabilitato **Ripristina backup**, anche con il consenso selezionato.
4. Leggere l’avviso e selezionare **Ho capito: il ripristino sostituisce i dati
   correnti**. Il consenso non è preselezionato; scegliere un altro file lo azzera.
   Solo dopo file valido e consenso si può premere **Ripristina backup**.
   Attendere eventuali altre scritture in corso.
5. Attendere **Backup ripristinato**. L’operazione sostituisce tutto, senza unione
   o deduplicazione: i record non presenti nel backup vengono rimossi, compresi
   eventuali progetti creati dopo il download. Anche una copia vuota valida
   svuota l’archivio. Non esiste annullamento; un precedente backup permette un
   successivo ripristino dello stato che si era conservato.
6. Dopo il successo, progetti, attività, settimana, cronologia globale e riepilogo
   sono riletti senza ricaricare la pagina. Filtri, selezioni, editor, confronti
   delle revisioni e bozze precedenti vengono scartati. La settimana torna a quella
   corrente e la data di riferimento a oggi. Se un caricamento fallisce, usare
   il comando Aggiorna della vista. Riaprire le altre schede dopo il ripristino,
   senza salvare le vecchie bozze: non ricevono una notifica di sostituzione.

Il server controlla nuovamente l’intero file prima del salvataggio. Un rifiuto
per dati invalidi o un errore di scrittura conserva l’archivio precedente e le
bozze; non viene applicato un ripristino parziale. Dopo ogni invio il consenso
viene azzerato. In caso di connessione interrotta, la risposta può andare persa
dopo la sostituzione: il browser rilegge le viste e scarta i vecchi editor per
precauzione. Controllare i dati, eventualmente con **Scarica backup**, prima di
riprovare; non ci sono invii automatici.

Per trasferire il lavoro, avviare Svolta nella nuova destinazione con una cartella
dati separata, poi importare il backup seguendo questi passaggi. Il limite del
ripristino è 2 MiB: copie più grandi possono essere scaricate ma non ripristinate
in questa versione. Il file interno `archive.json` ha uno schema diverso; usare
sempre il download di **Backup**. Non sono previste fusioni, altri formati,
backup automatici o cifratura.

## Tastiera e schermi stretti

**Vai al contenuto** salta la navigazione. Usare **Tab** e **Maiusc+Tab** per
spostarsi, **Invio** o **Spazio** per i pulsanti. Il contorno indica il focus;
i campi hanno etichette e gli errori di compilazione portano al campo da correggere.
Il dialogo nativo mantiene la navigazione al suo interno; alla chiusura il focus
torna al comando di apertura o al titolo della sezione se il record non è più
visibile. Durante il salvataggio occorre attendere la risposta prima di chiudere.

Il layout prevede navigazione su più righe, campi in colonna e dialoghi con
scorrimento verticale su schermi stretti; nomi, note e confronti vanno a capo.
Il nome completo del progetto selezionato appare sotto i selettori. Gli stati
sono scritti in italiano oltre al colore, le scadenze come giorno/mese/anno.
Anche il modulo Backup passa a una colonna su schermi stretti; il consenso va
a capo e il selettore file rimane nel pannello. Queste indicazioni descrivono il
CSS. Le ricevute host comprendono download reale e controlli dell’assenza di
scorrimento orizzontale per Attività, Settimana e Backup a 390 × 844; non coprono
tutti i dialoghi, il focus nativo, il percorso completo da tastiera o gli annunci
dei lettori di schermo. Vedere [copertura e limiti](verifiche.md#copertura-e-limiti).

## Dati e limiti

I record salvati rimangono in `~/.local/share/svolta/archive.json`, oppure nella
cartella `SVOLTA_DATA_DIR`. Ai riavvii usare la stessa cartella e un solo processo
per cartella. L’archivio è interamente in memoria; non c’è un blocco tra processi.
Non modificare il file mentre il server è attivo. Avvio e problemi comuni sono
nel [README](../README.md#cartella-dati-e-affidabilità).

L’archiviazione di un progetto conserva attività e tempo. La riattivazione dei
progetti è disponibile nell’interfaccia; quella delle singole attività soltanto
via API. La cronologia può mostrare l’ID se un’attività non è negli elenchi caricati.
Le stime non registrano tempo e il riepilogo non ricostruisce gli stati passati.
Le bozze vivono nella pagina: chiusura, ricaricamento o ripristino le scartano.

Il server ascolta solo sul dispositivo che lo esegue. Il layout mobile non
permette al telefono di raggiungere il computer con lo stesso indirizzo locale.
Non ci sono account, sincronizzazione, servizi esterni, pubblicazione remota,
recupero automatico o garanzie contro guasti del disco. I backup sono manuali.
Le revisioni originali vengono ripristinate: non proteggono da una vecchia scheda
che tenti di modificare dati appena sostituiti con la stessa revisione.

Il percorso descritto è **progetti → attività → settimana → tempo → riepilogo →
backup**. Le sette [ricevute host correnti](verifiche.md#ricevute-host-correnti)
riportano PASS per i casi API e browser approvati di questo percorso, con i
limiti elencati nel registro; non attestano ogni interazione o aggiornamento
delle viste dopo un ripristino. Questo aggiornamento riguarda solo la
documentazione e non riesegue le suite. Lo [storico](verifiche.md#storico-ereditato)
rimane distinto dagli esiti correnti.
