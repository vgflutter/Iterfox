// Frozen host acceptance. These fixtures are not application implementation.
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {mkdtemp,rm,mkdir,writeFile,readFile,readdir} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join,basename} from 'node:path';
import {createServer} from 'node:net';
const trial='/Users/vins/work/iterfox/.iterfox/missions/night-custode-20261020';
const mode=process.argv[2]||'all';
const modes=['inventory','inventory-ui','maintenance','maintenance-ui','backup','backup-ui'];
if(mode==='all'){
  for(const selected of modes){const status=await new Promise((resolve,reject)=>{const p=spawn(process.execPath,['tests/acceptance.mjs',selected],{stdio:'inherit'});p.once('error',reject);p.once('exit',code=>resolve(code));});if(status!==0)process.exit(status||1);}
  process.exit(0);
}
assert.ok(modes.includes(mode),'Known host acceptance mode required');
const dir=await mkdtemp(join(tmpdir(),'custode-acceptance-'));
let child,base,log='',browser;
let groups=0;
function passed(name){groups++;console.log(`PASS ${name}`);}
async function port(){const s=createServer();await new Promise(r=>s.listen(0,'127.0.0.1',r));const p=s.address().port;await new Promise(r=>s.close(r));return p;}
async function stop(){if(!child)return;const p=child;child=null;if(p.exitCode!==null)return;await new Promise(resolve=>{const t=setTimeout(()=>{p.kill('SIGKILL');resolve();},3000);p.once('exit',()=>{clearTimeout(t);resolve();});p.kill('SIGTERM');});}
async function start(){const p=await port();base=`http://127.0.0.1:${p}`;child=spawn(process.execPath,['src/server.mjs'],{cwd:process.cwd(),env:{...process.env,HOST:'127.0.0.1',PORT:String(p),CUSTODE_DATA_DIR:join(dir,'data')},stdio:['ignore','pipe','pipe']});child.stdout.on('data',s=>log+=s);child.stderr.on('data',s=>log+=s);for(let i=0;i<100;i++){if(child.exitCode!==null)throw Error(`Server exited: ${log}`);try{const r=await fetch(base+'/api/health',{signal:AbortSignal.timeout(1000)});if(r.ok&&(await r.json()).ok)return;}catch{}await new Promise(r=>setTimeout(r,100));}throw Error(`Server not ready: ${log}`);}
async function api(path,method='GET',body){const r=await fetch(base+path,{method,headers:body===undefined?{}:{'content-type':'application/json'},body:body===undefined?undefined:JSON.stringify(body),signal:AbortSignal.timeout(5000)});const raw=await r.text();let data;if(raw){try{data=JSON.parse(raw);}catch{throw Error(`${method} ${path}: expected JSON, got ${raw.slice(0,160)}`);}}return {status:r.status,data};}
async function good(path,method='GET',body,status){const r=await api(path,method,body);if(status)assert.equal(r.status,status,JSON.stringify(r));else assert.ok(r.status>=200&&r.status<300,JSON.stringify(r));return r.data;}
async function bad(path,method,body,status){const r=await api(path,method,body);assert.ok(r.status>=400&&r.status<500,JSON.stringify(r));if(status)assert.equal(r.status,status);assert.equal(typeof r.data.error,'string');return r;}
const item=(name,more={})=>({name,category:'Casa',location:'Cucina',notes:'',...more});
async function inventory(){
  assert.deepEqual(await good('/api/items'),[]);passed('empty inventory');
  const a=await good('/api/items','POST',item('Caffè <img src=x onerror=alert(1)>',{notes:'Filtro Ω_日本語'}),201);
  assert.equal(typeof a.id,'string');assert.ok(a.id);assert.equal(a.name,'Caffè <img src=x onerror=alert(1)>');assert.ok(Number.isFinite(Date.parse(a.createdAt)));assert.ok(Number.isFinite(Date.parse(a.updatedAt)));
  const b=await good('/api/items','POST',{name:'Trapano'},201);assert.notEqual(a.id,b.id);assert.equal(b.notes,'');passed('stable identifiers, defaults and literal Unicode');
  for(const payload of [{name:' '},{name:3},{name:'x'.repeat(201)},{name:'x',notes:[]},{name:'x',surprise:1}])await bad('/api/items','POST',payload);
  assert.equal((await good('/api/items')).length,2);passed('invalid writes leave inventory unchanged');
  const changed=await good('/api/items/'+encodeURIComponent(a.id),'PATCH',{location:'Garage'});assert.equal(changed.name,a.name);assert.equal(changed.location,'Garage');assert.equal(changed.id,a.id);
  await bad('/api/items/'+a.id,'PATCH',{name:''});assert.equal((await good('/api/items')).find(x=>x.id===a.id).name,a.name);passed('partial updates preserve fields');
  for(const query of ['q=filtro','q=%E6%97%A5%E6%9C%AC','q=garage','category=casa&location=GARAGE'])assert.deepEqual((await good('/api/items?'+query)).map(x=>x.id),[a.id]);
  assert.equal((await good('/api/items?q=missing')).length,0);passed('combined case-insensitive search');
  await bad('/api/items/no-such-id','PATCH',{name:'x'},404);await bad('/api/items/no-such-id','DELETE',undefined,404);
  const malformed=await fetch(base+'/api/items',{method:'POST',headers:{'content-type':'application/json'},body:'{"name":',signal:AbortSignal.timeout(5000)});assert.ok(malformed.status>=400&&malformed.status<500);passed('missing records and malformed JSON handled');
  await stop();await start();const persisted=await good('/api/items');assert.deepEqual(persisted.map(x=>x.id).sort(),[a.id,b.id].sort());assert.equal(persisted.find(x=>x.id===a.id).notes,'Filtro Ω_日本語');passed('real process restart preserves data');
  await good('/api/items/'+b.id,'DELETE');assert.equal((await good('/api/items')).length,1);passed('deletion persists');
}
async function maintenance(){
  const a=await good('/api/items','POST',item('Caldaia'),201);
  const payload={itemId:a.id,title:'Pulire filtro',dueDate:'2028-02-28',intervalDays:2,notes:'Acqua e sapone'};
  const t=await good('/api/tasks','POST',payload,201);assert.equal(t.completed,false);assert.equal(t.itemId,a.id);
  for(const patch of [{dueDate:'2028-02-30'},{dueDate:'2027-02-29'},{intervalDays:1.5},{intervalDays:-1},{itemId:'missing'},{title:' '},{unexpected:1}])await bad('/api/tasks','POST',{...payload,...patch});
  assert.equal((await good('/api/tasks')).length,1);passed('task references, civil dates, recurrence validation');
  await bad('/api/items/'+a.id,'DELETE',undefined,409);assert.equal((await good('/api/tasks')).length,1);passed('linked item deletion cannot silently lose maintenance');
  await good('/api/tasks/'+t.id,'PATCH',{notes:'Filtro annuale'});assert.equal((await good('/api/tasks')).find(x=>x.id===t.id).title,t.title);
  await good('/api/tasks/'+t.id+'/complete','POST',{completedOn:'2028-02-28'});let current=(await good('/api/tasks')).find(x=>x.id===t.id);assert.equal(current.dueDate,'2028-03-01');assert.equal(current.completed,false);
  let h=await good('/api/history');assert.equal(h.length,1);assert.equal(h[0].taskId,t.id);assert.equal(h[0].completedOn,'2028-02-28');passed('recurrence crosses leap day and saves history');
  const one=await good('/api/tasks','POST',{...payload,title:'Sostituire guarnizione',intervalDays:0,dueDate:'2028-03-01'},201);
  await good('/api/tasks/'+one.id+'/complete','POST',{completedOn:'2028-03-01'});await bad('/api/tasks/'+one.id+'/complete','POST',{completedOn:'2028-03-01'},409);
  await bad('/api/tasks/'+t.id+'/complete','POST',{completedOn:'2028-04-31'});assert.equal((await good('/api/history')).length,2);passed('one-off completion is single and invalid completion is atomic');
  for(const [title,date] of [['Scaduto','2028-02-27'],['Oggi','2028-02-28'],['Tra trenta giorni','2028-03-29'],['Tra trentuno giorni','2028-03-30']])await good('/api/tasks','POST',{...payload,title,dueDate:date,intervalDays:0},201);
  const summary=await good('/api/overview?today=2028-02-28');assert.equal(summary.overdue,1);assert.equal(summary.today,1);assert.equal(summary.upcoming,2);assert.equal(summary.tasks.length,5);assert.deepEqual(summary.tasks.map(t=>t.dueDate),summary.tasks.map(t=>t.dueDate).sort());
  await bad('/api/overview?today=2028-02-30','GET');passed('due summary counts active dates at exact 30-day boundary');
  await stop();await start();h=await good('/api/history');assert.equal(h.length,2);assert.equal((await good('/api/tasks')).length,6);passed('tasks and completion history survive restart');
}
async function backup(){
  const a=await good('/api/items','POST',item('Lampada Ω'),201);
  const t=await good('/api/tasks','POST',{itemId:a.id,title:'Controllare <cavo>',dueDate:'2030-12-31',intervalDays:1,notes:'安全'},201);
  await good('/api/tasks/'+t.id+'/complete','POST',{completedOn:'2030-12-31'});
  const b=await good('/api/backup');assert.equal(b.schemaVersion,1);assert.equal(b.items.length,1);assert.equal(b.history.length,1);
  await good('/api/items','POST',item('Da sostituire'),201);await good('/api/restore','POST',{backup:b,mode:'replace'});
  assert.deepEqual(await good('/api/backup'),b);passed('backup restore round-trip preserves exact identities and dates');
  for(const corrupt of [
    {...b,schemaVersion:2}, {...b,items:[...b.items,b.items[0]]}, {...b,tasks:[{...b.tasks[0],itemId:'dangling'}]},
    {...b,history:[{...b.history[0],taskId:'dangling'}]}, {...b,tasks:[{...b.tasks[0],dueDate:'2030-02-30'}]},
    {...b,items:[{...b.items[0],name:9}]}, {...b,history:'bad'}, {...b,tasks:[{...b.tasks[0],intervalDays:0.5}]}
  ]){await bad('/api/restore','POST',{backup:corrupt,mode:'replace'});assert.deepEqual(await good('/api/backup'),b);}
  await bad('/api/restore','POST',{backup:b,mode:'append'});assert.deepEqual(await good('/api/backup'),b);passed('malformed, duplicate and dangling backups never partially overwrite');
  const oversized=await fetch(base+'/api/restore',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({x:'a'.repeat(2*1024*1024+100)}),signal:AbortSignal.timeout(5000)});assert.ok(oversized.status>=400&&oversized.status<500);
  assert.deepEqual(await good('/api/backup'),b);await stop();await start();assert.deepEqual(await good('/api/backup'),b);passed('bounded HTTP input and restored data durable after restart');
  const readme=await readFile('README.md','utf8');for(const term of [/npm start/,/CUSTODE_DATA_DIR/,/backup/i,/ripristin/i,/127\.0\.0\.1/])assert.match(readme,term);passed('operator guide explains actual launch and data recovery');
}
async function browserTest(feature){
  const {chromium}=await import(trial+'/runtime/node_modules/playwright/index.mjs');
  browser=await chromium.launch({channel:'chrome',headless:true});
  const context=await browser.newContext({viewport:{width:1440,height:1000},locale:'it-IT'});const page=await context.newPage();page.setDefaultTimeout(10000);
  const errors=[];const remote=[];page.on('pageerror',e=>errors.push(e.message));context.on('request',r=>{if(/^https?:/.test(r.url())&&!r.url().startsWith(base+'/'))remote.push(r.url());});
  await page.goto(base);await page.getByRole('heading',{name:'Custode',exact:true}).waitFor();
  const fillItem=async(name)=>{await page.getByRole('button',{name:'Nuovo oggetto',exact:true}).click();await page.getByLabel('Nome oggetto',{exact:true}).fill(name);await page.getByLabel('Categoria',{exact:true}).fill('Cucina');await page.getByLabel('Posizione',{exact:true}).fill('Casa');await page.getByLabel('Note',{exact:true}).fill('Filtro Ω');await page.getByRole('button',{name:'Salva oggetto',exact:true}).click();await page.getByRole('button',{name:'Modifica '+name,exact:true}).waitFor();};
  await fillItem('Macchina del caffè');await fillItem('Trapano');
  await page.getByLabel('Cerca oggetti',{exact:true}).fill('caffè');await page.getByRole('button',{name:'Modifica Macchina del caffè',exact:true}).waitFor();await page.getByRole('button',{name:'Modifica Trapano',exact:true}).waitFor({state:'hidden'});
  await page.getByLabel('Cerca oggetti',{exact:true}).fill('');await page.getByRole('button',{name:'Modifica Trapano',exact:true}).click();await page.getByLabel('Posizione',{exact:true}).fill('Garage');await page.getByRole('button',{name:'Salva oggetto',exact:true}).click();
  await page.reload();await page.getByRole('button',{name:'Modifica Trapano',exact:true}).waitFor();assert.equal((await good('/api/items')).find(x=>x.name==='Trapano').location,'Garage');passed('browser creates, searches, edits and reloads real inventory');
  if(feature==='maintenance-ui'||feature==='backup-ui'){
    await page.getByRole('button',{name:'Manutenzioni',exact:true}).click();await page.getByRole('button',{name:'Nuovo intervento',exact:true}).click();await page.getByLabel('Titolo intervento',{exact:true}).fill('Cambiare filtro');const coffee=(await good('/api/items')).find(x=>x.name==='Macchina del caffè');await page.getByLabel('Oggetto',{exact:true}).selectOption(coffee.id);await page.getByLabel('Scadenza',{exact:true}).fill('2026-10-20');await page.getByLabel('Ripeti ogni (giorni)',{exact:true}).fill('30');await page.getByLabel('Note intervento',{exact:true}).fill('Usare ricambio lavabile');await page.getByRole('button',{name:'Salva intervento',exact:true}).click();await page.getByRole('button',{name:'Completa Cambiare filtro',exact:true}).click();await page.getByLabel('Data completamento',{exact:true}).fill('2026-10-20');await page.getByRole('button',{name:'Conferma completamento',exact:true}).click();await page.getByRole('heading',{name:'Storico',exact:true}).waitFor();
    await page.waitForFunction(async()=>{const r=await fetch('/api/history');return (await r.json()).length===1;});assert.equal((await good('/api/tasks'))[0].dueDate,'2026-11-19');passed('browser schedules, completes, advances recurrence and shows history');
  }
  if(feature==='backup-ui'){
    await page.getByRole('button',{name:'Backup',exact:true}).click();const before=await good('/api/backup');const downloaded=page.waitForEvent('download');await page.getByRole('button',{name:'Scarica backup',exact:true}).click();const download=await downloaded;const saved=join(dir,'download.json');await download.saveAs(saved);assert.deepEqual(JSON.parse(await readFile(saved,'utf8')),before);
    await good('/api/items','POST',item('Temporaneo'),201);await page.getByLabel('File backup',{exact:true}).setInputFiles(saved);await page.getByRole('button',{name:'Ripristina backup',exact:true}).click();assert.equal((await good('/api/items')).length,3);const consent=page.getByLabel('Confermo la sostituzione dei dati',{exact:true});await consent.check();await page.getByRole('button',{name:'Conferma ripristino',exact:true}).click();await page.waitForFunction(async()=>{const r=await fetch('/api/items');return (await r.json()).length===2;});assert.deepEqual(await good('/api/backup'),before);passed('browser downloads and requires explicit consent before restoring');
  }
  const screens=join(trial,'evidence','screens',basename(process.cwd()));await mkdir(screens,{recursive:true});
  await page.screenshot({path:join(screens,feature+'-desktop.png'),fullPage:true});
  await page.setViewportSize({width:390,height:844});await page.reload();await page.getByRole('heading',{name:'Custode',exact:true}).waitFor();await page.getByRole('button',{name:'Oggetti',exact:true}).click();await page.getByRole('button',{name:'Nuovo oggetto',exact:true}).waitFor();assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));await page.screenshot({path:join(screens,feature+'-mobile.png'),fullPage:true});
  assert.deepEqual(errors,[]);assert.deepEqual(remote,[]);passed('390px layout, no page errors, no remote resources');await context.close();await browser.close();browser=null;
}
try{
  await start();
  if(mode==='all'||mode==='inventory')await inventory();
  if(mode==='all'||mode==='inventory-ui')await browserTest('inventory-ui');
  if(mode==='all'||mode==='maintenance')await maintenance();
  if(mode==='all'||mode==='maintenance-ui')await browserTest('maintenance-ui');
  if(mode==='all'||mode==='backup')await backup();
  if(mode==='all'||mode==='backup-ui')await browserTest('backup-ui');
  console.log(JSON.stringify({result:'passed',mode,groups,worktree:process.cwd(),at:new Date().toISOString()}));
}catch(e){console.error(e.stack);console.error(log.slice(-5000));process.exitCode=1;}
finally{if(browser)await browser.close();await stop();await rm(dir,{recursive:true,force:true});}
