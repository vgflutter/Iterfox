# Programmazione, completamento e storico delle manutenzioni

L’interfaccia offre navigazione Manutenzioni, creazione, modifica, eliminazione
con conferma, panoramica, completamento e storico. L’interfaccia di backup e
ripristino è descritta in [ui-backup.md](ui-backup.md); le API sono documentate
in [api-backup.md](api-backup.md).

Scelte provvisorie e reversibili:

- Panoramica a schede ordinate per data, senza calendario grafico. Legge
  `/api/overview` e l’inventario completo; non utilizza i risultati della ricerca.
  Il giorno locale del browser è inviato esplicitamente come `today` e mostrato
  accanto ai conteggi. Le date civili sono validate senza parser permissivo e
  visualizzate senza conversioni di fuso. Il limite dei 30 giorni usa giorni UTC
  interi per non variare con l’ora legale, anche negli anni da 0001 a 0099.
- Nessuna preselezione arbitraria dell’oggetto. Il select ha un segnaposto e
  mostra nome, categoria e posizione, con identificativo come valore. Ogni
  apertura rilegge `/api/items`, senza filtri; il fallimento ha un recupero
  dedicato. Un oggetto scomparso dalla bozza viene segnalato e non sostituito.
- Titolo e note mantengono il testo letterale, con limiti Unicode uguali all’API.
  Scadenza obbligatoria e intervallo intero 0–3660; stringhe vuote non diventano
  implicitamente zero. Il POST converte soltanto l’intervallo in numero.
- Dialogo nativo con etichette del brief, errori associati ai campi, focus sul
  primo campo invalido e ritorno al comando d’origine o al titolo dell’elenco.
  Durante salvataggio o verifica di creazione campi e chiusura sono bloccati.
  La bozza resta nella pagina dopo Annulla o errori e si svuota dopo una risposta
  di POST valida; un ripristino confermato la scarta con le bozze precedenti.
- Stati distinti per caricamento, inventario senza oggetti, nessun intervento
  attivo e lettura fallita. Le letture hanno un limite di dieci secondi e un
  contatore contro le risposte obsolete. In caricamento o errore, i conteggi
  mostrano trattini e le vecchie schede sono nascoste. Non si interpretano gli
  errori come archivi vuoti né si mostrano scadenze superate come correnti.
- Salvataggio e ricaricamento hanno esiti separati: dopo conferma si svuota
  la bozza e si rilegge la panoramica; se la lettura fallisce, il messaggio
  ricorda che l’intervento è già salvato e propone solo la rilettura. Nessuna
  scrittura viene ripetuta automaticamente.
- Dopo una creazione non confermata, **Salva intervento** resta disabilitato.
  **Rileggi tutti gli interventi** legge `GET /api/tasks` e `GET /api/items`
  senza filtri, mostra nel dialogo gli interventi attuali inclusi i conclusi
  e avvia l’aggiornamento di panoramica e storico. Titolo, oggetto, categoria,
  posizione, scadenza, ricorrenza, stato e note aiutano a confrontare la bozza.
  Il comando esegue soltanto letture e non sostituisce i campi compilati.
  Una verifica riuscita permette un nuovo invio esplicito, se anche il menu
  Oggetto è pronto; se l’intervento è presente, scegliere Annulla. Un errore
  mantiene bozza e blocco e permette di ripetere la verifica. Il blocco ancora
  da risolvere resta chiudendo e riaprendo il nuovo modulo, anche dopo una
  modifica separata. Aggiorna manutenzioni e Riprova caricamento oggetti
  non sostituiscono questa verifica. I rifiuti di validazione `400` permettono
  invece la correzione, compreso il recupero del menu per un oggetto rimosso.
  L’elenco riletto è raggiungibile da tastiera; avanzamento ed errori ricevono
  il focus. È una fotografia senza interventi eliminati, non la prova di quale
  richiesta abbia creato un record simile né una garanzia contro duplicati tra
  finestre. Ricaricare la pagina perde bozza e stato di recupero.
- `Modifica <titolo>` riutilizza il modulo precompilato; l’inventario completo
  viene riletto a ogni apertura. Il PATCH contiene solo i campi cambiati rispetto
  ai valori visualizzati, preservando testo letterale non modificato anche con
  normalizzazioni dei controlli (a capo negli input, CRLF nelle textarea).
  L’intervallo viene confrontato come numero, mantenendo vuoto e valori invalidi
  da correggere. Un invio senza cambiamenti fa solo una rilettura. La bozza del
  nuovo intervento resta separata: annullare una modifica la scarta senza
  contaminare quella nuova. Gli errori conservano i valori nel modulo; un
  oggetto rimosso si può ricaricare senza perdere gli altri campi.
- Modifica ed eliminazione inviano `If-Match` con la versione `updatedAt` letta;
  il controllo sul server è atomico. Un cambiamento o completamento concorrente
  produce `409`, una rimozione produce `404`: il modulo non usa mai POST come
  ripiego. Le risposte incerte e i conflitti bloccano ulteriori conferme nel
  dialogo. `Scarta modifiche e rileggi` chiude il modulo scartando i valori di
  modifica; `Rileggi interventi e storico` chiude la conferma di eliminazione.
  I comandi eseguono solo GET; si riapre poi l’azione sui dati riletti.
- `Elimina <titolo>` apre un dialogo che descrive la conservazione dello storico
  e la protezione degli oggetti con legami attuali o storici. Focus iniziale su
  Annulla; solo `Conferma eliminazione` invia DELETE. Nessuna rimozione anticipata
  delle schede. Invio doppio, chiusura ed Esc sono bloccati durante la scrittura;
  una risposta valida chiude il dialogo e rilegge entrambe le sezioni. Errori e
  conflitti mantengono il dialogo aperto e rendono disponibile la sola rilettura.
- Gli interventi conclusi conservano Modifica ed Elimina nella scheda dello
  Storico più recente, una sola volta per intervento anche se prima era
  ricorrente, senza poter essere riaperti o completati di nuovo. Lo storico mostra
  il titolo al completamento e, dopo una rinomina, anche quello attuale. Rinomine,
  cambio oggetto e ricorrenza non riscrivono gli eventi; eliminare l’intervento
  lascia gli eventi consultabili con lo stato di intervento rimosso.
- Ogni scheda attiva offre `Completa <titolo>`. Il dialogo usa le etichette
  `Data completamento` e `Conferma completamento`; propone oggi locale e
  descrive l’effetto una tantum o ricorrente. Anteprima della prossima scadenza
  e validazione usano giorni civili, inclusi anni bassi, bisestili e limite 9999.
  La data scelta resta per identificativo nella pagina dopo annullamento o
  errore e si svuota dopo una risposta di completamento valida. Invio, chiusura
  ed Esc sono bloccati durante il POST; nessun handler ritenta la scrittura.
  Anche questo POST invia `If-Match`: una modifica o un completamento successivo
  alla lettura rifiuta atomicamente la scrittura con `409`, senza registrare
  eventi con una ricorrenza diversa da quella descritta nel dialogo.
- Risposte di completamento incerte (rete, timeout, server, JSON inatteso) e
  conflitti 404/409 bloccano una nuova conferma per quell’identificativo.
  `Verifica scadenze e storico` esegue solo letture e porta il focus allo storico.
  Il blocco si rimuove dopo il caricamento completo riuscito. Non è idempotenza
  dell’API: dopo aver controllato i dati l’utente può confermare intenzionalmente
  un’altra attività, che per i ricorrenti crea un altro evento anche nello stesso
  giorno. Un errore 400 mantiene la data e consente la correzione.
- Lo Storico è una sezione sempre presente nella vista, con stato vuoto,
  caricamento, conteggio ed errore dedicato. Gli eventi leggono `/api/history`;
  `/api/tasks` distingue una tantum conclusi, ricorrenti attivi e interventi
  rimossi. Titolo e itemId sono quelli dell’evento; nome dell’oggetto, stato e
  scadenza attuale provengono dai dati correnti. L’ordine è per completedOn
  decrescente, mantenendo quello dell’API a parità di data. Testi letterali via
  textContent e date tramite elementi time. Nessun evento viene fabbricato
  localmente o rimosso insieme alle schede attive.
- Una generazione di lettura recupera panoramica, inventario completo,
  interventi e storico, con limite di dieci secondi. Le due sezioni mostrano
  errori indipendenti: se una lettura fallisce, l’altra può rimanere utilizzabile.
  Dopo un POST confermato, gli avvisi ricordano che la scrittura è già avvenuta;
  Riprova, Riprova storico e Aggiorna manutenzioni inviano soltanto GET.
- Il focus dopo annullamento torna al comando d’origine, o al suo sostituto
  dopo una rilettura. Dopo completamento confermato va al titolo delle scadenze,
  senza tornare al pulsante Completa. Nessuna risposta tardiva sottrae il focus
  al dialogo o alla sezione raggiunta nel frattempo.
- Il cambio di sezione nasconde le viste senza ricostruire moduli e ricerca.
  Al ritorno si rilegge l’elenco attuale, senza perdere filtro e bozze. Le
  risposte di una sezione abbandonata vengono invalidate e non spostano il focus.
- Stessi componenti visivi dell’inventario: griglie comprimibili, testi a capo,
  select limitato alla larghezza disponibile, controlli alti almeno 44px e
  dialogo con scorrimento. Stato delle scadenze scritto in parole oltre al colore.

Backup JSON e ripristino sono disponibili, con riepilogo e consenso esplicito:
vedi [ui-backup.md](ui-backup.md). Dopo un ripristino confermato vengono invalidate
le letture precedenti, scartate schede, ricerca, bozze e stati di recupero e
riletti inventario, scadenze e storico. Eventuali errori di lettura non annullano
la sostituzione.

Nessun dato viene aggiunto all’avvio.

## Osservazioni storiche sui controlli locali

I controlli riportati qui provengono dalla documentazione del candidato
preservato: non sono nuove esecuzioni o prove host di questo recupero.
I controlli locali su sintassi, struttura
e DOM simulato non osservano rendering, tastiera o annunci reali del browser.
Il DOM simulato è stato collegato al gestore HTTP reale e a SQLite temporaneo:
programmazione, inventario completo durante la ricerca, conservazione delle due
bozze, errori di validazione, invii duplicati, scadenze e conteggi, limite dei
30 giorni, errori di caricamento, ricarica fallita dopo un POST confermato e
risposte obsolete hanno superato i controlli mirati. Le date civili sono state
confrontate con la validazione del backend, inclusi anni bassi e secoli bisestili.
L’archivio di verifica è stato rimosso; nessun dato utente è stato creato.

Per completamento e storico sono passati controlli locali mirati con il gestore
HTTP reale e SQLite temporaneo: avanzamento bisestile, una tantum che esce dalle
scadenze, conteggi, titoli letterali, collegamenti storici, conservazione dopo
riapertura dell’archivio, invii duplicati e chiusura durante il POST, errori di
data, letture fallite dopo conferma, risposta persa dopo scrittura, conflitti
404/409, focus e risposte obsolete. Anche ricerca e bozza del nuovo oggetto sono
state conservate durante il passaggio tra sezioni. Verificati i riferimenti
ARIA statici; nessun dato dimostrativo o archivio utente creato.

Per i risultati correnti consultare le ricevute dei sei controlli host elencati
nel [README](../README.md), riferite alla versione in uso. La revisione AI del
sorgente usa la stessa integrazione Codex e non è indipendente.
Questi controlli locali storici non osservano browser reale, layout a 390px,
annunci assistivi o riavvio del processo e non ne dichiarano il superamento.

Per modifica ed eliminazione sono passati controlli mirati con DOM simulato,
gestore HTTP reale e archivio SQLite temporaneo: precompilazione, PATCH parziali,
testo letterale, bozze separate, azioni sugli interventi conclusi, validazione,
conflitti di versione atomici, rimozione da un’altra finestra, annullamento,
blocco degli invii duplicati, conservazione degli eventi, risposte perse dopo
scrittura e letture fallite dopo conferma. Lo storico è rimasto identico dopo
riapertura dell’archivio. Sono verifiche in processo, senza browser o listener;
non sostituiscono le prove host richieste. Nessun archivio utente o dato
dimostrativo creato; l’archivio temporaneo di verifica è stato rimosso.

## Osservazioni storiche sull’integrazione

La documentazione precedente riporta l’esame delle quattro schermate host
`inventory-ui-desktop.png`, `inventory-ui-mobile.png`, `maintenance-ui-desktop.png` e
`maintenance-ui-mobile.png` del worktree `20261020T152604-46b3d576`.
Non sono catture di questa missione né prove aggiornate del recupero.
La vista desktop mostra conteggi, scadenze e storico coerenti, con azioni
distinte. Entrambe le catture mobile mostrano l’inventario: il controllo host
torna a Oggetti dopo il reload, quindi queste immagini non osservano i dialoghi
e le manutenzioni a 390px. Le catture precedono le correzioni di integrazione.

Scelte reversibili riportate dalla revisione precedente:

- Il cambio di sezione porta il focus al relativo titolo; un clic sulla sezione
  già aperta mantiene il focus sul pulsante. La pagina evita così uno spostamento
  superfluo su tutto il contenuto. Il salto al contenuto trasferisce esplicitamente
  il focus a main; il collegamento resta fuori vista, anche con testo ingrandito,
  fino a quando riceve il focus. Nelle catture mobile il collegamento di salto
  e il bordo di main erano visibili: il rendering aggiornato richiede l’host.
- Una chiusura tardiva non sottrae il focus a un dialogo appena aperto o alla
  sezione raggiunta. Riaprire lo stesso modulo prima dell’evento di chiusura
  precedente non annulla il nuovo caricamento degli oggetti.
- Il select mantiene i controlli nativi per tastiera e tecnologie assistive.
  Il dettaglio associato sotto il campo mostra nome, categoria e posizione
  completi su più righe. Non si dipende dal tooltip per leggere testi lunghi.
  Caricamento, errori e valore selezionato sono associati al campo; un recupero
  riuscito torna al select solo se l’utente non ha spostato il focus nel frattempo.
- Il riepilogo accessibile degli attivi annuncia anche i tre conteggi; la data
  di riferimento descrive il gruppo dei conteggi. La distinzione delle scadenze
  continua a usare testo oltre al colore.
- Le scritture dell’inventario invalidano anche le letture pendenti di scadenze,
  storico e menu. Tornando a Manutenzioni si leggono nomi e posizioni correnti;
  ricerca e bozze indipendenti rimangono nella pagina. Gli aggiornamenti di
  un’altra finestra richiedono ritorno alla sezione o aggiornamento esplicito.
- README comprende uso da tastiera, aggiornamento tra sezioni, date civili,
  ricorrenze, storico, conflitti, cartella persistente e copia manuale a servizio
  fermo.

Passati controlli mirati con DOM simulato, gestore HTTP in processo e SQLite
temporaneo: ricerca e bozze indipendenti nella navigazione, rinomina e posizione
aggiornate nelle scadenze e nel select, letture tardive da entrambe le sezioni,
recupero del menu, selezione scomparsa, chiusura e riapertura ravvicinate, testi
lunghi letterali e riferimenti ARIA. Verificati inoltre il rifiuto atomico di
completamenti su versioni superate, la compatibilità delle API senza precondizione
e la conservazione dello storico dopo la riapertura del database. Nessun listener,
browser o dato dimostrativo; archivio temporaneo rimosso. Sono controlli in
processo: rendering a 390px, tastiera nativa, zoom, annunci assistivi e riavvio
del processo richiedono nuova osservazione host.
