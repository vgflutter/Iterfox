# Backup e conferma di ripristino

La navigazione **Backup** apre una sezione con due azioni separate. Scaricare
o selezionare un file non invia richieste di sostituzione. Non vengono creati
dati dimostrativi. L’API e il formato completo sono descritti in
[api-backup.md](api-backup.md); i passaggi d’uso sono nel [README](../README.md).

Scelte reversibili dell’interfaccia:

- **Scarica backup** legge `/api/backup` senza cache. Dopo aver controllato il
  contenitore, offre i byte della risposta originale come download JSON: niente
  filtri, troncamenti o nuova serializzazione del file scaricato. Il nome
  `custode-backup-AAAA-MM-GG.json` usa il giorno locale e non incorpora nomi
  dell’archivio o intestazioni importate. Il messaggio dice «Download avviato»:
  la pagina non può verificare il salvataggio del browser. Un errore mantiene
  disponibile il pulsante per riprovare; durante il download gli invii duplicati
  sono bloccati.
- **File backup** usa un input nativo. L’estensione suggerita non è una prova
  di validità. Il file viene letto come UTF-8 rigoroso e interpretato come JSON;
  si controllano versione 1, contenitore e presenza dei tre array di record.
  I conteggi sono un’anteprima, non la validazione integrale: campi, riferimenti,
  date e duplicati rimangono responsabilità del servizio prima della scrittura.
  I nomi file appaiono soltanto tramite `textContent`, con testo a capo anche
  per nomi molto lunghi o contenenti markup. Non sono usati come URL o percorsi.
- La richiesta `{backup,mode:'replace'}` viene preparata durante la lettura.
  Si misura la sua dimensione UTF-8 completa, inclusi involucro e caratteri
  che richiedono escape JSON. La pagina rifiuta anche file sorgente oltre 2 MiB
  senza caricarli in memoria. File illeggibili, UTF-8 o JSON invalidi, versioni
  sconosciute e richieste troppo grandi non producono POST. Il download non ha
  questo limite e avvisa quando l’archivio richiede una copia della cartella dati
  a servizio fermo. I file originali non vengono modificati.
- Il cambio file invalida subito la selezione precedente; una lettura tardiva
  non può riproporre il vecchio file. **Rimuovi file** cancella la selezione e
  torna al controllo File backup. Un errore lascia utilizzabile il selettore.
- **Ripristina backup** apre un dialogo nativo con nome del file, tre conteggi,
  avviso di sostituzione totale e perdita delle bozze. È esplicito anche che un
  backup vuoto svuota l’archivio. Il focus iniziale è su **Annulla**.
  **Conferma ripristino** è disabilitato fino alla selezione della casella
  **Confermo la sostituzione dei dati**. Anche il gestore del submit richiede
  casella selezionata, dialogo aperto e file pronto. Il consenso viene azzerato
  a ogni apertura e chiusura. Solo questo submit invia il POST.
- **Annulla**, chiusura ed `Esc` conservano il file senza scrivere e riportano
  il focus al comando d’origine, oppure al titolo se il comando non è più
  utilizzabile. Il dialogo mantiene il comportamento nativo di Tab e Shift+Tab.
  Durante il POST, controlli, chiusura ed `Esc` sono bloccati; un indicatore
  riceve il focus e gli invii duplicati vengono ignorati.
- Gli errori restano leggibili nel dialogo e, alla chiusura, accanto al file.
  I rifiuti di validazione sono distinti da risposte incerte. La stessa selezione
  non può essere reinviata dopo un errore: per un file rifiutato occorre rimuoverlo
  e scegliere una copia valida. Dopo una risposta incerta occorre prima scaricare
  lo stato corrente e controllare Oggetti, scadenze e Storico. La selezione può
  essere rimossa e ripetuta intenzionalmente dopo il controllo; non ci sono
  reinvii o ripristini automatici.
- Dopo `{"ok":true}` vengono invalidati i caricamenti precedenti e rimossi i
  vecchi elenchi, selezioni, ricerca, bozze e stati di recupero delle creazioni
  non confermate. Inventario, scadenze e storico vengono riletti.
  L’esito di scrittura rimane confermato anche se una lettura
  successiva fallisce: nelle sezioni i controlli Riprova effettuano soltanto GET.
- Griglia a due colonne sui desktop larghi, una colonna sotto 1100px; a 390px
  azioni su righe separate, testi e nomi a capo, input limitati al contenitore.
  Dialogo con altezza massima rispetto alla finestra e scorrimento interno,
  controlli da almeno 44px e intera etichetta della casella selezionabile.

Le osservazioni che seguono sono storiche, riportate dalla documentazione del
candidato preservato; non sono nuove esecuzioni di questo recupero.
Controlli mirati locali: DOM simulato collegato al gestore HTTP reale e a SQLite
temporaneo, senza listener o browser. Esercitati download completo esatto
(compresi record eliminati e storico), file con nome contenente markup, lettura
senza scritture, riepilogo, consenso, annullamento, guardie di `Esc` e invii
duplicati, file illeggibili/invalidi, limite della richiesta completa, letture
obsolete, rifiuto server, risposta incerta e ricarica fallita dopo successo.
Controllati anche riferimenti ARIA e identificativi HTML univoci. I dati di
verifica sono stati rimossi; nessun archivio utente è stato popolato.

Questi controlli non osservano rendering reale, download nativo, Tab, focus
nativo o annunci assistivi. Per il rendering, i download e il layout Backup
anche a 390px consultare le prove del browser riferite alla versione in uso e
le ricevute host elencate nel [README](../README.md). La revisione AI del sorgente
è della stessa integrazione Codex e non è indipendente. Gli annunci assistivi
richiedono una verifica specifica con screen reader.
