# Archivio e API manutenzioni

Il backend dell’esito 3 supporta programmazione, completamento e storico.
L’interfaccia di programmazione, modifica, eliminazione, panoramica, completamento
e storico è descritta in `ui-manutenzioni.md`. Le API di backup e ripristino
dell’esito 4 sono descritte in [api-backup.md](api-backup.md); la loro interfaccia
grafica è descritta in [ui-backup.md](ui-backup.md). Le rotte e le regole d’uso sono documentate nel README.

Scelte interne reversibili:

- Migrazione SQLite da `user_version=1` a `2`, con creazione di `tasks`,
  `history`, indici e versione nella stessa transazione. La tabella `items`
  non viene riscritta. Per un archivio nuovo tutte le tabelle nascono vuote
  in una singola transazione.
- Titolo e note sono codificati come stringhe JSON in SQLite, come i testi
  dell’inventario: anche NUL e surrogati UTF-16 isolati restano dati letterali.
  La rappresentazione HTTP è testo normale, senza trasformazioni.
- Campi modificabili espliciti; `completed`, identificativi e timestamp sono
  gestiti dal server. Il completamento è l’unico percorso che chiude un intervento.
  Cambiare un intervento concluso non lo riapre.
- Validazione dei campi prima della transazione; verifica dei riferimenti e
  della situazione corrente sotto `BEGIN IMMEDIATE`, prima delle scritture.
  Aggiornamenti e completamenti usano timestamp strettamente crescenti.
- PATCH, DELETE e completamento accettano la precondizione facoltativa `If-Match` con il valore
  `updatedAt` tra virgolette doppie. Il confronto e la scrittura sono nella
  stessa transazione: una versione superata risponde `409`, un intervento non
  più disponibile `404`. Nessuna richiesta fallita ricrea l’intervento o scrive
  dati parziali. Senza precondizione, le API mantengono il comportamento esistente;
  `*` controlla soltanto l’esistenza. L’interfaccia invia sempre la versione per
  modifica, eliminazione e completamento; anche un completamento concorrente la
  invalida. Questo evita di registrare un completamento con una ricorrenza diversa
  dall’anteprima mostrata nel dialogo, o di duplicarlo su una scheda superata.
- Date civili gregoriane da `0001-01-01` a `9999-12-31`; calcolo della ricorrenza
  con giorni UTC interi. Non si usa il parser permissivo delle date, né una
  somma di ore in ora locale. La data predefinita della panoramica è invece
  quella locale del processo. Il limite superiore della panoramica usa giorni
  numerici, quindi funziona anche negli ultimi 30 giorni dell’anno 9999.
- Lo storico fotografa titolo e oggetto al completamento. Rinomine e cambio
  dell’oggetto nell’intervento non riscrivono gli eventi passati. Lo storico è
  ordinato per data decrescente e, a parità, per ultima registrazione.
- Eliminare un intervento senza eventi lo rimuove fisicamente. Con eventi,
  `deleted=1` conserva la sua identità ma lo esclude da `/api/tasks` e dalle
  operazioni successive. Chiavi esterne restrittive proteggono tutti i legami,
  anche verso l’oggetto storico se l’intervento è stato ricollegato altrove.
  L’eliminazione di un oggetto con legami attuali o storici dà `409`.
  Il backup comprende anche questi record interni con `deleted:true`, mantenendo
  i riferimenti degli eventi senza riattivare l’intervento al ripristino.
- Le letture non applicano filtri dell’inventario agli interventi. La panoramica
  comprende tutti gli attivi ordinati per scadenza, anche fuori dai 30 giorni;
  solo il conteggio `upcoming` applica quel limite inclusivo.

Per questo recupero tutti e sei i controlli approvati elencati nel
[README](../README.md), inclusi `inventory`, `inventory-ui`, `maintenance` e
`maintenance-ui`, e la revisione indipendente del sorgente sono in attesa di nuovi
risultati del runtime. Le osservazioni locali ereditate sul gestore HTTP e sul
database temporaneo sono storiche e non provano listener, processo riavviato o
comportamento nel browser.
