# Percorsi dell’inventario

La pagina iniziale usa l’API esistente per elenco reale, creazione, ricerca,
modifica ed eliminazione. Non inserisce dati all’avvio.

Scelte reversibili per l’interfaccia:

- HTML, CSS e JavaScript senza dipendenze, font o richieste remote.
- Navigazione laterale su desktop e in alto sui telefoni; elenco a schede
  con testi a capo, senza nascondere nome, posizione o note lunghe.
- Modulo in un dialogo nativo, etichette esplicite, limiti in punti di codice
  Unicode, errori associati ai campi e ritorno del focus alla chiusura.
- Nessun `maxlength` nativo, che conterebbe unità UTF-16 e impedirebbe alcuni
  valori validi per l’API. Gli errori locali indicano limite e numero inserito;
  il nome composto solo da spazi è rifiutato come nell’API. Al primo invio
  invalido si mostra un riepilogo e si porta il focus al primo campo da
  correggere. Durante la correzione un campo ancora invalido resta segnalato;
  il riepilogo di validazione scompare quando tutti gli errori sono risolti.
- Gli errori di validazione testuali noti dell’API sono associati al rispettivo
  campo con `aria-invalid` e `aria-describedby`; gli altri errori restano
  generali. Riepiloghi di errore e stati di invio sono fuori dai moduli con
  `aria-busy`, dentro il dialogo attivo, per permetterne l’annuncio.
- La bozza di creazione rimane disponibile fino al salvataggio o alla ricarica
  della pagina, separata dai campi di modifica. Un invio in corso disabilita
  un secondo invio e la chiusura.
- Stati distinti di caricamento, archivio vuoto, ricerca senza risultati,
  elenco disponibile ed errore recuperabile.
  Salvataggio e ricaricamento hanno esiti separati. Aggiorna elenco rilegge
  l’elenco normale mantenendo il filtro; non sostituisce la verifica completa
  richiesta dopo una creazione incerta.
- Se un POST non è confermato, la bozza resta compilata e Salva oggetto viene
  bloccato. **Rileggi inventario completo** esegue `GET /api/items` senza filtri
  e mostra nel dialogo nomi, categorie, posizioni e note. Aggiorna anche l’elenco
  normale mantenendo la ricerca, senza usare la risposta completa come risultati
  filtrati. Non ripete la creazione né sostituisce i campi della bozza.
  Solo una lettura completa riuscita permette un altro invio esplicito; se
  l’oggetto è presente, scegliere Annulla. Un errore di lettura conserva il blocco
  e offre lo stesso comando per riprovare. Chiudere e riaprire il nuovo modulo,
  anche dopo una modifica separata, non aggira la verifica ancora necessaria.
  I rifiuti di validazione associati ai campi permettono invece la correzione.
  Durante la verifica campi e chiusura sono bloccati; avanzamento ed errori
  ricevono il focus e l’elenco completo è raggiungibile da tastiera.
  Il confronto spetta all’utente: la fotografia dell’archivio non identifica
  con certezza la richiesta che ha creato un oggetto simile e non impedisce
  duplicati tra finestre. Bozza e stato di recupero vivono solo nella pagina;
  una ricarica li perde, un ripristino confermato li scarta.
- Ricerca tramite `GET /api/items?q=...`, senza duplicare il filtro nel browser:
  nome, categoria, posizione e note seguono le regole già definite dall’API.
  Si conserva il testo esatto del filtro, inclusi Unicode, spazi e accenti;
  `URLSearchParams` codifica i caratteri speciali.
- Attesa di 200 ms mentre si scrive, ricerca immediata con Invio o cancellando
  il filtro. I testi composti tramite IME attendono la fine della composizione.
  Ogni cambiamento invalida subito le richieste precedenti, prima dell’attesa;
  un contatore protegge da risposte obsolete anche se l’annullamento arriva tardi.
- Durante una ricerca non si mostrano le vecchie schede come risultati del nuovo
  filtro. Un errore può conservare solo le schede dell’ultima risposta riuscita
  per lo stesso filtro, con un avviso e un conteggio «da aggiornare».
  Le letture che non rispondono entro 10 secondi vengono annullate e propongono
  Riprova, evitando un caricamento indefinito.
- Il conteggio filtrato è espresso in risultati; il badge della navigazione
  compare solo nell’elenco senza filtri, per non confonderlo con il totale.
  Gli aggiornamenti di stato sono annunciati fuori dalla regione `aria-busy`.
- Cancella ricerca e Mostra tutti gli oggetti riportano il focus al campo di
  ricerca. Nuovo oggetto resta disponibile durante ogni stato dell’elenco.
  Un salvataggio conserva il filtro e ricorda come ritornare all’elenco completo.
- Ogni scheda offre i pulsanti con nomi accessibili `Modifica <nome>` ed
  `Elimina <nome>`. La modifica precompila tutti i campi e invia tramite PATCH
  solo quelli cambiati, senza sovrascrivere campi lasciati invariati se un’altra
  finestra li ha aggiornati. Un salvataggio senza cambiamenti non invia richieste.
  Il confronto usa i valori inizialmente mostrati dal browser: i ritorni a capo
  normalizzati dai controlli non causano modifiche involontarie ai campi
  originali dell’API, se si cambia soltanto un altro campo.
  Annullare scarta le modifiche dell’oggetto; un errore conserva i valori nel
  modulo aperto e non si trasforma mai in una creazione automatica.
- L’eliminazione richiede un dialogo separato con nome letterale dell’oggetto,
  Annulla e Conferma eliminazione. Il focus iniziale è su Annulla; anche Esc
  e la chiusura annullano. Nessuna richiesta DELETE parte all’apertura.
  L’oggetto non viene rimosso dall’elenco prima della conferma del server.
  Sono accettate risposte DELETE 200 JSON con `ok:true` e 204 senza corpo;
  un JSON di successo inatteso non annuncia l’eliminazione.
- Risposte 404 e 409, errori dell’archivio e problemi di rete mantengono il
  dialogo aperto, con errore annunciato e possibilità di annullamento. Anche le
  scritture hanno un limite di attesa di 10 secondi: una creazione incerta
  richiede la verifica completa descritta sopra; per modifica ed eliminazione
  il messaggio invita a chiudere e aggiornare l’elenco, senza presumere che il
  server non abbia agito.
- Dopo una scrittura confermata viene ricaricato lo stesso filtro dall’API,
  invalidando le schede precedenti: un errore di questa lettura non ripropone
  oggetti eliminati o campi superati. L’esito della scrittura rimane distinto.
  Un errore della lettura ricorda esplicitamente che l’operazione è già stata
  confermata; la bozza viene svuotata solo dopo una risposta di scrittura valida.
  Annullando, il focus torna al comando d’origine o al corrispondente pulsante
  ricreato da una lettura concorrente; se scomparso, torna al titolo dell’elenco.
  Dopo salvataggio o eliminazione confermati torna al titolo dell’inventario,
  che rimane presente anche durante il ricaricamento delle schede.
- Il server espone le risorse web dichiarate nella mappa `publicRoutes` di
  `src/server.mjs`, verificando che la destinazione risolta rimanga in `public`;
  nessuna rotta generica verso il filesystem. `/` e `/index.html` mostrano
  la stessa pagina. Il database non è esposto via HTTP.

Manutenzioni è ora attiva; il cambio di sezione conserva filtro e bozza di
creazione dell’inventario. Il suo menu degli oggetti legge l’archivio completo,
separatamente dai risultati della ricerca. **Backup** è disponibile con download
completo e ripristino esplicitamente confermato, descritti in
[ui-backup.md](ui-backup.md). Il ripristino confermato invalida le letture
precedenti, scarta schede, ricerca, bozze e stati di recupero e rilegge inventario,
scadenze e storico; un errore di lettura successivo non annulla la sostituzione.
Una modifica degli oggetti invalida anche le letture pendenti delle manutenzioni;
il ritorno alla sezione rilegge nomi e posizioni senza riutilizzare il filtro.
La navigazione porta il focus al titolo della sezione scelta; un nuovo clic
sulla sezione attuale mantiene il focus sul pulsante. Il collegamento di salto
è nascosto usando la propria altezza e porta esplicitamente il focus a main.
Le chiusure tardive dei dialoghi non spostano il focus in una sezione abbandonata
o fuori da un altro dialogo già aperto.

## Osservazioni storiche su layout e tastiera

La documentazione ereditata cita l’esame delle schermate host
`inventory-ui-desktop.png` e `inventory-ui-mobile.png`, precedenti a questo
recupero: riporta barra laterale su desktop e navigazione in alto a 390 px.
Non sono catture di questa missione e non verificano il prodotto attuale.
Anche i controlli locali descritti sotto sono osservazioni storiche del candidato
preservato, non nuove esecuzioni né risultati host di questo recupero.

Scelte reversibili riportate dalla revisione precedente:

- Stessa gerarchia su entrambi i formati: azione principale, ricerca, conteggio
  ed elenco; etichette delle schede, suggerimenti, disponibilità e footer più
  grandi, senza ridurre ulteriormente il testo sul telefono.
- Testi secondari con contrasto calcolato di almeno 4,5:1; bordi dei campi e dei
  pulsanti secondari di almeno 3:1. Il bordo di focus ha contrasto 5:1 sul fondo
  dei dialoghi. In modalità colori forzati usa il colore di sistema Highlight.
- Griglie con colonne comprimibili, testo a capo anche senza spazi, azioni
  dei dialoghi e intestazione dell’elenco su più righe quando necessario.
  A 360 px e meno la navigazione dispone l’icona sopra il testo, i dettagli
  delle schede sono su una colonna e la ricerca può andare su due righe.
  Nessun taglio dei dati o mascheramento dello scorrimento orizzontale.
- Controlli di almeno 44 px di altezza. Dialoghi entro la larghezza e l’altezza
  disponibili, con scorrimento verticale interno per telefono e schermi bassi.
- Dialoghi nativi per mantenere Tab e Maiusc+Tab nel modulo attivo, con il resto
  della pagina inerte. Apertura sul nome per creare/modificare, su Annulla per
  eliminare; chiusura o Esc annullano, salvo durante una richiesta in corso.
  Il modulo riparte dall’inizio del contenuto quando viene riaperto.
- Durante le scritture il focus va al messaggio di avanzamento, fuori dal form
  occupato. Gli errori riportano il focus al campo o all’avviso da correggere.
  Il focus è visibile anche quando spostato via codice al titolo dell’elenco,
  al contenuto principale, agli avvisi o all’avanzamento.
- Aggiorna elenco e Riprova spostano temporaneamente il focus al titolo prima
  di disabilitare o nascondere il controllo. Alla risposta torna al controllo
  ancora disponibile; se scomparso resta al titolo. Un successivo movimento
  dell’utente o l’apertura di un dialogo impediscono a questa lettura di spostarlo.

Sintassi JavaScript e differenze sono state controllate localmente. Un DOM
simulato ha esercitato i percorsi di focus di apertura, annullamento, scrittura,
errori e letture concorrenti, senza browser, listener o dati persistenti. Questi
controlli e i rapporti di contrasto non dimostrano il rendering effettivo, l’ordine
di Tab, il contenimento nei dialoghi, lo zoom o gli annunci di uno screen reader:
occorre una verifica host aggiornata dopo queste modifiche.

La revisione nel browser, il layout effettivo a 390px e l’ascolto HTTP reale
richiedono verifica host; i controlli locali sono statici e sul gestore HTTP
in processo, senza avviare listener o browser. Per modifica ed eliminazione
sono stati esercitati anche gli eventi dell’applicazione in un DOM simulato,
collegato al gestore HTTP e a un archivio SQLite temporaneo: precompilazione,
PATCH parziale, bozza separata, annullamento, invii duplicati, errori 404/409/500,
risposte DELETE 200/204 e fallimento della lettura dopo una scrittura confermata.
Questi controlli non dimostrano il comportamento effettivo nel browser.

La revisione dei form e dei feedback ha confrontato in memoria 64 casi Unicode
con `validateItemFields`: soglie esatte e superate in tutti i campi, emoji,
sequenze composte, accenti combinati e nomi vuoti. Eventi in un DOM simulato
hanno verificato anche errori associati ai campi, correzione senza invii,
conservazione della bozza per errori 400/409/500, rete assente e risposte
inattese, blocco del doppio invio, stati di avanzamento, testo e markup letterali,
PATCH senza alterare ritorni a capo intatti, modifica 404 senza ricreazione e
scritture confermate seguite da lettura fallita. Nessun dato utente o dimostrativo
è stato scritto. Gli annunci effettivi con screen reader e il browser reale
non sono coperti da queste osservazioni locali. Per il browser reale consultare
le ricevute dei sei controlli host elencati nel [README](../README.md), riferite
alla versione in uso. La revisione AI del sorgente è della stessa integrazione
Codex e non costituisce una valutazione indipendente.
