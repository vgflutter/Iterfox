# Backup completo e ripristino

Le API sono disponibili sullo stesso indirizzo locale di Custode. La sezione
Backup offre download e ripristino con consenso: vedi [ui-backup.md](ui-backup.md). Queste API
non aggiungono dati dimostrativi e non richiedono servizi esterni.

## Scaricare

`GET /api/backup` restituisce JSON UTF-8 con status `200`, senza cache e con
`Content-Disposition: attachment; filename="custode-backup.json"`. Aprire
`http://127.0.0.1:4380/api/backup` nel browser per scaricarlo; adeguare porta e
indirizzo se configurati diversamente. Il nome del download è fisso e non deriva
da testi presenti nell’archivio.

Il contenitore è `{schemaVersion:1,items:[],tasks:[],history:[]}`. Le tre tabelle
sono lette in un unico snapshot SQLite coerente, anche se un altro processo
locale modifica l’archivio durante la lettura. Il download comprende tutto
l’archivio, indipendentemente dai filtri della pagina:

- `items`: tutti gli oggetti, con `id`, `name`, `category`, `location`, `notes`,
  `createdAt`, `updatedAt`.
- `tasks`: tutti gli interventi, compresi conclusi ed eliminati che sostengono
  lo storico. Campi `id`, `itemId`, `title`, `dueDate`, `intervalDays`, `notes`,
  `completed`, `createdAt`, `updatedAt`, più il booleano `deleted`.
  `deleted:true` conserva il record senza renderlo disponibile nelle scadenze
  o nel normale elenco `/api/tasks`; `false` indica un intervento non eliminato.
- `history`: tutti gli eventi con `id`, `taskId`, `itemId`, `title`, `completedOn`.
  Titolo e oggetto sono quelli al momento della registrazione: possono differire
  dai valori correnti dell’intervento.

Tutti gli array seguono l’ordine di inserimento. Nel backup lo storico non è
ordinato come `/api/history`: l’ordine di inserimento permette di ricostruire
anche le precedenze tra eventi dello stesso giorno. Dopo il ripristino, lo
storico visibile continua a mostrare prima la data più recente e, a parità di
data, l’ultimo evento registrato. Non riordinare gli array del file.

Spazi, Unicode, markup e caratteri di controllo nei testi restano dati letterali;
il formato JSON li codifica quando necessario. Identificativi, date e timestamp
non vengono rigenerati. Un download prodotto da Custode, ripristinato senza
modifiche, produce lo stesso documento JSON a parità di dati.

## Sostituire esplicitamente l’archivio

`POST /api/restore` accetta soltanto un oggetto JSON con `backup` (il documento
completo) e `mode:"replace"`. Restituisce `200` con `{"ok":true}` soltanto dopo
il commit. La sostituzione comprende tutti i dati correnti, anche quelli
aggiunti dopo il download; non c’è fusione né annullamento automatico.
Un backup vuoto valido svuota l’archivio.

Prima di procedere, salvare anche un backup dello stato corrente. Chiudere
le altre finestre di Custode ed evitare scritture durante la sostituzione.
L’API non può chiedere una conferma grafica: inviare `mode:"replace"` è la
scelta esplicita del chiamante. Scaricare o leggere un file non sostituisce dati.

Per chi usa il terminale, questi comandi preparano il corpo richiesto senza
modificare il file di backup. Sostituire i percorsi con quelli reali, fuori dal
repository; il secondo comando effettua la sostituzione:

```sh
node --input-type=module - /percorso/backup.json /percorso/richiesta-ripristino.json <<'NODE'
import { readFileSync, writeFileSync } from 'node:fs';
const [source, destination] = process.argv.slice(2);
const backup = JSON.parse(readFileSync(source, 'utf8'));
writeFileSync(destination, JSON.stringify({ backup, mode: 'replace' }), { flag: 'wx', mode: 0o600 });
NODE

curl --fail-with-body -X POST http://127.0.0.1:4380/api/restore \
  -H 'Content-Type: application/json' \
  --data-binary @/percorso/richiesta-ripristino.json
```

L’involucro `{backup,mode}` è obbligatorio: non inviare direttamente il file
scaricato come corpo del POST. Dopo il successo, ricaricare le pagine aperte;
le bozze o schede già caricate appartengono all’archivio precedente.

## Validazione e atomicità

La validazione completa precede qualsiasi scrittura. Sono rifiutati:

- Contenitori, record, tipi, campi obbligatori o versione errati; campi sconosciuti
  a ogni livello. `schemaVersion` deve essere il numero `1`.
- Identificativi vuoti, composti solo da spazi, non rappresentabili in Unicode
  valido, contenenti separatori di percorso o controlli, oppure `.` e `..`.
  Gli identificativi sono stringhe opache: non devono necessariamente essere UUID.
  Ogni collezione richiede identificativi univoci.
- Riferimenti a oggetti o interventi assenti nel backup. Anche un evento di un
  intervento eliminato richiede il suo record in `tasks` con `deleted:true`.
- Testi non conformi agli stessi limiti delle API ordinarie: nome e titolo
  obbligatori massimo 200 punti di codice, categoria/posizione 100, note 5000.
  Nessun testo viene troncato, ripulito o normalizzato.
- Date civili impossibili o non nel formato `YYYY-MM-DD` con anni 0001–9999;
  intervalli non interi o fuori da 0–3660; `completed` e `deleted` non booleani.
- Timestamp non ISO, giorni o orari impossibili, fusi assenti, oppure
  `updatedAt` precedente a `createdAt`. Il formato accettato è
  `YYYY-MM-DDTHH:mm:ss[.S|.SS|.SSS]Z` oppure con fuso `±HH:mm`, anni 0001–9999.
  La rappresentazione originale viene conservata, senza conversione di fuso.

Gli aggiornamenti successivi mantengono timestamp crescenti: se un timestamp
importato è già al limite superiore supportato, la modifica viene rifiutata
senza alterare dati, evitando di produrre un archivio non ripristinabile.

Tutti i campi dei record completi sono obbligatori, inclusi quelli con testo
vuoto. L’unica eccezione è `tasks[].deleted`: se assente vale `false`, per
accettare i record ordinari dell’API manutenzioni nel contenitore versione 1.
Ogni nuovo download esplicita sempre questo campo. Rimuoverlo da un record
eliminato ne perde l’informazione di eliminazione: conservare il file originale.
Il ripristino non impone che il titolo o l’oggetto storico coincidano con quelli
attuali e non ricalcola scadenze o stato di completamento.

La cancellazione e tutti gli inserimenti nelle tre tabelle avvengono in una
sola transazione, con chiavi esterne attive. Un errore durante qualsiasi
inserimento provoca rollback completo, compresi i dati cancellati. Le risposte
di validazione sono `400` con `{"error":"descrizione"}`; formati HTTP non
supportati danno `415`, metodi non consentiti `405`, errori di archivio `500`.
Un errore non svuota l’archivio e non ricrea il database.

## Dimensioni e recupero

Il corpo HTTP completo è limitato a **2 MiB (2.097.152 byte)**, compresi
`backup`, `mode`, parentesi e ogni spazio. La misura è in byte UTF-8, non in
caratteri. Il limite vale anche senza `Content-Length`; un eccesso dà `413`
JSON senza avviare il ripristino. Corpi compressi e UTF-8 invalido sono rifiutati.
Il download completo non viene troncato e può superare questa dimensione:
un file scaricabile non è quindi necessariamente ripristinabile via HTTP.
In quel caso conservare una copia dell’intera cartella dati a servizio fermo.
Non tagliare il JSON né rimuovere eventi per aggirare il limite.

In caso di file illeggibile o JSON non valido conservare l’originale e scegliere
una copia integra. In caso di risposta persa o connessione interrotta durante
il POST, il risultato può essere già stato confermato: prima di riprovare,
scaricare nuovamente `/api/backup` e confrontare lo stato, oltre a inventario,
scadenze e storico. Non ci sono reinvii automatici. Un errore di lettura dopo
`{"ok":true}` non annulla la sostituzione: riprovare la lettura.

Se il database non si avvia, arrestare Custode e conservare tutta la cartella
originale. Avviare con `CUSTODE_DATA_DIR` rivolto a una **nuova cartella esterna
al repository** e ripristinare lì un backup JSON valido, lasciando intatto
l’archivio originale. Per copie grandi usare invece una copia completa e integra
della cartella fatta a servizio fermo e avviare con quel percorso. Custode non
ripara database corrotti e non recupera informazioni assenti nel backup.

La documentazione del candidato preservato riporta verifiche locali mirate su
round-trip, record eliminati, ordine dello storico, validazione, rollback forzato,
riapertura SQLite e handler HTTP senza listener. Sono osservazioni storiche.
Per questo recupero tutti e sei i controlli approvati elencati nel
[README](../README.md), incluso `backup`, e la revisione indipendente del sorgente
sono in attesa di nuovi risultati del runtime; questo documento non ne dichiara
il superamento.
