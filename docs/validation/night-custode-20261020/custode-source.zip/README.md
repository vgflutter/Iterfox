# Custode

Applicazione locale per conservare gli oggetti di casa, con interfaccia in
italiano e API HTTP. Un archivio nuovo è vuoto, senza dati dimostrativi.
L’interfaccia permette di vedere l’inventario, aggiungere, cercare e modificare
oggetti, ed eliminarli con conferma esplicita.
La sezione Manutenzioni permette di programmare e completare interventi una tantum
o ricorrenti, modificarli ed eliminarli con conferma, consultarne le scadenze e
ritrovare le attività nello Storico.
La sezione **Backup** permette di scaricare l’archivio completo e ripristinarlo
con riepilogo e conferma esplicita della sostituzione.

## Avvio

Serve Node.js 22.13 o successivo, con il modulo integrato `node:sqlite`.
Non occorre installare dipendenze. Dalla cartella del progetto:

```sh
npm start
```

Il servizio risponde su `http://127.0.0.1:4380`. Il terminale mostra l’indirizzo
effettivo e il percorso del database. `Ctrl+C` arresta il servizio.

Variabili d’ambiente facoltative:

| Variabile | Valore predefinito | Uso |
| --- | --- | --- |
| `HOST` | `127.0.0.1` | Solo loopback: indirizzi IPv4 `127.*`, `::1` oppure `localhost` (ricondotto a `127.0.0.1`). |
| `PORT` | `4380` | Intero da 0 a 65535; `0` sceglie una porta libera, indicata nel terminale. |
| `CUSTODE_DATA_DIR` | `~/.local/share/custode` | Cartella persistente, esterna al repository; `~` qui indica la cartella personale dell’utente. |

Esempio con una cartella esplicita:

```sh
CUSTODE_DATA_DIR="$HOME/Documenti/Custode" PORT=4380 npm start
```

La cartella configurata deve essere esterna al repository; un percorso relativo
è risolto dalla cartella di avvio. Gli indirizzi pubblici o della LAN sono
rifiutati: il servizio è utilizzabile solo dal dispositivo su cui viene eseguito.

## Usare l’inventario

Dopo l’avvio, aprire `http://127.0.0.1:4380/` nel browser sullo stesso dispositivo.
Se si cambiano `HOST` o `PORT`, usare l’indirizzo effettivo mostrato nel terminale.
L’interfaccia richiede JavaScript e un browser moderno; non occorrono account
o connessioni esterne. La navigazione **Oggetti** apre l’inventario.

Il layout si adatta a desktop e schermi di telefono. Il limite loopback rimane:
un telefono sulla stessa rete Wi-Fi non può raggiungere il servizio avviato sul
computer. Cambiare `HOST` con un indirizzo LAN non è supportato.

### Aggiungere un oggetto

1. Scegliere **Nuovo oggetto** oppure, nell’archivio vuoto, **Aggiungi il primo oggetto**.
2. Compilare **Nome oggetto**, obbligatorio e non composto solo da spazi.
   **Categoria**, **Posizione** e **Note** sono facoltativi.
3. Premere **Salva oggetto** e attendere il messaggio di conferma. L’elenco viene
   ricaricato; i dati confermati restano disponibili dopo la ricarica della pagina
   e il riavvio del servizio con la stessa cartella dati.

**Annulla**, il pulsante **Chiudi il modulo** o `Esc` chiudono senza inviare altri dati.
La bozza di un nuovo oggetto resta disponibile riaprendo **Nuovo oggetto**, anche
dopo aver modificato un altro oggetto. È conservata solo nella pagina aperta:
un salvataggio confermato la svuota; ricaricare o chiudere la pagina la elimina.
Anche un ripristino confermato scarta le bozze dell’archivio precedente.

### Cercare e aggiornare l’elenco

Scrivere in **Cerca oggetti**: l’elenco si aggiorna mentre si digita; `Invio`
avvia subito la ricerca. Il testo cerca una sottostringa in nome, categoria,
posizione e note senza distinguere maiuscole e minuscole. Accenti e spazi contano.
Il conteggio filtrato indica i risultati della ricerca, non il totale dell’archivio.

**Cancella ricerca** (il pulsante **Cancella** accanto al campo) oppure **Mostra
tutti gli oggetti** rimuove il filtro. Un archivio vuoto e una ricerca senza
risultati mostrano messaggi distinti. **Nuovo oggetto** resta disponibile durante
la ricerca, il caricamento e gli errori.

Creazione, modifica ed eliminazione mantengono la ricerca attiva. Un oggetto
salvato può quindi non comparire se non corrisponde al filtro: cancellare la
ricerca per vedere tutto l’inventario. **Aggiorna elenco**, il pulsante con la
freccia circolare accanto al conteggio, rilegge i dati mantenendo il filtro;
usarlo anche per vedere modifiche effettuate da un’altra finestra.

### Modificare un oggetto

Sulla scheda scegliere **Modifica**. Il modulo mostra i dati dell’oggetto;
**Salva oggetto** aggiorna solo i campi cambiati. Un invio senza cambiamenti
chiude il modulo con il messaggio **Nessuna modifica da salvare**.
**Annulla**, la chiusura e `Esc` scartano le modifiche non salvate: riaprendo
il modulo si ritrovano i dati dell’elenco. La bozza di creazione rimane separata.

### Eliminare un oggetto

Scegliere **Elimina** sulla scheda e controllare il nome nella conferma.
Solo **Conferma eliminazione** invia la richiesta al server; l’operazione
non può essere annullata. **Annulla**, **Chiudi la conferma** o `Esc` tornano
all’elenco senza eliminare nulla. I pulsanti delle schede includono il nome
dell’oggetto nel nome accessibile: `Modifica <nome>` ed `Elimina <nome>`.

Durante un salvataggio o un’eliminazione in corso, invio e chiusura sono
disabilitati per evitare richieste duplicate. Attendere l’esito prima di agire.

### Correggere errori e recuperare l’elenco

Gli errori di compilazione sono indicati accanto ai campi; il focus va al primo
da correggere e i valori restano compilati. I limiti coincidono con quelli
dell’API: nome 200 caratteri, categoria e posizione 100, note 5000, contando
i punti di codice Unicode. Le emoji composte possono contare come più caratteri.
Correggere i campi segnalati e premere di nuovo **Salva oggetto**; la correzione
da sola non invia dati.

| Situazione | Come procedere |
| --- | --- |
| **Inventario non disponibile** o **Ricerca non disponibile** | Verificare che il servizio sia attivo nel terminale, quindi usare **Riprova** o **Aggiorna elenco**. La ricerca resta modificabile. |
| Creazione non confermata, con **Verifica prima di riprovare** nel modulo | L’oggetto potrebbe essere già stato creato. **Salva oggetto** resta disabilitato finché **Rileggi inventario completo** non riesce: seguire i passaggi sotto. |
| Modifica o eliminazione non confermate, servizio non raggiungibile o risposta inattesa | L’operazione potrebbe essere già avvenuta. Chiudere il dialogo e usare **Aggiorna elenco** prima di riprovare, per evitare ripetizioni. |
| Oggetto non più disponibile o operazione non consentita | Leggere il messaggio, annullare e aggiornare l’elenco. Un oggetto scomparso non viene ricreato automaticamente. |
| Operazione confermata, ma aggiornamento dell’elenco fallito | Usare **Riprova** per rileggere i dati. Il salvataggio o l’eliminazione già confermati restano validi: non ripetere l’operazione. |

Per recuperare una creazione non confermata senza perdere la bozza:

1. Nel modulo scegliere **Rileggi inventario completo**. Il comando esegue
   soltanto letture e mostra tutti gli oggetti, con categoria, posizione e note,
   indipendentemente dalla ricerca attiva. Il filtro dell’elenco resta invariato.
2. Confrontare i risultati con la bozza. Se l’oggetto è già presente, scegliere
   **Annulla**; la verifica non svuota la bozza né salva automaticamente.
3. Solo dopo una lettura riuscita **Salva oggetto** torna disponibile. Se l’oggetto
   manca e si vuole tentare di crearlo, premere esplicitamente quel pulsante.

Se la verifica fallisce, **Salva oggetto** resta disabilitato e i campi restano
compilati: controllare che Custode sia attivo e ripetere **Rileggi inventario
completo**. Chiudere e riaprire **Nuovo oggetto** conserva bozza e stato di
recupero nella pagina; **Aggiorna elenco** da solo non sblocca la creazione.
Durante la verifica, modifica dei campi e chiusura sono temporaneamente bloccate.
I risultati fotografano il momento della lettura: un oggetto simile non identifica
con certezza la richiesta che lo ha creato. Il controllo richiede il confronto
dell’utente e non garantisce l’assenza di duplicati tra più finestre.

Un errore di salvataggio conserva i campi finché il modulo è aperto. Prima di
chiuderlo per controllare l’elenco, copiare eventuali modifiche che si vogliono
conservare: annullare una modifica le scarta. Per un nuovo oggetto la bozza
rimane nella pagina, ma viene persa ricaricandola o chiudendola.

Errori e conflitti lasciano aperto il dialogo e non rimuovono schede localmente.
Un errore di lettura non viene mostrato come una ricerca senza risultati.
Se restano visibili schede già caricate per lo stesso filtro, un avviso e il
conteggio **da aggiornare** indicano che potrebbero essere superate.
Dopo un’operazione confermata, invece, le vecchie schede non vengono riproposte
se la ricarica fallisce; l’esito dell’operazione e l’errore di lettura sono separati.

## Programmare le manutenzioni

Aprire **Manutenzioni** e scegliere **Nuovo intervento**. Compilare **Titolo
intervento**, scegliere un **Oggetto** dell’inventario e indicare **Scadenza**.
**Ripeti ogni (giorni)** accetta un intero da 0 a 3660: 0 significa una tantum;
un valore positivo indica i giorni dalla data di completamento alla prossima
scadenza. **Note intervento** è facoltativo. **Salva intervento** registra i dati
nell’archivio reale; attendere la conferma prima di chiudere.

Il menu **Oggetto** carica sempre tutto l’inventario, anche se la ricerca nella
sezione Oggetti è attiva. Categoria e posizione aiutano a distinguere gli oggetti
con lo stesso nome. Senza oggetti, **Aggiungi un oggetto** apre il modulo
dell’inventario; dopo il salvataggio tornare a Manutenzioni per riprendere la bozza.
Il cambio di sezione conserva ricerca e bozza del nuovo oggetto.

Oggetti e Manutenzioni rileggono i dati quando si torna da un’altra sezione.
Una rinomina o un cambio di posizione nell’inventario appare quindi anche nelle
scadenze e nello Storico al ritorno a Manutenzioni; il menu del modulo viene
riletto a ogni apertura. Sotto il menu, il dettaglio dell’oggetto selezionato
mostra nome, categoria e posizione completi anche quando il testo è molto lungo.
Le modifiche da un’altra finestra si vedono tornando alla sezione o usando
**Aggiorna elenco** / **Aggiorna manutenzioni**: non c’è aggiornamento automatico
continuo. Le risposte di lettura superate non sostituiscono i dati più recenti.

**Annulla**, la chiusura e `Esc` conservano la bozza del nuovo intervento nella
pagina aperta. Un salvataggio confermato la svuota; ricaricare o chiudere la pagina
la elimina. Anche un ripristino confermato scarta le bozze precedenti.
Gli errori indicano i campi da correggere e conservano i valori. Durante il
salvataggio non è possibile inviare nuovamente o chiudere.
Se non si carica il menu degli oggetti, usare **Riprova caricamento oggetti**.
Se l’oggetto scelto è stato eliminato da un’altra finestra, chiudere e riaprire il
modulo per rileggere l’inventario e selezionare un oggetto disponibile.

La panoramica mostra solo interventi attivi, ordinati per scadenza, con oggetto,
posizione, data, ricorrenza e note. Distingue **Scaduti**, **Oggi**, **Prossimi**
e **Oltre 30 giorni**. I tre conteggi includono rispettivamente le scadenze prima
di oggi, quelle di oggi e quelle da domani fino al trentesimo giorno incluso.
Gli interventi più lontani rimangono nell’elenco. Il giorno di riferimento è
quello locale del browser, mostrato sopra i conteggi; le date sono giorni di
calendario, senza orario o conversione di fuso.

**Aggiorna manutenzioni**, **Riprova** o il ritorno alla sezione rileggono dati e
giorno di riferimento. Se la lettura fallisce, i conteggi mostrano un trattino e
un avviso: non significano che l’archivio sia vuoto. Dopo un salvataggio confermato
seguito da un errore di lettura, riprovare solo l’aggiornamento. Non ci sono invii
automatici o notifiche esterne.

### Recuperare la creazione di un intervento

Gli errori di compilazione e i rifiuti di validazione mantengono i valori e
permettono di correggerli prima di premere di nuovo **Salva intervento**.
Se invece compare **Verifica prima di riprovare**, l’intervento potrebbe essere
già stato creato: **Salva intervento** resta disabilitato fino alla verifica.

1. Scegliere **Rileggi tutti gli interventi** nel modulo. Il comando legge gli
   interventi attuali e l’inventario senza scrivere, conservando la bozza.
2. Controllare l’elenco mostrato nel dialogo: include anche gli interventi conclusi
   che non compaiono nelle scadenze attive. Oggetto, categoria, posizione,
   scadenza, ricorrenza, stato e note aiutano a confrontarlo con la bozza.
   Se l’intervento è presente, scegliere **Annulla**.
3. Dopo una lettura riuscita, se l’intervento manca, scegliere esplicitamente
   **Salva intervento** per un nuovo tentativo. Anche il menu **Oggetto** deve
   essere caricato correttamente prima di poter salvare.

Un errore della verifica lascia la bozza e il blocco: controllare che Custode sia
attivo e ripetere **Rileggi tutti gli interventi**. Durante la verifica campi e
chiusura sono bloccati; nessun salvataggio viene ripetuto automaticamente.
Chiudere e riaprire **Nuovo intervento**, anche dopo aver modificato un altro
intervento, conserva lo stato di recupero nella pagina. **Aggiorna manutenzioni**
e **Riprova caricamento oggetti** non sostituiscono questa verifica.
L’elenco è una fotografia del momento, senza gli interventi eliminati; un record
simile non prova quale richiesta lo abbia creato. La verifica non garantisce
l’assenza di duplicati tra finestre. Ricaricare o chiudere la pagina perde bozza
e stato di recupero: controllare i dati correnti prima di ricreare l’intervento.

### Completare e consultare lo storico

Sulla scheda dell’intervento scegliere **Completa**, indicare **Data completamento**
e premere **Conferma completamento**. Il dialogo propone oggi e descrive l’effetto:
una tantum viene concluso; un ricorrente resta attivo e sposta la scadenza alla
data di completamento più i giorni dell’intervallo. L’anteprima mostra la prossima
scadenza, anche attraverso febbraio bisestile e i cambi d’anno. Le date sono
giorni di calendario, senza orario; si può registrare anche un’attività passata.

Durante la registrazione invio, chiusura ed `Esc` sono bloccati. Dopo conferma
del server, scadenze, conteggi e **Storico** vengono riletti. Un intervento
una tantum concluso esce dall’elenco attivo e rimane consultabile nello storico;
quello ricorrente mostra la nuova scadenza. Ogni evento ha titolo, oggetto e data
di completamento. L’ordine segue la data di completamento, dalla più recente;
a parità di data, l’ultima registrazione viene prima.

Il titolo e il collegamento all’oggetto fotografano il completamento; il nome
dell’oggetto e lo stato dell’intervento mostrano i dati correnti. Lo storico
distingue **Una tantum · concluso**, **Ricorrente · ancora attivo** e interventi
successivamente rimossi, conservando comunque le registrazioni. Per gli attivi
mostra anche la scadenza attuale. Gli eventi restano nell’archivio dopo il riavvio.

Una data invalida non viene inviata. Gli errori mantengono il giorno scelto,
anche chiudendo e riaprendo il dialogo per lo stesso intervento nella pagina.
La bozza si svuota solo dopo conferma e non sopravvive al ricaricamento della pagina.
Se la risposta al completamento è incerta, oppure l’intervento risulta già
concluso o rimosso da un’altra finestra, una nuova conferma viene bloccata.
Anche un intervento modificato o completato dopo l’apertura del dialogo viene
rifiutato (`409`): la registrazione non usa una ricorrenza diversa dall’anteprima.
**Verifica scadenze e storico** chiude il dialogo e legge i dati senza ripetere
il completamento. Controllare lo storico prima di registrare un’altra attività:
per i ricorrenti ogni conferma esplicita registra un nuovo evento, anche se
si indica la stessa data. Il blocco si rimuove dopo una lettura completa riuscita.

Se il completamento è confermato e fallisce solo la lettura successiva, il
messaggio lo distingue: non ripetere la registrazione. **Riprova** e **Riprova
storico** eseguono soltanto letture. Scadenze e storico hanno avvisi separati:
un errore dello storico lascia utilizzabile la panoramica caricata correttamente,
e viceversa. Una sezione non caricata non viene presentata come vuota.

### Modificare ed eliminare gli interventi

**Modifica** apre un modulo precompilato. **Salva intervento** aggiorna soltanto
i campi cambiati; senza cambiamenti rilegge i dati senza scrivere. **Annulla**,
chiusura ed `Esc` scartano le modifiche del modulo, lasciando intatta la bozza
separata di un nuovo intervento. Gli errori mantengono i valori nel modulo;
se l’oggetto scelto non esiste più, **Riprova caricamento oggetti** aggiorna il
menu senza perdere gli altri campi.

Le modifiche non riscrivono i completamenti già registrati: titolo, data e
collegamento all’oggetto nello Storico restano quelli originali. Una nuova
ricorrenza vale per i prossimi completamenti; la scadenza corrente cambia solo
se viene modificata. Gli interventi conclusi offrono **Modifica** ed **Elimina**
nello Storico. Modificarli non li riapre; un titolo rinominato appare anche come
**Titolo attuale**, accanto al titolo originale dell’evento.

**Elimina** apre una conferma che mostra il titolo e gli effetti sullo storico.
Soltanto **Conferma eliminazione** invia la richiesta; **Annulla**, chiusura ed
`Esc` non rimuovono dati. L’intervento esce dalle scadenze dopo la conferma del
server, mentre i completamenti restano nello Storico con lo stato **Intervento
rimosso**. Gli oggetti collegati a interventi o eventi storici restano protetti
dall’eliminazione: un conflitto `409` non rimuove alcun dato.

Modifica ed eliminazione verificano anche la versione letta: se un’altra finestra
ha modificato o completato l’intervento, il server rifiuta la richiesta (`409`)
senza sovrascrivere i dati più recenti. Se l’ha rimosso, risponde `404` e il modulo
non lo ricrea. Dopo un conflitto o una risposta incerta, la conferma resta
bloccata: **Scarta modifiche e rileggi** chiude il modulo scartandone le modifiche;
**Rileggi interventi e storico** chiude la conferma di eliminazione. Entrambi
eseguono soltanto letture. Controllare i dati aggiornati e riaprire l’azione
desiderata. Una lettura fallita dopo una scrittura confermata non ne annulla
l’esito: riprovare solo la lettura. Nessuna scrittura viene ripetuta automaticamente.

### Tastiera e lettura

Usare `Tab` e `Maiusc+Tab` per spostarsi tra navigazione, ricerca e azioni;
`Invio` o `Spazio` attivano i pulsanti. Il collegamento **Vai al contenuto**
compare quando riceve il focus e porta al contenuto principale. Cambiando
sezione, il focus passa al suo titolo; ricerca e bozze di creazione rimangono
nella pagina. I dialoghi mantengono il focus al loro interno e `Esc` li chiude,
salvo durante una scrittura o una verifica di creazione in corso. Dopo Annulla
si torna all’azione d’origine; dopo una scrittura confermata, al titolo delle
scadenze o dello Storico.

Il menu **Oggetto** usa i comandi nativi del browser, comprese frecce e ricerca
digitando il nome. I messaggi dei campi sono associati ai rispettivi controlli;
il primo campo invalido riceve il focus. Scaduto, Oggi e Prossimo sono scritti
anche in parole; i conteggi aggiornati sono annunciati insieme al totale degli
attivi. Il layout dispone campi e azioni su più righe sugli schermi stretti.

## API inventario

Le risposte sono JSON UTF-8. Per inviare dati usare `Content-Type: application/json`.
Non vengono modificati spazi, Unicode o markup nei testi memorizzati.

| Metodo e percorso | Risultato |
| --- | --- |
| `GET /api/health` | `{"ok":true}` |
| `GET /api/items` | Array di oggetti, inizialmente vuoto; ordine di inserimento. |
| `GET /api/items?q=...&category=...&location=...` | Filtri combinati con AND, senza distinzione tra maiuscole e minuscole. |
| `POST /api/items` | Crea un oggetto; status `201` e oggetto completo. |
| `PATCH /api/items/:id` | Aggiorna soltanto i campi forniti; restituisce l’oggetto completo. |
| `DELETE /api/items/:id` | Elimina l’oggetto; status `200` con `{"ok":true}`. Se collegato a interventi o storico, `409` senza modifiche. |

La ricerca `q` trova una sottostringa in nome, categoria, posizione o note.
Categoria e posizione richiedono una corrispondenza esatta, ignorando il caso.
I filtri vuoti sono ignorati; caratteri speciali e spazi vanno codificati nell’URL.
La ricerca non ignora gli accenti.

POST e PATCH accettano esclusivamente questi campi:

| Campo | Regole |
| --- | --- |
| `name` | Stringa obbligatoria alla creazione, non vuota né composta solo da spazi; massimo 200 caratteri. |
| `category` | Stringa, massimo 100 caratteri; predefinito `""`. |
| `location` | Stringa, massimo 100 caratteri; predefinito `""`. |
| `notes` | Stringa, massimo 5000 caratteri; predefinito `""`. |

I limiti contano i punti di codice Unicode. Un aggiornamento deve contenere
almeno un campo. `null`, array, tipi diversi da stringhe, campi sconosciuti e
tentativi di impostare `id`, `createdAt` o `updatedAt` sono rifiutati.
Ogni oggetto dell’inventario include un `id` stringa stabile e le date ISO UTC
`createdAt` e `updatedAt`. Gli identificativi e la data di creazione non cambiano
durante un aggiornamento.

Esempi con `curl`: sostituire i segnaposto con i propri valori.
POST crea un oggetto reale; per PATCH e DELETE sostituire
`ID_OGGETTO` con l’`id` restituito dalla creazione o dall’elenco.

```sh
curl -sS http://127.0.0.1:4380/api/health

curl -i -X POST http://127.0.0.1:4380/api/items \
  -H 'Content-Type: application/json' \
  -d '{"name":"NOME_OGGETTO","category":"CATEGORIA","location":"POSIZIONE","notes":""}'

curl -sS http://127.0.0.1:4380/api/items

curl -sS -G http://127.0.0.1:4380/api/items \
  --data-urlencode 'q=TESTO' \
  --data-urlencode 'category=CATEGORIA' \
  --data-urlencode 'location=POSIZIONE'

curl -sS -X PATCH http://127.0.0.1:4380/api/items/ID_OGGETTO \
  -H 'Content-Type: application/json' \
  -d '{"location":"NUOVA_POSIZIONE"}'

curl -sS -X DELETE http://127.0.0.1:4380/api/items/ID_OGGETTO
```

Richieste invalide restituiscono `400`, identificativi o percorsi inesistenti
`404`, metodi non consentiti `405`, corpi oltre 2 MiB `413`, formati del corpo
non supportati `415`. Gli errori contengono `{"error":"descrizione"}`.
La validazione completa precede ogni modifica: una richiesta rifiutata
lascia l’inventario invariato. DELETE non accetta un corpo HTTP.
Il limite di 2 MiB è misurato in byte; i corpi compressi sono rifiutati.
Un errore di archivio restituisce `500` e viene registrato nel terminale,
senza ricreare o svuotare i dati.

## API manutenzioni

Usare lo stesso indirizzo e `Content-Type: application/json` dell’inventario.
Gli elenchi di un archivio nuovo sono vuoti; il server non crea esempi.

| Metodo e percorso | Risultato |
| --- | --- |
| `GET /api/tasks` | Array degli interventi non eliminati, in ordine di inserimento, inclusi quelli una tantum conclusi. |
| `POST /api/tasks` | Crea un intervento; `201` con l’intervento completo. |
| `PATCH /api/tasks/:id` | Aggiorna solo i campi forniti; restituisce l’intervento completo. |
| `DELETE /api/tasks/:id` | Rimuove l’intervento dagli elenchi e dalle scadenze; `200` con `{"ok":true}`. Conserva lo storico. |
| `POST /api/tasks/:id/complete` | Corpo `{"completedOn":"YYYY-MM-DD"}`; `200` con l’intervento aggiornato, dopo aver registrato anche lo storico. |
| `GET /api/history` | Array di eventi con `id`, `taskId`, `itemId`, `title`, `completedOn`. Ordine per data completamento decrescente; a parità di data, prima l’ultimo registrato. |
| `GET /api/overview?today=YYYY-MM-DD` | `{overdue,today,upcoming,tasks}`: conteggi e interventi attivi ordinati per scadenza, con ordine di inserimento a parità di data. |

POST e PATCH degli interventi accettano soltanto:

| Campo | Regole |
| --- | --- |
| `itemId` | Stringa obbligatoria alla creazione; deve riferirsi a un oggetto esistente. |
| `title` | Stringa obbligatoria, non vuota né composta solo da spazi; massimo 200 punti di codice Unicode. |
| `dueDate` | Data civile obbligatoria `YYYY-MM-DD`, anni da `0001` a `9999`, con giorno e mese realmente esistenti. |
| `intervalDays` | Intero da 0 a 3660; predefinito 0 (una tantum). |
| `notes` | Stringa, massimo 5000 punti di codice Unicode; predefinito `""`. |

Identificativi e timestamp ISO `createdAt`/`updatedAt` sono assegnati dal server.
`completed` è un booleano gestito esclusivamente dal completamento; non è
scrivibile con POST o PATCH. Un PATCH vuoto, i campi sconosciuti, tipi errati,
date impossibili e riferimenti inesistenti producono `400` senza cambiamenti.
Testi, spazi, Unicode e markup sono conservati letteralmente.

PATCH, DELETE e completamento degli interventi accettano l’intestazione facoltativa `If-Match`
con l’`updatedAt` letto da `/api/tasks`, racchiuso tra virgolette doppie (per
esempio `If-Match: "2026-10-20T16:00:00.000Z"`). Il confronto avviene nella stessa
transazione della scrittura: versione diversa dà `409` senza cambiamenti;
identificativo rimosso dà `404`. `If-Match: *` richiede soltanto l’esistenza.
Senza intestazione restano disponibili i normali PATCH parziali, DELETE e completamenti.
L’interfaccia usa la versione per evitare di sovrascrivere modifiche o confermare
l’eliminazione o il completamento di un intervento cambiato dopo la lettura.

Il completamento una tantum imposta `completed:true`, mantiene la scadenza
originaria e non può essere ripetuto (`409`). Modificare un intervento concluso
non lo riapre. Un intervento ricorrente resta `completed:false` e la nuova
scadenza è **data di completamento + intervalDays**, indipendentemente dalla
scadenza precedente. Per esempio, `2028-02-28 + 2` dà `2028-03-01`.
Il calcolo usa giorni di calendario, senza dipendere da fuso o ora legale.
Una prossima scadenza oltre `9999-12-31` viene rifiutata senza registrare eventi.
È possibile registrare una data precedente o successiva alla scadenza.

Ogni completamento registra un nuovo evento con identificativo stabile;
titolo e oggetto sono quelli al momento del completamento e non cambiano
rinominando o ricollegando successivamente l’intervento. Evento e stato
dell’intervento sono salvati nella stessa transazione: nessun aggiornamento parziale.
Un completamento ricorrente ripetuto registra un altro evento: in caso di
risposta di rete incerta, consultare prima storico e scadenze, senza reinviare
automaticamente la richiesta.

La panoramica esclude interventi conclusi ed eliminati. `overdue` conta quelli
prima di `today`, `today` quelli nella data indicata e `upcoming` quelli da
domani fino al trentesimo giorno incluso. `tasks` contiene tutti gli attivi,
anche oltre i 30 giorni. Senza il parametro si usa la data locale del processo;
un parametro vuoto o invalido restituisce `400`.

Eliminare un intervento non elimina i suoi completamenti. Quando esiste uno
storico, il record dell’intervento viene conservato internamente per mantenere
integri i riferimenti; successive modifiche, eliminazioni o completamenti di
quell’identificativo restituiscono `404`. L’oggetto collegato allo storico resta
protetto da eliminazione (`409`), anche dopo aver eliminato l’intervento.
Se l’intervento non ha mai avuto completamenti, eliminarlo libera il legame:
l’oggetto potrà essere eliminato quando non ha altri interventi o eventi collegati.
DELETE non accetta corpi HTTP. Metodi, errori JSON e limite di 2 MiB coincidono
con quelli dell’inventario.

## Persistenza e limiti attuali

Il database predefinito è `~/.local/share/custode/custode.sqlite`, anche su macOS.
Con `CUSTODE_DATA_DIR` cambia la cartella, mentre il nome resta `custode.sqlite`.
SQLite usa transazioni e sincronizzazione completa; durante l’uso possono essere
presenti anche `custode.sqlite-wal` e `custode.sqlite-shm`. Creazioni, modifiche
ed eliminazioni confermate restano dopo il riavvio con la stessa cartella.
Non eliminare o modificare i file dell’archivio mentre il servizio è attivo.
L’avvio aggiorna gli archivi SQLite versione 1 alla versione interna 2 in una
transazione, senza riscrivere gli oggetti. Interventi, completamenti e storico
sono nello stesso database e restano disponibili con la stessa cartella dati.

Il servizio espone soltanto le risorse web locali previste in `public`, senza
accesso HTTP al database o ad altri percorsi del filesystem. Se il percorso non è
accessibile, il database è danneggiato o ha una versione non supportata, l’avvio
fallisce con un messaggio nel terminale, senza sostituire l’archivio con uno vuoto.
Conservare i dati su un disco locale scrivibile.

Per una copia manuale dei dati, arrestare prima tutte le istanze di Custode e
copiare l’intera cartella dei dati. Per riutilizzarla, avviare il servizio con
`CUSTODE_DATA_DIR` rivolto a quella cartella. Una cartella diversa e vuota crea
un nuovo archivio vuoto; per ritrovare i dati precedenti usare il percorso
originario mostrato nel terminale.

## Backup JSON e ripristino

Aprire **Backup** nella navigazione e scegliere **Scarica backup**. Il browser
scarica `custode-backup-AAAA-MM-GG.json`, con il giorno locale nel nome. Attendere
il download e controllare il file nella cartella scelta dal browser: il messaggio
di Custode segnala l’avvio, non può confermare dove il browser lo abbia salvato.

Per recuperare una copia:

1. Scaricare prima un backup dei dati correnti e chiudere le altre finestre di Custode.
2. In **File backup**, scegliere il file JSON. La lettura mostra nome e conteggi
   e **non modifica dati**. **Rimuovi file** annulla la selezione.
3. Premere **Ripristina backup**. Un secondo passaggio riepiloga oggetti,
   interventi (anche conclusi e rimossi) e completamenti; avvisa della sostituzione.
4. Solo dopo aver controllato, selezionare **Confermo la sostituzione dei dati**
   e premere **Conferma ripristino**. **Annulla**, la chiusura o `Esc` tornano
   al file senza scrivere. A ogni apertura il consenso è deselezionato.
5. Attendere l’esito. Durante la sostituzione invio e chiusura sono bloccati.
   Dopo il successo le schede e le bozze dell’archivio precedente vengono scartate
   e inventario, scadenze e storico vengono riletti. La ricerca viene svuotata.

Un file illeggibile, JSON invalido o troppo grande è segnalato senza invio.
I conteggi sono un’anteprima: il servizio controlla tutti i campi e riferimenti
prima di scrivere. Un rifiuto conserva l’archivio; annullare, rimuovere il file
e scegliere una copia valida. Una risposta incerta blocca ulteriori invii di
quel file selezionato: chiudere la conferma, scaricare lo stato corrente e
controllare Oggetti, scadenze e Storico prima di qualsiasi nuovo tentativo.
Un errore di lettura dopo il successo non annulla la sostituzione: nelle
sezioni usare **Riprova** / **Riprova storico**, senza ripetere il ripristino.

Con Custode avviato, aprire `http://127.0.0.1:4380/api/backup` per scaricare
l’archivio JSON completo anche direttamente tramite API. Adeguare l’indirizzo se è stata cambiata la porta.
Il file comprende oggetti, interventi attivi e conclusi, record eliminati che
sostengono lo storico e tutti i completamenti, con identificativi, testi,
date e ordine di registrazione conservati. I record eliminati non vengono
riattivati dal ripristino. Custodire i file di backup come gli altri dati personali.

`POST /api/restore` con `Content-Type: application/json` e corpo
`{"backup":DOCUMENTO_SCARICATO,"mode":"replace"}` sostituisce **tutto** l’archivio
corrente. Prima salvare anche lo stato corrente. `mode:"replace"` è una scelta
esplicita: non c’è fusione o annullamento automatico. Il download o la lettura
del file non modifica dati. La struttura completa, i tipi, le date e i riferimenti
sono validati prima di scrivere; qualsiasi errore di scrittura annulla l’intera
transazione. Il successo è `200` con `{"ok":true}`. Dopo il successo ricaricare
le pagine aperte, perché schede e bozze possono riferirsi ai dati precedenti.
La [guida delle API backup](docs/api-backup.md) descrive lo schema, il campo
`deleted`, gli errori e i comandi di ripristino.

Il corpo HTTP del ripristino ha un limite di **2 MiB (2.097.152 byte)**,
**incluso l’involucro della richiesta**: un file di 2 MiB non ci rientra.
Un eccesso restituisce `413` senza modifiche. Il download non viene troncato:
archivi più grandi richiedono la copia dell’intera cartella dati a servizio
fermo. I backup non sono automatici né cifrati. Le stringhe importate restano
letterali; non modificare il file per riordinare o eliminare record.

Se una risposta di ripristino si perde, scaricare il backup corrente e verificare
inventario, scadenze e storico prima di ripetere la sostituzione. Se è arrivato
`{"ok":true}` e fallisce solo una lettura successiva, riprovare la lettura.
Se l’archivio impedisce l’avvio, arrestare il servizio e conservare tutta la
cartella originale; avviare con `CUSTODE_DATA_DIR` su una nuova cartella esterna
al repository e ripristinare un backup valido nella nuova istanza. Per una
copia completa della cartella fatta a servizio fermo, avviare direttamente su
quella copia. Non cancellare il database originale per tentare il recupero.

Sono disponibili interfaccia e API dell’inventario, controllo di stato, API delle
manutenzioni e interfaccia di programmazione, modifica, eliminazione con conferma,
panoramica, completamento e storico, oltre a download e ripristino da **Backup**
con riepilogo e consenso esplicito. Le API sono disponibili anche direttamente.
Le osservazioni locali riportate nelle guide sono storiche e non certificano
la versione in uso. Per i risultati correnti consultare le ricevute dei sei
controlli host `inventory`, `inventory-ui`, `maintenance`, `maintenance-ui`,
`backup` e `backup-ui`, riferite al relativo codice. La revisione AI del sorgente
usa la stessa integrazione Codex e non è una valutazione indipendente.
Le verifiche locali non sostituiscono le prove con processo e browser reali.
