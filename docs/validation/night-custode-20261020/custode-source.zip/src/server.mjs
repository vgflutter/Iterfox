import http from 'node:http';
import { readFile, realpath } from 'node:fs/promises';
import { isIP } from 'node:net';
import { isAbsolute, relative, resolve, sep } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { HttpError } from './errors.mjs';
import { InventoryStore } from './store.mjs';

export const maxBodyBytes = 2 * 1024 * 1024;

const publicDirectory = fileURLToPath(new URL('../public/', import.meta.url));
// Only these local assets are exposed. Request paths never become file paths.
const publicRoutes = new Map([
  ['/', ['index.html', 'text/html; charset=utf-8']],
  ['/index.html', ['index.html', 'text/html; charset=utf-8']],
  ['/styles.css', ['styles.css', 'text/css; charset=utf-8']],
  ['/app.js', ['app.js', 'text/javascript; charset=utf-8']],
  ['/favicon.svg', ['favicon.svg', 'image/svg+xml']],
]);

async function servePublic(req, res, asset) {
  allowMethod(req, ['GET', 'HEAD']);
  const root = await realpath(publicDirectory);
  const path = await realpath(resolve(publicDirectory, asset[0]));
  const fromRoot = relative(root, path);
  if (isAbsolute(fromRoot) || fromRoot === '..' || fromRoot.startsWith(`..${sep}`)) {
    throw new HttpError(404, 'Risorsa non trovata.');
  }
  const body = await readFile(path);
  res.writeHead(200, {
    'Content-Type': asset[1],
    'Content-Length': body.length,
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'Content-Security-Policy': "default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'",
  });
  res.end(req.method === 'HEAD' ? undefined : body);
}

function json(res, status, value, headers = {}) {
  const body = JSON.stringify(value);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    ...headers,
  });
  res.end(body);
}

function allowMethod(req, allowed) {
  if (!allowed.includes(req.method)) {
    throw new HttpError(405, 'Metodo HTTP non consentito.', { Allow: allowed.join(', ') });
  }
}

function parseRequestTarget(target) {
  // Route the path actually sent by the client. URL() normalizes dot segments
  // and backslashes, which could turn an unsupported path into a write route.
  if (typeof target !== 'string' || !target.startsWith('/') || target.startsWith('//') ||
      /[\u0000-\u0020\u007f#]/u.test(target)) {
    throw new HttpError(400, 'Indirizzo della richiesta non valido.');
  }
  const queryStart = target.indexOf('?');
  const rawPath = queryStart === -1 ? target : target.slice(0, queryStart);
  let segments;
  try {
    segments = rawPath.split('/').map(segment => decodeURIComponent(segment));
  } catch {
    throw new HttpError(400, 'Indirizzo della richiesta non valido.');
  }
  if (segments.some(segment => segment === '.' || segment === '..' ||
      /[\/\\\u0000-\u001f\u007f]/u.test(segment))) {
    throw new HttpError(400, 'Percorso della richiesta non valido.');
  }
  return {
    pathname: segments.join('/'),
    searchParams: new URLSearchParams(queryStart === -1 ? '' : target.slice(queryStart + 1)),
  };
}

async function readBody(req) {
  return new Promise((resolveBody, reject) => {
    let size = 0;
    let chunks = [];
    let failed = false;
    const fail = error => {
      if (failed) return;
      failed = true;
      chunks = [];
      reject(error);
    };
    req.on('data', chunk => {
      // Continue draining rejected requests without retaining their contents.
      // Destroying the request here could also destroy the JSON error response.
      if (failed) return;
      size += chunk.length;
      if (size > maxBodyBytes) {
        fail(new HttpError(413, 'Il corpo HTTP supera il limite di 2 MiB.', { Connection: 'close' }));
      } else {
        chunks.push(chunk);
      }
    });
    req.once('aborted', () => fail(new HttpError(400, 'Richiesta interrotta.')));
    req.once('error', () => fail(new HttpError(400, 'Impossibile leggere il corpo della richiesta.')));
    req.once('end', () => {
      if (failed) return;
      resolveBody(Buffer.concat(chunks, size));
    });
    if (Number(req.headers['content-length']) > maxBodyBytes) {
      fail(new HttpError(413, 'Il corpo HTTP supera il limite di 2 MiB.', { Connection: 'close' }));
    }
  });
}

function parseJson(req, body) {
  const contentType = req.headers['content-type'];
  if (contentType && contentType.split(';', 1)[0].trim().toLowerCase() !== 'application/json') {
    throw new HttpError(415, 'Il corpo deve usare Content-Type: application/json.');
  }
  if (req.headers['content-encoding'] && req.headers['content-encoding'].toLowerCase() !== 'identity') {
    throw new HttpError(415, 'La compressione del corpo non è supportata.');
  }
  try {
    const text = new TextDecoder('utf-8', { fatal: true }).decode(body);
    return JSON.parse(text);
  } catch {
    throw new HttpError(400, 'Il corpo deve contenere JSON valido in UTF-8.');
  }
}

export function createRequestHandler(store) {
  return async (req, res) => {
    try {
      const { pathname, searchParams } = parseRequestTarget(req.url);
      const body = await readBody(req);

      if (publicRoutes.has(pathname)) {
        await servePublic(req, res, publicRoutes.get(pathname));
      } else if (pathname === '/api/health') {
        allowMethod(req, ['GET']);
        json(res, 200, { ok: true });
      } else if (pathname === '/api/backup') {
        allowMethod(req, ['GET']);
        json(res, 200, store.backup(), { 'Content-Disposition': 'attachment; filename="custode-backup.json"' });
      } else if (pathname === '/api/restore') {
        allowMethod(req, ['POST']);
        json(res, 200, store.restore(parseJson(req, body)));
      } else if (pathname === '/api/items') {
        allowMethod(req, ['GET', 'POST']);
        if (req.method === 'GET') {
          const filters = Object.fromEntries(['q', 'category', 'location'].map(key =>
            [key, searchParams.get(key) ?? '']));
          json(res, 200, store.list(filters));
        } else {
          const item = store.create(parseJson(req, body));
          json(res, 201, item, { Location: `/api/items/${encodeURIComponent(item.id)}` });
        }
      } else if (pathname === '/api/tasks') {
        allowMethod(req, ['GET', 'POST']);
        if (req.method === 'GET') {
          json(res, 200, store.listTasks());
        } else {
          const task = store.createTask(parseJson(req, body));
          json(res, 201, task, { Location: `/api/tasks/${encodeURIComponent(task.id)}` });
        }
      } else if (pathname === '/api/history') {
        allowMethod(req, ['GET']);
        json(res, 200, store.listHistory());
      } else if (pathname === '/api/overview') {
        allowMethod(req, ['GET']);
        json(res, 200, store.overview(searchParams.get('today') ?? undefined));
      } else {
        const match = /^\/api\/(items|tasks)\/([^/]+)(\/complete)?$/.exec(pathname);
        if (!match || (match[1] === 'items' && match[3])) throw new HttpError(404, 'Risorsa non trovata.');
        const [, collection, id, completion] = match;
        if (completion) {
          allowMethod(req, ['POST']);
          json(res, 200, store.completeTask(id, parseJson(req, body), req.headers['if-match']));
        } else {
          allowMethod(req, ['PATCH', 'DELETE']);
          if (req.method === 'PATCH') {
            const fields = parseJson(req, body);
            json(res, 200, collection === 'items' ? store.patch(id, fields) : store.patchTask(id, fields, req.headers['if-match']));
          } else {
            if (body.length !== 0) throw new HttpError(400, 'L’eliminazione non accetta un corpo HTTP.');
            if (collection === 'items') store.delete(id);
            else store.deleteTask(id, req.headers['if-match']);
            json(res, 200, { ok: true });
          }
        }
      }
    } catch (error) {
      if (req.aborted || res.destroyed) return;
      if (error instanceof HttpError) {
        json(res, error.status, { error: error.message }, error.headers);
      } else {
        console.error('Errore durante l’operazione sull’archivio:', error);
        json(res, 500, { error: 'Impossibile completare l’operazione sull’archivio.' });
      }
    } finally {
      // Invalid paths can be rejected before readBody installs its listeners.
      // A later stream error must not become an uncaught process error.
      req.once('error', () => {});
      req.resume();
    }
  };
}

function socketJsonError(socket, status, message, headers = {}) {
  if (socket.destroyed || !socket.writable) return;
  // CONNECT, protocol upgrades and parser failures have no ServerResponse.
  const body = JSON.stringify({ error: message });
  const lines = Object.entries({
    Connection: 'close',
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    ...headers,
  }).map(([name, value]) => `${name}: ${value}`);
  socket.end(`HTTP/1.1 ${status} ${http.STATUS_CODES[status]}\r\n${lines.join('\r\n')}\r\n\r\n${body}`);
}

export function createHttpServer(store) {
  const handler = createRequestHandler(store);
  const server = http.createServer({ maxHeaderSize: 16 * 1024 }, handler);
  server.requestTimeout = 30_000;
  server.headersTimeout = 10_000;
  server.keepAliveTimeout = 5_000;

  server.on('checkContinue', (req, res) => {
    // Reject a declared oversized body before asking the client to send it.
    if (!(Number(req.headers['content-length']) > maxBodyBytes)) res.writeContinue();
    handler(req, res);
  });
  server.on('checkExpectation', (req, res) => {
    json(res, 417, { error: 'Aspettativa HTTP non supportata.' }, { Connection: 'close' });
    req.once('error', () => {});
    req.resume();
  });
  server.on('connect', (_req, socket) => {
    socketJsonError(socket, 405, 'Metodo HTTP non consentito.', { Allow: 'GET, POST, PATCH, DELETE' });
  });
  server.on('upgrade', (_req, socket) => {
    socketJsonError(socket, 400, 'Il cambio di protocollo non è supportato.');
  });
  server.on('clientError', (error, socket) => {
    if (error.code === 'ECONNRESET') {
      socket.destroy();
      return;
    }
    const status = error.code === 'HPE_HEADER_OVERFLOW' ? 431 :
      error.code === 'ERR_HTTP_REQUEST_TIMEOUT' ? 408 : 400;
    socketJsonError(socket, status, 'Richiesta HTTP non valida o incompleta.');
  });
  return server;
}

function listenOptions(environment) {
  let host = environment.HOST || '127.0.0.1';
  if (host === 'localhost') host = '127.0.0.1';
  if (host !== '::1' && !(isIP(host) === 4 && host.startsWith('127.'))) {
    throw new Error('HOST deve essere un indirizzo loopback (127.0.0.1, ::1 o localhost).');
  }
  const rawPort = environment.PORT || '4380';
  if (!/^\d+$/.test(rawPort) || Number(rawPort) > 65535) {
    throw new Error('PORT deve essere un intero tra 0 e 65535.');
  }
  return { host, port: Number(rawPort) };
}

export function startServer(environment = process.env) {
  const options = listenOptions(environment);
  const store = new InventoryStore(environment.CUSTODE_DATA_DIR);
  const server = createHttpServer(store);

  let stopping = false;
  const shutdown = () => {
    if (stopping) return;
    stopping = true;
    server.close();
    const timeout = setTimeout(() => server.closeAllConnections(), 5000);
    timeout.unref();
    server.once('close', () => clearTimeout(timeout));
  };
  process.once('SIGINT', shutdown);
  process.once('SIGTERM', shutdown);
  server.once('close', () => {
    process.removeListener('SIGINT', shutdown);
    process.removeListener('SIGTERM', shutdown);
    store.close();
  });
  server.once('error', error => {
    console.error('Impossibile avviare il server Custode:', error.message);
    process.exitCode = 1;
    shutdown();
  });
  server.listen(options, () => {
    const address = server.address();
    const host = options.host.includes(':') ? `[${options.host}]` : options.host;
    console.log(`Custode: http://${host}:${address.port}`);
    console.log(`Archivio: ${store.path}`);
  });
  return server;
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  try {
    startServer();
  } catch (error) {
    console.error('Impossibile avviare Custode:', error.message);
    process.exitCode = 1;
  }
}
