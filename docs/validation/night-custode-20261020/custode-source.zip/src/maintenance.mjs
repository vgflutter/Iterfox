import { HttpError } from './errors.mjs';

const taskKeys = new Set(['itemId', 'title', 'dueDate', 'intervalDays', 'notes']);
const dayMilliseconds = 86_400_000;

function objectKeys(input) {
  if (input === null || typeof input !== 'object' || Array.isArray(input)) {
    throw new HttpError(400, 'Il corpo JSON deve essere un oggetto.');
  }
  return Object.keys(input);
}

// Civil dates use the proleptic Gregorian calendar, years 0001..9999.
// Validate before using Date: its parser silently normalizes impossible days.
export function validateCivilDate(value, field = 'dueDate') {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    throw new HttpError(400, `Il campo ${field} deve essere una data valida YYYY-MM-DD.`);
  }
  const [year, month, day] = value.split('-').map(Number);
  const leap = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  const days = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (year < 1 || month < 1 || month > 12 || day < 1 || day > days[month - 1]) {
    throw new HttpError(400, `Il campo ${field} deve essere una data valida YYYY-MM-DD (anni 0001–9999).`);
  }
  return value;
}

export function civilDay(value) {
  const [year, month, day] = value.split('-').map(Number);
  // setUTCFullYear avoids Date.UTC's special treatment of years 00..99.
  const date = new Date(0);
  date.setUTCFullYear(year, month - 1, day);
  return date.getTime() / dayMilliseconds;
}

export function addCivilDays(value, days) {
  const date = new Date((civilDay(value) + days) * dayMilliseconds);
  if (date.getUTCFullYear() > 9999) {
    throw new HttpError(400, 'La prossima scadenza supera il limite del calendario (9999-12-31).');
  }
  return date.toISOString().slice(0, 10);
}

export function localToday() {
  const date = new Date();
  return `${String(date.getFullYear()).padStart(4, '0')}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

export function validateTaskFields(input, { partial = false } = {}) {
  const keys = objectKeys(input);
  for (const key of keys) {
    if (!taskKeys.has(key)) throw new HttpError(400, `Campo non consentito: ${key}.`);
  }
  if (partial && keys.length === 0) throw new HttpError(400, 'Indicare almeno un campo da aggiornare.');
  if (!partial) {
    for (const key of ['itemId', 'title', 'dueDate']) {
      if (!Object.hasOwn(input, key)) throw new HttpError(400, `Il campo ${key} è obbligatorio.`);
    }
  }
  const fields = partial ? {} : { intervalDays: 0, notes: '' };
  for (const key of keys) {
    const value = input[key];
    if (key === 'intervalDays') {
      if (!Number.isInteger(value) || value < 0 || value > 3660) {
        throw new HttpError(400, 'Il campo intervalDays deve essere un intero tra 0 e 3660.');
      }
    } else if (key === 'dueDate') {
      validateCivilDate(value);
    } else {
      if (typeof value !== 'string') throw new HttpError(400, `Il campo ${key} deve essere una stringa.`);
      if ((key === 'itemId' || key === 'title') && value.trim().length === 0) {
        throw new HttpError(400, `Il campo ${key} non può essere vuoto.`);
      }
      const maximum = key === 'title' ? 200 : key === 'notes' ? 5000 : undefined;
      if (maximum !== undefined && [...value].length > maximum) {
        throw new HttpError(400, `Il campo ${key} può contenere al massimo ${maximum} caratteri.`);
      }
    }
    fields[key] = value;
  }
  return fields;
}

export function validateCompletion(input) {
  const keys = objectKeys(input);
  for (const key of keys) {
    if (key !== 'completedOn') throw new HttpError(400, `Campo non consentito: ${key}.`);
  }
  return validateCivilDate(input.completedOn, 'completedOn');
}

export function maintenanceOverview(tasks, today = localToday()) {
  validateCivilDate(today, 'today');
  const endDay = civilDay(today) + 30;
  const active = tasks.filter(task => !task.completed).sort((a, b) =>
    a.dueDate < b.dueDate ? -1 : a.dueDate > b.dueDate ? 1 : 0);
  return {
    overdue: active.filter(task => task.dueDate < today).length,
    today: active.filter(task => task.dueDate === today).length,
    upcoming: active.filter(task => task.dueDate > today && civilDay(task.dueDate) <= endDay).length,
    tasks: active,
  };
}
