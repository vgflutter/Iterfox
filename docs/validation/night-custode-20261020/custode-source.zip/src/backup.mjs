import { HttpError } from './errors.mjs';
import { validateItemFields } from './inventory.mjs';
import { validateCivilDate, validateTaskFields } from './maintenance.mjs';

const itemKeys = ['id', 'name', 'category', 'location', 'notes', 'createdAt', 'updatedAt'];
const taskKeys = ['id', 'itemId', 'title', 'dueDate', 'intervalDays', 'notes', 'completed', 'createdAt', 'updatedAt'];
const historyKeys = ['id', 'taskId', 'itemId', 'title', 'completedOn'];

function shape(value, required, optional, path) {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) {
    throw new HttpError(400, `${path} deve essere un oggetto JSON.`);
  }
  for (const key of Object.keys(value)) {
    if (!required.includes(key) && !optional.includes(key)) {
      throw new HttpError(400, `Campo non consentito in ${path}: ${key}.`);
    }
  }
  for (const key of required) {
    if (!Object.hasOwn(value, key)) throw new HttpError(400, `Manca il campo ${path}.${key}.`);
  }
}

function identifier(value, path) {
  // IDs are opaque strings, not necessarily UUIDs. Reject values that cannot
  // round-trip through SQLite text or the application's encoded URL segments.
  if (typeof value !== 'string' || value.trim().length === 0 || !value.isWellFormed() ||
      value === '.' || value === '..' || /[/\\\u0000-\u001f\u007f]/u.test(value)) {
    throw new HttpError(400, `Identificativo non valido in ${path}.`);
  }
  return value;
}

function timestamp(value, path) {
  // Accept ISO timestamps with an explicit timezone, without converting their
  // representation. Check the civil day before Date.parse can normalize it.
  const match = typeof value === 'string' &&
    /^(\d{4}-\d{2}-\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d{1,3})?(Z|[+-](\d{2}):(\d{2}))$/.exec(value);
  if (!match) throw new HttpError(400, `Timestamp ISO non valido in ${path}.`);
  validateCivilDate(match[1], path);
  if (Number(match[2]) > 23 || Number(match[3]) > 59 || Number(match[4]) > 59 ||
      Number(match[6] ?? 0) > 23 || Number(match[7] ?? 0) > 59 || !Number.isFinite(Date.parse(value))) {
    throw new HttpError(400, `Timestamp ISO non valido in ${path}.`);
  }
  return Date.parse(value);
}

function timestamps(record, path) {
  const created = timestamp(record.createdAt, `${path}.createdAt`);
  const updated = timestamp(record.updatedAt, `${path}.updatedAt`);
  if (updated < created) {
    throw new HttpError(400, `${path}.updatedAt non può precedere createdAt.`);
  }
}

function boolean(value, path) {
  if (typeof value !== 'boolean') throw new HttpError(400, `${path} deve essere un booleano.`);
}

function unique(records, path) {
  const ids = new Set();
  for (const [index, record] of records.entries()) {
    const id = identifier(record.id, `${path}[${index}].id`);
    if (ids.has(id)) throw new HttpError(400, `Identificativo duplicato in ${path}: ${id}.`);
    ids.add(id);
  }
  return ids;
}

function reference(value, ids, path) {
  identifier(value, path);
  if (!ids.has(value)) throw new HttpError(400, `Riferimento inesistente in ${path}.`);
}

// Fully validate before opening a write transaction. No trimming, coercion,
// truncation, generated IDs, timestamp replacement or dangling-link repairs.
export function validateRestore(input) {
  shape(input, ['backup', 'mode'], [], 'Richiesta');
  if (input.mode !== 'replace') {
    throw new HttpError(400, 'Il ripristino richiede mode: "replace" e sostituisce tutti i dati.');
  }
  const backup = input.backup;
  shape(backup, ['schemaVersion', 'items', 'tasks', 'history'], [], 'backup');
  if (backup.schemaVersion !== 1) throw new HttpError(400, 'Versione del backup non supportata: è richiesta schemaVersion 1.');
  for (const key of ['items', 'tasks', 'history']) {
    if (!Array.isArray(backup[key])) throw new HttpError(400, `backup.${key} deve essere un array.`);
  }

  const items = backup.items.map((record, index) => {
    const path = `backup.items[${index}]`;
    shape(record, itemKeys, [], path);
    const { id, name, category, location, notes, createdAt, updatedAt } = record;
    validateItemFields({ name, category, location, notes });
    timestamps(record, path);
    return { id, name, category, location, notes, createdAt, updatedAt };
  });
  const tasks = backup.tasks.map((record, index) => {
    const path = `backup.tasks[${index}]`;
    shape(record, taskKeys, ['deleted'], path);
    const { id, itemId, title, dueDate, intervalDays, notes, completed, createdAt, updatedAt } = record;
    validateTaskFields({ itemId, title, dueDate, intervalDays, notes });
    boolean(completed, `${path}.completed`);
    // Version 1 may also contain ordinary API task records, where deleted is
    // absent. Its documented default is false; exports always include it.
    const deleted = Object.hasOwn(record, 'deleted') ? record.deleted : false;
    boolean(deleted, `${path}.deleted`);
    timestamps(record, path);
    return { id, itemId, title, dueDate, intervalDays, notes, completed, createdAt, updatedAt, deleted };
  });
  const history = backup.history.map((record, index) => {
    const path = `backup.history[${index}]`;
    shape(record, historyKeys, [], path);
    const { id, taskId, itemId, title, completedOn } = record;
    // Event titles have the same literal-text constraints as task titles,
    // but are snapshots: they need not equal the current title or itemId.
    validateTaskFields({ title }, { partial: true });
    validateCivilDate(completedOn, `${path}.completedOn`);
    return { id, taskId, itemId, title, completedOn };
  });

  const itemIds = unique(items, 'backup.items');
  const taskIds = unique(tasks, 'backup.tasks');
  unique(history, 'backup.history');
  for (const [index, task] of tasks.entries()) {
    reference(task.itemId, itemIds, `backup.tasks[${index}].itemId`);
  }
  for (const [index, event] of history.entries()) {
    reference(event.taskId, taskIds, `backup.history[${index}].taskId`);
    reference(event.itemId, itemIds, `backup.history[${index}].itemId`);
  }
  return { schemaVersion: 1, items, tasks, history };
}
