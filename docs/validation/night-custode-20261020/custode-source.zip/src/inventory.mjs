import { HttpError } from './errors.mjs';

const limits = Object.freeze({ name: 200, category: 100, location: 100, notes: 5000 });

// Validate the entire input before the store starts a write transaction. Keep
// text exactly as received: whitespace, Unicode and markup belong to the user.
export function validateItemFields(input, { partial = false } = {}) {
  if (input === null || typeof input !== 'object' || Array.isArray(input)) {
    throw new HttpError(400, 'Il corpo JSON deve essere un oggetto.');
  }

  const keys = Object.keys(input);
  for (const key of keys) {
    if (!Object.hasOwn(limits, key)) {
      throw new HttpError(400, `Campo non consentito: ${key}.`);
    }
  }
  if (!partial && !Object.hasOwn(input, 'name')) {
    throw new HttpError(400, 'Il nome oggetto è obbligatorio.');
  }
  if (partial && keys.length === 0) {
    throw new HttpError(400, 'Indicare almeno un campo da aggiornare.');
  }

  const fields = {};
  for (const [key, maximum] of Object.entries(limits)) {
    if (!Object.hasOwn(input, key)) {
      if (!partial) fields[key] = '';
      continue;
    }
    const value = input[key];
    if (typeof value !== 'string') {
      throw new HttpError(400, `Il campo ${key} deve essere una stringa.`);
    }
    if (key === 'name' && value.trim().length === 0) {
      throw new HttpError(400, 'Il nome oggetto non può essere vuoto.');
    }
    // Count Unicode code points, rather than UTF-16 units (e.g. an emoji is
    // one character). No normalization or HTML transformation is performed.
    if ([...value].length > maximum) {
      throw new HttpError(400, `Il campo ${key} può contenere al massimo ${maximum} caratteri.`);
    }
    fields[key] = value;
  }
  return fields;
}

export function filterItems(items, { q = '', category = '', location = '' } = {}) {
  const query = q.toLowerCase();
  const categoryQuery = category.toLowerCase();
  const locationQuery = location.toLowerCase();
  return items.filter(item =>
    (!categoryQuery || item.category.toLowerCase() === categoryQuery) &&
    (!locationQuery || item.location.toLowerCase() === locationQuery) &&
    (!query || ['name', 'category', 'location', 'notes'].some(key =>
      item[key].toLowerCase().includes(query)))
  );
}
