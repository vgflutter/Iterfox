import { randomUUID } from 'node:crypto';
import { lstatSync, mkdirSync, realpathSync } from 'node:fs';
import { homedir } from 'node:os';
import { dirname, isAbsolute, join, relative, resolve, sep } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { fileURLToPath } from 'node:url';
import { HttpError } from './errors.mjs';
import { validateRestore } from './backup.mjs';
import { filterItems, validateItemFields } from './inventory.mjs';
import { addCivilDays, maintenanceOverview, validateCompletion, validateTaskFields } from './maintenance.mjs';

const projectDirectory = realpathSync(fileURLToPath(new URL('..', import.meta.url)));
export const defaultDataDirectory = join(homedir(), '.local', 'share', 'custode');
const columns = 'id, name, category, location, notes, createdAt, updatedAt';
const textFields = ['name', 'category', 'location', 'notes'];
const taskColumns = 'id, itemId, title, dueDate, intervalDays, notes, completed, createdAt, updatedAt';
const historyColumns = 'id, taskId, itemId, title, completedOn';

function storedText(item) {
  // Encode each string as JSON: the native SQLite text interface truncates
  // reads at embedded NULs and replaces isolated UTF-16 surrogates. JSON
  // escapes those values while keeping the HTTP round-trip lossless.
  return textFields.map(key => JSON.stringify(item[key]));
}

function readItem(row) {
  if (!row) return undefined;
  const item = { ...row };
  for (const key of textFields) item[key] = JSON.parse(row[key]);
  return item;
}

function readTask(row) {
  if (!row) return undefined;
  return { ...row, title: JSON.parse(row.title), notes: JSON.parse(row.notes), completed: Boolean(row.completed) };
}

function taskValues(task) {
  return [task.itemId, JSON.stringify(task.title), task.dueDate, task.intervalDays, JSON.stringify(task.notes)];
}

function readHistory(row) {
  return { ...row, title: JSON.parse(row.title) };
}

function nextUpdatedAt(current) {
  const next = new Date(Math.max(Date.now(), Date.parse(current.updatedAt) + 1));
  if (!Number.isFinite(next.getTime()) || next.getUTCFullYear() > 9999) {
    throw new HttpError(400, 'Impossibile aggiornare il timestamp oltre il limite supportato (9999-12-31). Nessun dato è stato modificato.');
  }
  return next.toISOString();
}

function within(parent, child) {
  const path = relative(parent, child);
  return path === '' || (!isAbsolute(path) && path !== '..' && !path.startsWith(`..${sep}`));
}

function prepareDataDirectory(directory) {
  const requested = resolve(directory || defaultDataDirectory);
  // Resolve existing ancestors too, so a symlink cannot redirect storage into
  // the source tree. Do this before creating any directory.
  let ancestor = requested;
  let canonical;
  while (canonical === undefined) {
    try {
      canonical = resolve(realpathSync(ancestor), relative(ancestor, requested));
    } catch (error) {
      if (error.code !== 'ENOENT' || dirname(ancestor) === ancestor) throw error;
      ancestor = dirname(ancestor);
    }
  }
  if (within(projectDirectory, requested) || within(projectDirectory, canonical)) {
    throw new Error('CUSTODE_DATA_DIR deve trovarsi fuori dal repository.');
  }
  mkdirSync(canonical, { recursive: true, mode: 0o700 });
  return canonical;
}

export class InventoryStore {
  constructor(directory) {
    this.directory = prepareDataDirectory(directory);
    this.path = join(this.directory, 'custode.sqlite');
    try {
      if (lstatSync(this.path).isSymbolicLink()) {
        throw new Error('Il file di archivio non può essere un collegamento simbolico.');
      }
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
    }

    this.database = new DatabaseSync(this.path);
    try {
      this.database.exec('PRAGMA busy_timeout = 5000; PRAGMA foreign_keys = ON;');
      const version = this.database.prepare('PRAGMA user_version').get().user_version;
      if (![0, 1, 2].includes(version)) {
        throw new Error(`Versione archivio non supportata: ${version}.`);
      }
      if (version === 0 && this.database.prepare(
        "SELECT name FROM sqlite_schema WHERE name NOT LIKE 'sqlite_%' LIMIT 1"
      ).get()) {
        throw new Error('Archivio non riconosciuto: nessun dato è stato sostituito.');
      }
      const checks = this.database.prepare('PRAGMA quick_check').all();
      if (checks.length !== 1 || checks[0].quick_check !== 'ok') {
        throw new Error('Archivio danneggiato: verificare i dati prima di riavviare.');
      }
      this.database.exec('PRAGMA journal_mode = WAL; PRAGMA synchronous = FULL;');
      if (version < 2) {
        this.transaction(() => {
          if (version === 0) {
            this.database.exec(`
              CREATE TABLE items (
                id TEXT PRIMARY KEY NOT NULL,
                name TEXT NOT NULL,
                category TEXT NOT NULL DEFAULT '',
                location TEXT NOT NULL DEFAULT '',
                notes TEXT NOT NULL DEFAULT '',
                createdAt TEXT NOT NULL,
                updatedAt TEXT NOT NULL
              ) STRICT;
            `);
          }
          // Version 1's items table and its contents remain untouched. Both
          // new tables and the version marker commit (or roll back) together.
          this.database.exec(`
            CREATE TABLE tasks (
              id TEXT PRIMARY KEY NOT NULL,
              itemId TEXT NOT NULL REFERENCES items(id) ON DELETE RESTRICT,
              title TEXT NOT NULL,
              dueDate TEXT NOT NULL,
              intervalDays INTEGER NOT NULL CHECK (intervalDays BETWEEN 0 AND 3660),
              notes TEXT NOT NULL,
              completed INTEGER NOT NULL DEFAULT 0 CHECK (completed IN (0, 1)),
              createdAt TEXT NOT NULL,
              updatedAt TEXT NOT NULL,
              deleted INTEGER NOT NULL DEFAULT 0 CHECK (deleted IN (0, 1))
            ) STRICT;
            CREATE TABLE history (
              id TEXT PRIMARY KEY NOT NULL,
              taskId TEXT NOT NULL REFERENCES tasks(id) ON DELETE RESTRICT,
              itemId TEXT NOT NULL REFERENCES items(id) ON DELETE RESTRICT,
              title TEXT NOT NULL,
              completedOn TEXT NOT NULL
            ) STRICT;
            CREATE INDEX tasks_item ON tasks(itemId);
            CREATE INDEX tasks_due ON tasks(deleted, completed, dueDate);
            CREATE INDEX history_task ON history(taskId);
            CREATE INDEX history_item ON history(itemId);
            PRAGMA user_version = 2;
          `);
        });
      }
      if (this.database.prepare('PRAGMA foreign_key_check').all().length !== 0) {
        throw new Error('Archivio con riferimenti non validi: nessun dato è stato sostituito.');
      }
      this.selectAll = this.database.prepare(`SELECT ${columns} FROM items ORDER BY rowid`);
      this.selectOne = this.database.prepare(`SELECT ${columns} FROM items WHERE id = ?`);
      this.insert = this.database.prepare(`INSERT INTO items (${columns}) VALUES (?, ?, ?, ?, ?, ?, ?)`);
      this.update = this.database.prepare(
        'UPDATE items SET name = ?, category = ?, location = ?, notes = ?, updatedAt = ? WHERE id = ?'
      );
      this.remove = this.database.prepare('DELETE FROM items WHERE id = ?');
      this.itemLinks = this.database.prepare(`
        SELECT 1 FROM tasks WHERE itemId = ?
        UNION ALL SELECT 1 FROM history WHERE itemId = ? LIMIT 1
      `);
      this.tasks = {
        all: this.database.prepare(`SELECT ${taskColumns} FROM tasks WHERE deleted = 0 ORDER BY rowid`),
        one: this.database.prepare(`SELECT ${taskColumns} FROM tasks WHERE id = ? AND deleted = 0`),
        insert: this.database.prepare(`INSERT INTO tasks (${taskColumns}) VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?)`),
        update: this.database.prepare(`
          UPDATE tasks SET itemId = ?, title = ?, dueDate = ?, intervalDays = ?, notes = ?, updatedAt = ? WHERE id = ?
        `),
        complete: this.database.prepare('UPDATE tasks SET dueDate = ?, completed = ?, updatedAt = ? WHERE id = ?'),
        remove: this.database.prepare('DELETE FROM tasks WHERE id = ?'),
        archive: this.database.prepare('UPDATE tasks SET deleted = 1, updatedAt = ? WHERE id = ?'),
      };
      this.history = {
        all: this.database.prepare(`SELECT ${historyColumns} FROM history ORDER BY completedOn DESC, rowid DESC`),
        forTask: this.database.prepare('SELECT 1 FROM history WHERE taskId = ? LIMIT 1'),
        insert: this.database.prepare(`INSERT INTO history (${historyColumns}) VALUES (?, ?, ?, ?, ?)`),
      };
      this.backupTasks = this.database.prepare(`SELECT ${taskColumns}, deleted FROM tasks ORDER BY rowid`);
      this.backupHistory = this.database.prepare(`SELECT ${historyColumns} FROM history ORDER BY rowid`);
      this.restoreTask = this.database.prepare(`INSERT INTO tasks (${taskColumns}, deleted) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);
    } catch (error) {
      this.database.close();
      throw error;
    }
  }

  transaction(operation, { readOnly = false } = {}) {
    this.database.exec(readOnly ? 'BEGIN' : 'BEGIN IMMEDIATE');
    try {
      const result = operation();
      this.database.exec('COMMIT');
      return result;
    } catch (error) {
      try {
        this.database.exec('ROLLBACK');
      } catch (rollbackError) {
        // Keep the original error and make an unsuccessful rollback visible.
        console.error('Errore durante il rollback dell’archivio:', rollbackError);
      }
      throw error;
    }
  }

  list(filters) {
    return filterItems(this.selectAll.all().map(readItem), filters);
  }

  create(input) {
    const fields = validateItemFields(input);
    return this.transaction(() => {
      const id = randomUUID();
      const timestamp = new Date().toISOString();
      this.insert.run(id, ...storedText(fields), timestamp, timestamp);
      return readItem(this.selectOne.get(id));
    });
  }

  patch(id, input) {
    const fields = validateItemFields(input, { partial: true });
    return this.transaction(() => {
      const current = readItem(this.selectOne.get(id));
      if (!current) throw new HttpError(404, 'Oggetto non trovato.');
      const changed = { ...current, ...fields };
      // Keep update times monotonic even for consecutive writes in one
      // millisecond or when the system clock moves backwards.
      const updatedAt = nextUpdatedAt(current);
      this.update.run(...storedText(changed), updatedAt, id);
      return readItem(this.selectOne.get(id));
    });
  }

  delete(id) {
    this.transaction(() => {
      if (!this.selectOne.get(id)) throw new HttpError(404, 'Oggetto non trovato.');
      if (this.itemLinks.get(id, id)) {
        throw new HttpError(409, 'L’oggetto è collegato a interventi o allo storico e non può essere eliminato. Nessun dato è stato rimosso.');
      }
      if (this.remove.run(id).changes === 0) throw new HttpError(404, 'Oggetto non trovato.');
    });
  }

  requireItem(id) {
    const item = this.selectOne.get(id);
    if (!item || item.id !== id) throw new HttpError(400, 'Il campo itemId deve indicare un oggetto esistente.');
  }

  requireTask(id) {
    const task = readTask(this.tasks.one.get(id));
    if (!task || task.id !== id) throw new HttpError(404, 'Intervento non trovato.');
    return task;
  }

  listTasks() {
    return this.tasks.all.all().map(readTask);
  }

  createTask(input) {
    const fields = validateTaskFields(input);
    return this.transaction(() => {
      this.requireItem(fields.itemId);
      const id = randomUUID();
      const timestamp = new Date().toISOString();
      this.tasks.insert.run(id, ...taskValues(fields), timestamp, timestamp);
      return this.requireTask(id);
    });
  }

  checkTaskVersion(task, ifMatch) {
    if (ifMatch !== undefined && ifMatch !== '*' && ifMatch !== JSON.stringify(task.updatedAt)) {
      throw new HttpError(409, 'L’intervento è stato modificato in un’altra finestra. Nessun dato è stato modificato o eliminato da questa richiesta. Rileggi interventi e storico prima di riprovare.');
    }
  }

  patchTask(id, input, ifMatch) {
    const fields = validateTaskFields(input, { partial: true });
    return this.transaction(() => {
      const current = this.requireTask(id);
      this.checkTaskVersion(current, ifMatch);
      const changed = { ...current, ...fields };
      this.requireItem(changed.itemId);
      this.tasks.update.run(...taskValues(changed), nextUpdatedAt(current), id);
      return this.requireTask(id);
    });
  }

  deleteTask(id, ifMatch) {
    this.transaction(() => {
      const current = this.requireTask(id);
      this.checkTaskVersion(current, ifMatch);
      if (this.history.forTask.get(id)) {
        // Retain the identity behind historical events. It is no longer
        // listed or editable, but foreign keys never become dangling.
        this.tasks.archive.run(nextUpdatedAt(current), id);
      } else {
        this.tasks.remove.run(id);
      }
    });
  }

  completeTask(id, input, ifMatch) {
    const completedOn = validateCompletion(input);
    return this.transaction(() => {
      const current = this.requireTask(id);
      if (current.completed) throw new HttpError(409, 'Questo intervento è già stato completato.');
      this.checkTaskVersion(current, ifMatch);
      // Calculate and validate the next date before writing either record.
      const recurring = current.intervalDays > 0;
      const dueDate = recurring ? addCivilDays(completedOn, current.intervalDays) : current.dueDate;
      this.history.insert.run(randomUUID(), id, current.itemId, JSON.stringify(current.title), completedOn);
      this.tasks.complete.run(dueDate, recurring ? 0 : 1, nextUpdatedAt(current), id);
      return this.requireTask(id);
    });
  }

  listHistory() {
    return this.history.all.all().map(readHistory);
  }

  backup() {
    // One SQLite read snapshot, including changes from other local processes.
    // Array order records insertion order, including historical same-day ties.
    return this.transaction(() => ({
      schemaVersion: 1,
      items: this.selectAll.all().map(readItem),
      tasks: this.backupTasks.all().map(row => ({ ...readTask(row), deleted: Boolean(row.deleted) })),
      history: this.backupHistory.all().map(readHistory),
    }), { readOnly: true });
  }

  restore(input) {
    const backup = validateRestore(input);
    this.transaction(() => {
      // Foreign keys remain enabled. Delete children first, insert parents
      // first; every deletion and insertion belongs to this single commit.
      this.database.exec('DELETE FROM history; DELETE FROM tasks; DELETE FROM items;');
      for (const item of backup.items) {
        this.insert.run(item.id, ...storedText(item), item.createdAt, item.updatedAt);
      }
      for (const task of backup.tasks) {
        this.restoreTask.run(task.id, ...taskValues(task), Number(task.completed), task.createdAt, task.updatedAt, Number(task.deleted));
      }
      for (const event of backup.history) {
        this.history.insert.run(event.id, event.taskId, event.itemId, JSON.stringify(event.title), event.completedOn);
      }
    });
    return { ok: true };
  }

  overview(today) {
    return maintenanceOverview(this.listTasks(), today);
  }

  close() {
    this.database.close();
  }
}
