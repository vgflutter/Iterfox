const element = id => document.getElementById(id);
const dialog = element('item-dialog');
const form = element('item-form');
const newItemButton = element('new-item');
const saveButton = element('save-item');
const deleteDialog = element('delete-dialog');
const deleteForm = element('delete-form');
const searchInput = element('item-search');
const inventoryTitle = element('inventory-title');
const fieldNames = ['name', 'category', 'location', 'notes'];
const limits = { name: 200, category: 100, location: 100, notes: 5000 };
const newItemDraft = Object.fromEntries(fieldNames.map(name => [name, '']));
let items = [];
let loadedQuery = null;
let loadSequence = 0;
let loadController;
let searchTimer;
let saving = false;
let formOpener = newItemButton;
let editingItem = null;
let initialFormValues = null;
let formErrorKind = null;
// Keep uncertain creation blocked across closing/reopening the draft. Only a
// successful read of the complete inventory permits another explicit POST.
let itemCreationRecovery = null;
let reviewingItemCreation = false;
let needsMutationRefresh = false;
let deleting = false;
let deletionItem = null;
let deleteOpener = newItemButton;
let currentView = 'inventory';

const taskDialog = element('task-dialog');
const taskForm = element('task-form');
const taskTitle = element('maintenance-title');
const taskFieldNames = ['title', 'itemId', 'dueDate', 'intervalDays', 'notes'];
const taskDraft = { title: '', itemId: '', dueDate: '', intervalDays: '0', notes: '' };
let taskOpener = element('new-task');
let taskSaving = false;
let taskFormErrorKind;
let editingTask = null;
let initialTaskFormValues = null;
let taskSelectedItemId = '';
let taskEditBlocked = false;
// A new-task draft keeps its uncertainty across closing and editing other
// tasks. Only a successful read of all current tasks permits another POST.
let taskCreationRecovery = null;
let reviewingTaskCreation = false;
let taskItems = [];
let taskItemsReady = false;
let taskItemsSequence = 0;
let taskItemsController;
let maintenanceSequence = 0;
let maintenanceController;
let taskMutationConfirmed = '';
const completionDialog = element('completion-dialog');
const completionForm = element('completion-form');
const completionDate = element('completion-date');
const historyTitle = element('history-title');
const completionDrafts = new Map();
// An uncertain write must be checked with fresh reads before another attempt.
const completionIssues = new Map();
let completionTask = null;
let completionOpener = taskTitle;
let completionSaving = false;
const deleteTaskDialog = element('delete-task-dialog');
const deleteTaskForm = element('delete-task-form');
let deletionTask = null;
let taskDeleting = false;
let taskDeleteBlocked = false;
let taskDeleteOpener = taskTitle;
const restoreDialog = element('restore-dialog');
const restoreForm = element('restore-form');
const backupFile = element('backup-file');
const backupTitle = element('backup-page-title');
const maxRestoreBytes = 2 * 1024 * 1024;
let selectedBackup = null;
let backupFileSequence = 0;
let readingBackup = false;
let downloadingBackup = false;
let restoringBackup = false;
let restoreBlocked = false;
let restoreOpener = element('restore-backup');

class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
}

async function requestJSON(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { Accept: 'application/json', ...options.headers },
    cache: 'no-store',
  });
  // DELETE may confirm success with no response body.
  if (response.status === 204) return undefined;
  let data;
  try {
    data = await response.json();
  } catch {
    throw new ApiError('Il servizio ha restituito una risposta inattesa. Verifica l’elenco prima di riprovare.', response.status);
  }
  if (!response.ok) {
    throw new ApiError(typeof data?.error === 'string' ? data.error : 'Operazione non riuscita.', response.status);
  }
  return data;
}

function isItem(item) {
  return item !== null && typeof item === 'object' &&
    typeof item.id === 'string' && item.id.length > 0 &&
    fieldNames.every(name => typeof item[name] === 'string');
}

function node(tag, className, text) {
  const result = document.createElement(tag);
  if (className) result.className = className;
  if (text !== undefined) result.textContent = text;
  return result;
}

function itemCard(item, index) {
  const entry = node('li');
  const card = node('article', 'item-card');
  card.dataset.itemId = item.id;
  const heading = node('div', 'card-heading');
  const symbol = node('span', 'item-symbol');
  symbol.setAttribute('aria-hidden', 'true');
  // Clone a trusted local illustration; user content is always textContent.
  symbol.append(document.querySelector('#inventory-tab svg').cloneNode(true));
  const title = node('h4', '', item.name);
  title.id = `item-title-${index}`;
  card.setAttribute('aria-labelledby', title.id);
  heading.append(symbol, title);
  const details = node('dl', 'item-details');
  for (const [field, label] of [['category', 'Categoria'], ['location', 'Posizione']]) {
    const detail = node('div');
    const value = node('dd', item[field] ? '' : 'unspecified', item[field] || 'Non indicata');
    detail.append(node('dt', '', label), value);
    details.append(detail);
  }
  card.append(heading, details);
  if (item.notes) {
    const notes = node('div', 'item-notes');
    notes.append(node('p', 'item-notes-label', 'Note'), node('p', 'item-notes-text', item.notes));
    card.append(notes);
  }
  const actions = node('div', 'card-actions');
  for (const [action, label, open] of [
    ['edit', 'Modifica', openForm],
    ['delete', 'Elimina', openDelete],
  ]) {
    const button = node('button', `button ${action === 'delete' ? 'button-delete' : 'button-secondary'}`, label);
    button.type = 'button';
    button.setAttribute('aria-label', `${label} ${item.name}`);
    button.setAttribute('aria-haspopup', 'dialog');
    button.setAttribute('aria-controls', action === 'delete' ? 'delete-dialog' : 'item-dialog');
    button.dataset.itemId = item.id;
    button.dataset.itemAction = action;
    button.addEventListener('click', event => open(event, item));
    actions.append(button);
  }
  card.append(actions);
  entry.append(card);
  return entry;
}

function itemCount(query) {
  const count = items.length;
  return query
    ? `${count} ${count === 1 ? 'risultato' : 'risultati'}`
    : `${count} ${count === 1 ? 'oggetto' : 'oggetti'}`;
}

function renderItems(query) {
  const count = items.length;
  element('items-summary').textContent = itemCount(query);
  // A filtered result count is not the size of the household inventory.
  if (!query) element('nav-count').textContent = String(count);
  element('item-list').replaceChildren(...items.map(itemCard));
  element('item-list').hidden = count === 0;
  element('empty-state').hidden = Boolean(query) || count !== 0;
  element('no-results-state').hidden = !query || count !== 0;
  element('no-results-query').textContent = `«${query}»`;
}

function invalidateListLoad() {
  // Invalidate immediately on input, including during the debounce interval.
  // Aborting alone is insufficient if an older response has already arrived.
  loadSequence += 1;
  clearTimeout(searchTimer);
  loadController?.abort();
  loadController = undefined;
  return loadSequence;
}

function showListLoading(query) {
  element('inventory-results').setAttribute('aria-busy', 'true');
  element('clear-search').hidden = !query;
  element('nav-count').hidden = Boolean(query);
  if (!query) element('nav-count').textContent = '–';
  element('list-error').hidden = true;
  element('retry-items').disabled = true;
  element('refresh-items').disabled = true;
  element('loading-state').textContent = query ? 'Ricerca degli oggetti…' : 'Caricamento dell’inventario…';
  element('loading-state').hidden = false;
  element('empty-state').hidden = true;
  element('no-results-state').hidden = true;
  element('item-list').hidden = true;
  element('items-summary').textContent = query ? 'Ricerca in corso…' : 'Caricamento…';
}

async function loadItems() {
  // Loading hides cards, empty-state actions and retry, and disables refresh.
  // Keep keyboard focus visible, then restore the action only if the user has
  // stayed on the heading while waiting. Never move focus out of a dialog.
  const active = document.activeElement;
  const focusReturn = currentView === 'inventory' && !dialog.open && !deleteDialog.open && !taskDialog.open && !completionDialog.open && !deleteTaskDialog.open && (
    element('inventory-results').contains(active) ||
    active === element('retry-items') || active === element('refresh-items')
  ) ? active : null;
  if (focusReturn) inventoryTitle.focus();
  const query = searchInput.value;
  const sequence = invalidateListLoad();
  const controller = new AbortController();
  let timedOut = false;
  const timeout = setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, 10000);
  loadController = controller;
  showListLoading(query);
  try {
    const params = new URLSearchParams({ q: query });
    const result = await requestJSON(query ? `/api/items?${params}` : '/api/items', { signal: controller.signal });
    if (sequence !== loadSequence) return;
    if (!Array.isArray(result) || !result.every(isItem)) {
      throw new ApiError('Il servizio ha restituito un elenco non valido.');
    }
    items = result;
    loadedQuery = query;
    needsMutationRefresh = false;
    renderItems(query);
  } catch (error) {
    if (sequence !== loadSequence) return;
    const message = timedOut
      ? 'Il servizio non ha risposto in tempo. Controlla che Custode sia in esecuzione e riprova.'
      : error instanceof ApiError ? error.message : 'Controlla che Custode sia in esecuzione e riprova.';
    // Keep previous cards only when they belong to this exact query. In
    // particular, a failed search must not present the whole archive as hits.
    const showPrevious = loadedQuery === query && items.length > 0;
    element('item-list').hidden = !showPrevious;
    element('list-error-title').textContent = query ? 'Ricerca non disponibile' : 'Inventario non disponibile';
    element('list-error-message').textContent = (needsMutationRefresh
      ? 'L’operazione è stata confermata dal server, ma non è stato possibile aggiornare l’elenco. '
      : '') + (showPrevious
      ? 'Stai vedendo l’ultimo elenco caricato, che potrebbe non essere aggiornato. '
      : '') + `${message} Puoi riprovare o aggiungere un oggetto con Nuovo oggetto.`;
    element('list-error').hidden = false;
    element('items-summary').textContent = showPrevious
      ? `${itemCount(query)} · da aggiornare`
      : query ? 'Ricerca non disponibile' : 'Elenco non disponibile';
  } finally {
    clearTimeout(timeout);
    if (sequence === loadSequence) {
      loadController = undefined;
      element('inventory-results').setAttribute('aria-busy', 'false');
      element('loading-state').hidden = true;
      element('retry-items').disabled = false;
      element('refresh-items').disabled = false;
      if (focusReturn && currentView === 'inventory' && document.activeElement === inventoryTitle && !dialog.open && !deleteDialog.open && !taskDialog.open && !completionDialog.open && !deleteTaskDialog.open) {
        restoreFocus(focusReturn);
      }
    }
  }
}

function searchChanged(event) {
  invalidateListLoad();
  showListLoading(searchInput.value);
  // Wait for a complete input when a keyboard uses composition (IME).
  if (event.isComposing) return;
  if (!searchInput.value) void loadItems();
  else searchTimer = setTimeout(loadItems, 200);
}

function clearSearch() {
  searchInput.value = '';
  searchInput.focus();
  void loadItems();
}

function clearFieldError(name) {
  form.elements.namedItem(name).removeAttribute('aria-invalid');
  element(`${name}-error`).hidden = true;
  element(`${name}-error`).textContent = '';
}

function setFieldError(name, message) {
  if (!message) {
    clearFieldError(name);
    return;
  }
  form.elements.namedItem(name).setAttribute('aria-invalid', 'true');
  element(`${name}-error`).textContent = message;
  element(`${name}-error`).hidden = false;
}

function clearFormError() {
  element('form-error').hidden = true;
  element('form-error').textContent = '';
  formErrorKind = null;
}

function showFormError(message, kind = 'request') {
  element('form-error').textContent = message;
  element('form-error').hidden = false;
  formErrorKind = kind;
}

function clearFormErrors() {
  clearFormError();
  for (const name of fieldNames) clearFieldError(name);
}

function readFormValues() {
  return Object.fromEntries(fieldNames.map(name => [name, form.elements.namedItem(name).value]));
}

function openForm(event, item = null) {
  if (saving || reviewingItemCreation || dialog.open) return;
  formOpener = event.currentTarget;
  editingItem = item ? { ...item } : null;
  const fields = editingItem ?? newItemDraft;
  for (const name of fieldNames) form.elements.namedItem(name).value = fields[name];
  // Browsers strip newlines in single-line inputs and normalize textarea line
  // endings. Compare against what was displayed, so untouched API text remains
  // exactly as stored even when a different field is edited.
  initialFormValues = readFormValues();
  element('item-form-title').textContent = editingItem ? 'Modifica oggetto' : 'Nuovo oggetto';
  element('item-form-description').textContent = editingItem
    ? 'Aggiorna le informazioni e salva le modifiche. Con Annulla lasci l’oggetto invariato.'
    : 'Basta un nome per iniziare. Puoi aggiungere gli altri dettagli ora.';
  clearFormErrors();
  renderItemCreationRecovery();
  updateItemFormControls();
  element('feedback').textContent = '';
  dialog.showModal();
  dialog.scrollTop = 0;
  const focusTarget = !editingItem && itemCreationRecovery
    ? element('review-item-creation') : form.elements.namedItem('name');
  focusTarget.focus();
  focusTarget.scrollIntoView({ block: 'nearest' });
}

function closeForm() {
  if (saving || reviewingItemCreation || !dialog.open) return;
  dialog.close();
}

function restoreFocus(opener) {
  if (currentView !== 'inventory' || anyDialogOpen()) return;
  // A concurrent list load can replace the original button while a dialog is
  // open. Restore the corresponding action when it still exists and is visible.
  const isVisible = target => target.isConnected && !target.disabled && target.getClientRects().length;
  const replacement = [...element('item-list').querySelectorAll('button')].find(button =>
    button.dataset.itemId === opener.dataset.itemId &&
    button.dataset.itemAction === opener.dataset.itemAction && isVisible(button));
  const target = isVisible(opener) ? opener : replacement ?? inventoryTitle;
  target.focus();
}

function openDelete(event, item) {
  deleteOpener = event.currentTarget;
  deletionItem = { ...item };
  element('delete-item-name').textContent = item.name;
  element('delete-error').textContent = '';
  element('delete-error').hidden = true;
  element('feedback').textContent = '';
  deleteDialog.showModal();
  deleteDialog.scrollTop = 0;
  // Enter on the initially focused control cancels; deletion requires choosing
  // the separate confirmation button.
  element('cancel-delete').focus();
  element('cancel-delete').scrollIntoView({ block: 'nearest' });
}

function closeDelete() {
  if (deleting || !deleteDialog.open) return;
  deleteDialog.close();
}

function setDeleting(value) {
  deleting = value;
  element('cancel-delete').disabled = value;
  element('close-delete').disabled = value;
  element('confirm-delete').disabled = value;
  element('confirm-delete').textContent = value ? 'Eliminazione…' : 'Conferma eliminazione';
  deleteForm.setAttribute('aria-busy', String(value));
  element('delete-status').textContent = value ? 'Eliminazione in corso. Attendi la conferma.' : '';
  if (value) element('delete-status').focus();
}

function announceMutation(message) {
  element('feedback').textContent = message + (searchInput.value
    ? ' La ricerca è ancora attiva. Cancella la ricerca per vedere tutti gli oggetti.'
    : '');
  // A successful write invalidates cached search results. If the following GET
  // fails, do not show an old name or a deleted object as current data.
  loadedQuery = null;
  needsMutationRefresh = true;
  // Object names and locations also appear in due dates, history and choices.
  // Reject any older read now; returning to maintenance reads the full archive.
  invalidateMaintenanceLoad();
  invalidateTaskItemsLoad();
  void loadItems();
}

function fieldErrorMessage(name, value) {
  if (name === 'name' && value.trim().length === 0) return 'Inserisci il nome dell’oggetto.';
  // Match the API's Unicode code-point limits. Native maxlength counts UTF-16
  // units and would reject valid supplementary characters such as emoji.
  const length = [...value].length;
  return length > limits[name] ? `Usa al massimo ${limits[name]} caratteri (inseriti: ${length}).` : '';
}

function validateForm(values) {
  let firstInvalid;
  for (const name of fieldNames) {
    const input = form.elements.namedItem(name);
    const message = fieldErrorMessage(name, values[name]);
    setFieldError(name, message);
    if (message) {
      firstInvalid ??= input;
    }
  }
  if (firstInvalid) {
    showFormError('Controlla i campi segnalati prima di salvare. I valori sono stati conservati.', 'validation');
  }
  firstInvalid?.focus();
  return !firstInvalid;
}

function rejectedField(error) {
  // The existing API returns textual errors. Recognize only its known field
  // validation messages; storage, network and conflict errors are form-wide.
  if (!(error instanceof ApiError) || error.status !== 400) return undefined;
  if (['Il nome oggetto è obbligatorio.', 'Il nome oggetto non può essere vuoto.'].includes(error.message)) return 'name';
  return fieldNames.find(name => [
    `Il campo ${name} deve essere una stringa.`,
    `Il campo ${name} può contenere al massimo ${limits[name]} caratteri.`,
  ].includes(error.message));
}

function updateItemFormControls() {
  const busy = saving || reviewingItemCreation;
  element('item-fields').disabled = busy;
  element('cancel-form').disabled = busy;
  element('close-form').disabled = busy;
  element('review-item-creation').disabled = busy;
  saveButton.disabled = busy || (!editingItem && itemCreationRecovery?.archive === null);
  form.setAttribute('aria-busy', String(busy));
}

function setSaving(value) {
  saving = value;
  updateItemFormControls();
  saveButton.textContent = value ? 'Salvataggio…' : 'Salva oggetto';
  element('form-status').textContent = value ? 'Salvataggio in corso. Attendi la conferma.' : '';
  if (value) element('form-status').focus();
}

function renderItemCreationRecovery() {
  const recovery = !editingItem && itemCreationRecovery;
  element('item-creation-recovery').hidden = !recovery;
  const archive = recovery?.archive;
  element('item-recovery-results').hidden = !archive;
  element('item-recovery-list').replaceChildren(...(archive ?? []).map(item => {
    const entry = node('li');
    entry.append(node('strong', '', item.name));
    entry.append(node('p', '', `Categoria: ${item.category || 'Non indicata'}\nPosizione: ${item.location || 'Non indicata'}\nNote: ${item.notes || 'Nessuna'}`));
    return entry;
  }));
  element('item-recovery-status').textContent = reviewingItemCreation
    ? 'Lettura dell’inventario completo in corso. Il salvataggio non viene ripetuto.'
    : archive
    ? `Lettura completata: ${archive.length} ${archive.length === 1 ? 'oggetto' : 'oggetti'} in inventario. Controlla l’elenco qui sotto. Se l’oggetto è già presente, usa Annulla. Altrimenti puoi premere Salva oggetto per un nuovo tentativo esplicito.`
    : '';
  element('item-recovery-error').textContent = recovery?.error ?? '';
  element('item-recovery-error').hidden = !recovery?.error;
  element('item-creation-recovery').setAttribute('aria-busy', String(reviewingItemCreation));
}

async function reviewItemCreation() {
  if (saving || reviewingItemCreation || editingItem || !dialog.open || !itemCreationRecovery) return;
  const recovery = itemCreationRecovery;
  recovery.archive = null;
  recovery.error = '';
  reviewingItemCreation = true;
  renderItemCreationRecovery();
  updateItemFormControls();
  element('item-recovery-status').focus();
  try {
    const archive = await requestJSON('/api/items', { signal: AbortSignal.timeout(10000) });
    if (!Array.isArray(archive) || !archive.every(isItem)) throw new ApiError('Il servizio ha restituito un elenco di oggetti non valido.');
    recovery.archive = archive;
    clearFormError();
    // Refresh the ordinary list with its existing search, never substituting
    // the unfiltered recovery snapshot for the user's search results.
    loadedQuery = null;
    invalidateMaintenanceLoad();
    invalidateTaskItemsLoad();
    void loadItems();
  } catch (error) {
    recovery.error = (error instanceof ApiError ? error.message : 'Controlla che Custode sia in esecuzione e riprova la lettura.') +
      ' Verifica non riuscita: la bozza è conservata e Salva oggetto resta disabilitato. La verifica non ripete il salvataggio.';
  } finally {
    reviewingItemCreation = false;
    renderItemCreationRecovery();
    updateItemFormControls();
    (recovery.archive ? element('item-recovery-status') : element('item-recovery-error')).focus();
  }
}

newItemButton.addEventListener('click', openForm);
document.querySelector('.skip-link').addEventListener('click', event => {
  event.preventDefault();
  element('main-content').focus();
});
element('first-item').addEventListener('click', openForm);
element('inventory-tab').addEventListener('click', () => showView('inventory'));
element('retry-items').addEventListener('click', loadItems);
element('refresh-items').addEventListener('click', loadItems);
searchInput.addEventListener('input', searchChanged);
searchInput.addEventListener('compositionend', searchChanged);
element('search-form').addEventListener('submit', event => {
  event.preventDefault();
  void loadItems();
});
element('clear-search').addEventListener('click', clearSearch);
element('show-all-items').addEventListener('click', clearSearch);
element('cancel-form').addEventListener('click', closeForm);
element('close-form').addEventListener('click', closeForm);
element('review-item-creation').addEventListener('click', reviewItemCreation);
dialog.addEventListener('cancel', event => {
  if (saving || reviewingItemCreation) event.preventDefault();
});
dialog.addEventListener('close', () => {
  restoreFocus(formOpener);
});
element('cancel-delete').addEventListener('click', closeDelete);
element('close-delete').addEventListener('click', closeDelete);
deleteDialog.addEventListener('cancel', event => {
  if (deleting) event.preventDefault();
});
deleteDialog.addEventListener('close', () => restoreFocus(deleteOpener));
for (const name of fieldNames) {
  form.elements.namedItem(name).addEventListener('input', event => {
    const input = event.currentTarget;
    if (input.getAttribute('aria-invalid') === 'true') {
      setFieldError(name, fieldErrorMessage(name, input.value));
    }
    if (formErrorKind === 'validation' && fieldNames.every(field =>
      form.elements.namedItem(field).getAttribute('aria-invalid') !== 'true')) clearFormError();
    if (!editingItem) newItemDraft[name] = event.currentTarget.value;
  });
}

form.addEventListener('submit', async event => {
  event.preventDefault();
  if (saving || reviewingItemCreation || !dialog.open || (!editingItem && itemCreationRecovery?.archive === null)) return;
  clearFormErrors();
  const original = editingItem;
  const values = readFormValues();
  if (!original) Object.assign(newItemDraft, values);
  if (!validateForm(values)) return;
  // PATCH only edited fields, preserving unrelated changes from other windows.
  const fields = Object.fromEntries(Object.entries(values)
    .filter(([name, value]) => !original || value !== initialFormValues[name]));
  if (original && Object.keys(fields).length === 0) {
    dialog.close();
    element('feedback').textContent = 'Nessuna modifica da salvare.';
    return;
  }
  if (!original) itemCreationRecovery = null;
  renderItemCreationRecovery();
  setSaving(true);
  let savedItem;
  let invalidField;
  try {
    const item = await requestJSON(original ? `/api/items/${encodeURIComponent(original.id)}` : '/api/items', {
      method: original ? 'PATCH' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(fields),
      signal: AbortSignal.timeout(10000),
    });
    if (!isItem(item) || (original && item.id !== original.id)) {
      throw new ApiError('Il servizio ha restituito una risposta inattesa. Verifica l’elenco prima di riprovare.');
    }
    savedItem = item;
  } catch (error) {
    invalidField = rejectedField(error);
    if (invalidField) setFieldError(invalidField, error.message);
    if (!original && !invalidField) {
      itemCreationRecovery = { archive: null, error: '' };
      renderItemCreationRecovery();
      showFormError('Salvataggio non confermato: l’oggetto potrebbe essere già stato creato. I campi sono stati conservati. Usa Rileggi inventario completo per controllare tutti gli oggetti prima di un nuovo tentativo; la verifica non ripete il salvataggio.');
    } else showFormError(error.status === 404 && original
      ? 'L’oggetto non è più disponibile sul server. I campi sono stati conservati. Annulla e usa Aggiorna elenco per verificarne lo stato.'
      : error.status === 409
      ? `Modifica non consentita: ${error.message} I campi sono stati conservati. Annulla e aggiorna l’elenco prima di riprovare.`
      : error instanceof ApiError
      ? `${error.message} I campi sono stati conservati.`
      : 'Salvataggio non confermato: il servizio non risponde. I campi sono stati conservati. Annulla e usa Aggiorna elenco prima di riprovare.', invalidField ? 'validation' : 'request');
  } finally {
    setSaving(false);
  }
  if (!savedItem) {
    (invalidField ? form.elements.namedItem(invalidField) : element('form-error')).focus();
    return;
  }
  // Only a confirmed write clears the draft. The following list read handles
  // its own failures and must never turn this success into a save error.
  if (!original) for (const name of fieldNames) newItemDraft[name] = '';
  form.reset();
  // The list refresh replaces the originating card; use a stable, visible
  // destination so a completed write cannot leave focus on the document body.
  formOpener = inventoryTitle;
  dialog.close();
  announceMutation(`Oggetto ${original ? 'aggiornato' : 'salvato'}: ${savedItem.name}.`);
});

deleteForm.addEventListener('submit', async event => {
  event.preventDefault();
  if (deleting || !deletionItem || !deleteDialog.open) return;
  const item = deletionItem;
  element('delete-error').hidden = true;
  setDeleting(true);
  try {
    const result = await requestJSON(`/api/items/${encodeURIComponent(item.id)}`, {
      method: 'DELETE',
      signal: AbortSignal.timeout(10000),
    });
    if (result !== undefined && result?.ok !== true) throw new ApiError('Risposta all’eliminazione inattesa.');
    deleteOpener = inventoryTitle;
    deleteDialog.close();
    announceMutation(`Oggetto eliminato: ${item.name}.`);
  } catch (error) {
    element('delete-error').textContent = error.status === 409
      ? `Eliminazione non consentita: ${error.message} L’oggetto resta nell’elenco.`
      : error.status === 404
      ? 'L’oggetto non è più disponibile sul server. Annulla e usa Aggiorna elenco per verificarne lo stato.'
      : error instanceof ApiError
      ? `Eliminazione non confermata: ${error.message} Annulla e aggiorna l’elenco prima di riprovare.`
      : 'Eliminazione non confermata: il servizio non risponde. Annulla e usa Aggiorna elenco prima di riprovare.';
    element('delete-error').hidden = false;
  } finally {
    setDeleting(false);
    if (!element('delete-error').hidden) element('delete-error').focus();
  }
});

function showView(view) {
  if (anyDialogOpen()) return;
  const changed = currentView !== view;
  currentView = view;
  for (const name of ['inventory', 'maintenance', 'backup']) {
    const selected = name === view;
    element(`${name}-view`).hidden = !selected;
    element(`${name}-tab`).classList.toggle('active', selected);
    if (selected) element(`${name}-tab`).setAttribute('aria-current', 'page');
    else element(`${name}-tab`).removeAttribute('aria-current');
  }
  document.title = view === 'maintenance' ? 'Custode · Manutenzioni'
    : view === 'backup' ? 'Custode · Backup' : 'Custode · Gli oggetti di casa';
  if (!changed) return;
  element(`${view}-page-title`).focus();
  invalidateListLoad();
  invalidateMaintenanceLoad();
  if (view === 'maintenance') void loadMaintenance();
  if (view === 'inventory') void loadItems();
}

function anyDialogOpen() {
  return [dialog, deleteDialog, taskDialog, completionDialog, deleteTaskDialog, restoreDialog].some(modal => modal.open);
}

function invalidateMaintenanceLoad() {
  maintenanceSequence += 1;
  maintenanceController?.abort();
  maintenanceController = undefined;
  return maintenanceSequence;
}

function invalidateTaskItemsLoad() {
  taskItemsSequence += 1;
  taskItemsController?.abort();
  taskItemsController = undefined;
  return taskItemsSequence;
}

function civilDateValid(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [year, month, day] = value.split('-').map(Number);
  const leap = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  return year >= 1 && month >= 1 && month <= 12 && day >= 1 &&
    day <= [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1];
}

function browserToday() {
  const now = new Date();
  return `${String(now.getFullYear()).padStart(4, '0')}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
}

function dateLabel(value) {
  return value.split('-').reverse().join('/');
}

function civilDayNumber(value) {
  const [year, month, day] = value.split('-').map(Number);
  const date = new Date(0);
  date.setUTCFullYear(year, month - 1, day);
  return date.getTime() / 86400000;
}

function isTask(task) {
  return task !== null && typeof task === 'object' &&
    ['id', 'itemId', 'title', 'notes'].every(key => typeof task[key] === 'string') &&
    task.id.length > 0 && civilDateValid(task.dueDate) &&
    Number.isInteger(task.intervalDays) && task.intervalDays >= 0 && task.intervalDays <= 3660 &&
    typeof task.completed === 'boolean' && typeof task.updatedAt === 'string';
}

function taskCard(task, index, archive, today) {
  const entry = node('li');
  const card = node('article', 'item-card task-card');
  card.dataset.taskId = task.id;
  const status = task.dueDate < today ? ['overdue', 'Scaduto']
    : task.dueDate === today ? ['today', 'Oggi']
    : civilDayNumber(task.dueDate) <= civilDayNumber(today) + 30 ? ['upcoming', 'Prossimo']
    : ['later', 'Oltre 30 giorni'];
  card.append(node('p', `due-badge due-${status[0]}`, status[1]));
  const heading = node('div', 'card-heading');
  const title = node('h4', '', task.title);
  title.id = `task-title-${index}`;
  card.setAttribute('aria-labelledby', title.id);
  heading.append(title);
  const details = node('dl', 'item-details');
  const item = archive.get(task.itemId);
  for (const [label, value] of [
    ['Oggetto', item ? item.name : 'Oggetto non disponibile · aggiorna le manutenzioni'],
    ['Scadenza', task.dueDate],
    ['Ricorrenza', task.intervalDays === 0 ? 'Una tantum' : `Ogni ${task.intervalDays} ${task.intervalDays === 1 ? 'giorno' : 'giorni'}`],
    ['Posizione', item?.location || 'Non indicata'],
  ]) {
    const detail = node('div');
    const text = node('dd', '', label === 'Scadenza' ? undefined : value);
    if (label === 'Scadenza') {
      const time = node('time', '', dateLabel(value));
      time.dateTime = value;
      text.append(time);
    }
    detail.append(node('dt', '', label), text);
    details.append(detail);
  }
  const notes = node('div', 'item-notes');
  notes.append(node('p', 'item-notes-label', 'Note intervento'),
    node('p', task.notes ? 'item-notes-text' : 'item-notes-text unspecified', task.notes || 'Non indicate'));
  card.append(heading, details, notes);
  card.append(taskActions(task));
  entry.append(card);
  return entry;
}

function taskActions(task) {
  const actions = node('div', 'card-actions');
  for (const [action, label, style, dialogId, open] of [
    ...(!task.completed ? [['complete', 'Completa', 'primary', 'completion-dialog', openCompletion]] : []),
    ['edit', 'Modifica', 'secondary', 'task-dialog', openTaskForm],
    ['delete', 'Elimina', 'delete', 'delete-task-dialog', openTaskDelete],
  ]) {
    const button = node('button', `button button-${style}`, label);
    button.type = 'button';
    button.setAttribute('aria-label', `${label} ${task.title}`);
    button.setAttribute('aria-haspopup', 'dialog');
    button.setAttribute('aria-controls', dialogId);
    button.dataset.taskId = task.id;
    button.dataset.taskAction = action;
    button.dataset.taskSection = task.completed ? 'history' : 'tasks';
    button.addEventListener('click', event => open(event, task));
    actions.append(button);
  }
  return actions;
}

function isHistoryEntry(entry) {
  return entry !== null && typeof entry === 'object' &&
    ['id', 'taskId', 'itemId', 'title'].every(key => typeof entry[key] === 'string') &&
    entry.id.length > 0 && entry.taskId.length > 0 && entry.itemId.length > 0 && civilDateValid(entry.completedOn);
}

function historyCard(event, index, archive, tasks, showActions = false) {
  const entry = node('li');
  const card = node('article', 'item-card history-card');
  const heading = node('h4', '', event.title);
  heading.id = `history-event-title-${index}`;
  card.setAttribute('aria-labelledby', heading.id);
  const task = tasks.get(event.taskId);
  const state = !task ? 'Intervento rimosso · registrazione conservata'
    : task.completed ? (task.intervalDays === 0 ? 'Una tantum · concluso' : 'Intervento concluso')
    : task.intervalDays > 0 ? 'Ricorrente · ancora attivo' : 'Una tantum · ancora attivo';
  const title = node('div', 'card-heading');
  title.append(heading);
  card.append(node('p', 'due-badge', state), title);
  const details = node('dl', 'item-details');
  const item = archive.get(event.itemId);
  const fields = [
    ['Completato il', event.completedOn, true],
    ['Oggetto', item?.name || 'Oggetto non disponibile', false],
  ];
  if (task && task.title !== event.title) fields.push(['Titolo attuale', task.title, false]);
  if (task && !task.completed) fields.push(['Scadenza attuale', task.dueDate, true]);
  for (const [label, value, isDate] of fields) {
    const detail = node('div');
    const text = node('dd', '', isDate ? undefined : value);
    if (isDate) {
      const time = node('time', '', dateLabel(value));
      time.dateTime = value;
      text.append(time);
    }
    detail.append(node('dt', '', label), text);
    details.append(detail);
  }
  card.append(details);
  // A completed task stays editable on its newest historical event, even if
  // it had recurring completions before becoming one-off. Events never change.
  if (showActions && task?.completed) card.append(taskActions(task));
  entry.append(card);
  return entry;
}

function restoreMaintenanceFocus(opener, fallback = opener.dataset.taskSection === 'history' ? historyTitle : taskTitle) {
  const visible = target => target.isConnected && !target.disabled && target.getClientRects().length;
  if (currentView !== 'maintenance' || anyDialogOpen()) return;
  const replacement = [...element('task-list').querySelectorAll('button'), ...element('history-list').querySelectorAll('button')].find(button =>
    button.dataset.taskId === opener.dataset.taskId &&
    button.dataset.taskAction === opener.dataset.taskAction && visible(button));
  (visible(opener) ? opener : replacement ?? fallback).focus();
}

async function loadMaintenance() {
  const active = document.activeElement;
  const focusHeading = element('history-results').contains(active) || active === element('retry-history') ? historyTitle : taskTitle;
  const focusReturn = currentView === 'maintenance' && !taskDialog.open && !completionDialog.open && !deleteTaskDialog.open && (
    element('maintenance-results').contains(active) || element('history-results').contains(active) ||
    [element('refresh-tasks'), element('retry-tasks'), element('retry-history')].includes(active)
  ) ? active : null;
  if (focusReturn) focusHeading.focus();
  const sequence = invalidateMaintenanceLoad();
  const controller = new AbortController();
  maintenanceController = controller;
  const timeout = setTimeout(() => controller.abort(), 10000);
  const today = browserToday();
  element('overview-date').textContent = `Scadenze rispetto a oggi, ${dateLabel(today)}. Prossimi: da domani fino al trentesimo giorno incluso.`;
  for (const id of ['count-overdue', 'count-today', 'count-upcoming']) element(id).textContent = '–';
  for (const id of ['tasks-no-items', 'tasks-empty', 'task-list', 'tasks-error']) element(id).hidden = true;
  element('tasks-loading').hidden = false;
  element('maintenance-results').setAttribute('aria-busy', 'true');
  element('tasks-summary').textContent = 'Caricamento…';
  element('refresh-tasks').disabled = true;
  element('retry-tasks').disabled = true;
  for (const id of ['history-empty', 'history-list', 'history-error']) element(id).hidden = true;
  element('history-loading').hidden = false;
  element('history-results').setAttribute('aria-busy', 'true');
  element('history-summary').textContent = 'Caricamento…';
  element('retry-history').disabled = true;
  try {
    // A failed history read must not hide valid due dates. All reads belong to
    // this generation, never to an inventory search filter.
    const [overviewRead, archiveRead, tasksRead, historyRead] = await Promise.allSettled([
      requestJSON(`/api/overview?today=${today}`, { signal: controller.signal }),
      requestJSON('/api/items', { signal: controller.signal }),
      requestJSON('/api/tasks', { signal: controller.signal }),
      requestJSON('/api/history', { signal: controller.signal }),
    ]);
    if (sequence !== maintenanceSequence) return;
    const read = (result, validate, message) => {
      if (result.status === 'rejected') throw result.reason;
      if (!validate(result.value)) throw new ApiError(message);
      return result.value;
    };
    const readArchive = () => read(archiveRead, value => Array.isArray(value) && value.every(isItem), 'Il servizio ha restituito un inventario non valido.');
    const readError = error => (taskMutationConfirmed ? `${taskMutationConfirmed} ` : '') +
      (error instanceof ApiError ? error.message : 'Controlla che Custode sia in esecuzione.');
    let overviewReady = false;
    let historyReady = false;
    try {
      const overview = read(overviewRead, value => value &&
        ['overdue', 'today', 'upcoming'].every(key => Number.isInteger(value[key]) && value[key] >= 0) &&
        Array.isArray(value.tasks) && value.tasks.every(task => isTask(task) && !task.completed),
      'Il servizio ha restituito una panoramica non valida.');
      const archive = readArchive();
      for (const name of ['overdue', 'today', 'upcoming']) element(`count-${name}`).textContent = String(overview[name]);
      const tasks = [...overview.tasks].sort((a, b) => a.dueDate.localeCompare(b.dueDate));
      const itemMap = new Map(archive.map(item => [item.id, item]));
      element('task-list').replaceChildren(...tasks.map((task, index) => taskCard(task, index, itemMap, today)));
      element('task-list').hidden = tasks.length === 0;
      element('tasks-no-items').hidden = archive.length > 0 || tasks.length > 0;
      element('tasks-empty').hidden = archive.length === 0 || tasks.length > 0;
      element('tasks-summary').textContent = `${tasks.length} ${tasks.length === 1 ? 'intervento attivo' : 'interventi attivi'} · per scadenza`;
      element('tasks-summary').append(node('span', 'visually-hidden',
        `. Scaduti: ${overview.overdue}. Oggi: ${overview.today}. Prossimi 30 giorni: ${overview.upcoming}.`));
      overviewReady = true;
    } catch (error) {
      element('tasks-error-message').textContent = readError(error) + ' Non è stato possibile aggiornare le scadenze. Usa Riprova per rileggere i dati.';
      element('tasks-error').hidden = false;
      element('tasks-summary').textContent = 'Scadenze non disponibili';
    }
    try {
      const history = read(historyRead, value => Array.isArray(value) && value.every(isHistoryEntry), 'Il servizio ha restituito uno storico non valido.');
      const tasks = read(tasksRead, value => Array.isArray(value) && value.every(isTask), 'Il servizio ha restituito interventi non validi.');
      const archive = readArchive();
      const events = [...history].sort((a, b) => b.completedOn.localeCompare(a.completedOn));
      const itemMap = new Map(archive.map(item => [item.id, item]));
      const taskMap = new Map(tasks.map(task => [task.id, task]));
      const actionsShown = new Set();
      element('history-list').replaceChildren(...events.map((entry, index) => {
        const showActions = taskMap.get(entry.taskId)?.completed && !actionsShown.has(entry.taskId);
        if (showActions) actionsShown.add(entry.taskId);
        return historyCard(entry, index, itemMap, taskMap, showActions);
      }));
      element('history-list').hidden = events.length === 0;
      element('history-empty').hidden = events.length > 0;
      element('history-summary').textContent = `${events.length} ${events.length === 1 ? 'completamento' : 'completamenti'}`;
      historyReady = true;
    } catch (error) {
      element('history-error-message').textContent = readError(error) + ' Non è stato possibile aggiornare lo storico. Usa Riprova storico per rileggere i dati.';
      element('history-error').hidden = false;
      element('history-summary').textContent = 'Storico non disponibile';
    }
    if (overviewReady && historyReady) {
      taskMutationConfirmed = '';
      completionIssues.clear();
    }
  } finally {
    clearTimeout(timeout);
    controller.abort();
    if (sequence === maintenanceSequence) {
      element('tasks-loading').hidden = true;
      element('maintenance-results').setAttribute('aria-busy', 'false');
      element('history-loading').hidden = true;
      element('history-results').setAttribute('aria-busy', 'false');
      element('refresh-tasks').disabled = false;
      element('retry-tasks').disabled = false;
      element('retry-history').disabled = false;
      if (focusReturn && document.activeElement === focusHeading && currentView === 'maintenance' && !taskDialog.open && !completionDialog.open && !deleteTaskDialog.open) {
        restoreMaintenanceFocus(focusReturn, focusHeading);
      }
    }
  }
}

function setTaskFieldError(name, message = '') {
  const input = taskForm.elements.namedItem(name);
  if (message) input.setAttribute('aria-invalid', 'true');
  else input.removeAttribute('aria-invalid');
  element(`task-${name}-error`).textContent = message;
  element(`task-${name}-error`).hidden = !message;
}

function showTaskFormError(message = '', kind = 'request') {
  element('task-form-error').textContent = message;
  element('task-form-error').hidden = !message;
  taskFormErrorKind = message ? kind : undefined;
}

function taskFieldError(name, value) {
  if (name === 'title' && !value.trim()) return 'Inserisci il titolo dell’intervento.';
  if (name === 'title' || name === 'notes') {
    const limit = name === 'title' ? 200 : 5000;
    if ([...value].length > limit) return `Usa al massimo ${limit} caratteri (inseriti: ${[...value].length}).`;
  }
  if (name === 'itemId' && !taskItems.some(item => item.id === value)) return 'Scegli un oggetto disponibile nell’inventario.';
  if (name === 'dueDate' && !civilDateValid(value)) return 'Inserisci una data valida, con anno da 0001 a 9999.';
  if (name === 'intervalDays' && (!value.trim() || !Number.isInteger(Number(value)) || Number(value) < 0 || Number(value) > 3660)) {
    return 'Inserisci un intero tra 0 e 3660. Usa 0 per un intervento una tantum.';
  }
  return '';
}

function updateTaskSaveButton() {
  element('save-task').disabled = taskSaving || reviewingTaskCreation || taskEditBlocked ||
    (!editingTask && taskCreationRecovery?.tasks === null) || !taskItemsReady || taskItems.length === 0;
}

function updateTaskFormControls() {
  const busy = taskSaving || reviewingTaskCreation;
  element('task-fields').disabled = busy;
  for (const id of ['cancel-task-form', 'close-task-form', 'review-task-edit', 'review-task-creation']) {
    element(id).disabled = busy;
  }
  taskForm.setAttribute('aria-busy', String(busy));
  updateTaskSaveButton();
}

function renderTaskCreationRecovery() {
  const recovery = !editingTask && taskCreationRecovery;
  element('task-creation-recovery').hidden = !recovery;
  const tasks = recovery?.tasks;
  const itemMap = new Map((recovery?.items ?? []).map(item => [item.id, item]));
  element('task-recovery-results').hidden = !tasks;
  element('task-recovery-list').replaceChildren(...(tasks ?? []).map(task => {
    const entry = node('li');
    const item = itemMap.get(task.itemId);
    entry.append(node('strong', '', task.title));
    entry.append(node('p', '', `Oggetto: ${item?.name ?? 'Non disponibile'}\nCategoria: ${item?.category || 'Non indicata'}\nPosizione: ${item?.location || 'Non indicata'}\nScadenza: ${dateLabel(task.dueDate)}\nRicorrenza: ${task.intervalDays === 0 ? 'Una tantum' : `Ogni ${task.intervalDays} giorni`}\nStato: ${task.completed ? 'Concluso' : 'Attivo'}\nNote: ${task.notes || 'Nessuna'}`));
    return entry;
  }));
  element('task-recovery-status').textContent = reviewingTaskCreation
    ? 'Lettura degli interventi e dell’inventario in corso. Il salvataggio non viene ripetuto.'
    : tasks
    ? `Lettura completata: ${tasks.length} ${tasks.length === 1 ? 'intervento' : 'interventi'}, inclusi i conclusi. Controlla l’elenco qui sotto. Se l’intervento è già presente, usa Annulla. Altrimenti puoi premere Salva intervento per un nuovo tentativo esplicito.`
    : '';
  element('task-recovery-error').textContent = recovery?.error ?? '';
  element('task-recovery-error').hidden = !recovery?.error;
  element('task-creation-recovery').setAttribute('aria-busy', String(reviewingTaskCreation));
}

async function reviewTaskCreation() {
  if (taskSaving || reviewingTaskCreation || editingTask || !taskDialog.open || !taskCreationRecovery) return;
  const recovery = taskCreationRecovery;
  recovery.tasks = null;
  recovery.items = [];
  recovery.error = '';
  reviewingTaskCreation = true;
  renderTaskCreationRecovery();
  updateTaskFormControls();
  element('task-recovery-status').focus();
  try {
    const signal = AbortSignal.timeout(10000);
    // Read the complete task list, including concluded interventions that the
    // overview omits. No write or draft replacement occurs during recovery.
    const [tasks, archive] = await Promise.all([
      requestJSON('/api/tasks', { signal }),
      requestJSON('/api/items', { signal }),
    ]);
    if (!Array.isArray(tasks) || !tasks.every(isTask)) throw new ApiError('Il servizio ha restituito un elenco di interventi non valido.');
    if (!Array.isArray(archive) || !archive.every(isItem)) throw new ApiError('Il servizio ha restituito un elenco di oggetti non valido.');
    recovery.tasks = tasks;
    recovery.items = archive;
    showTaskFormError();
    void loadMaintenance();
  } catch (error) {
    recovery.error = (error instanceof ApiError ? error.message : 'Controlla che Custode sia in esecuzione e riprova la lettura.') +
      ' Verifica non riuscita: la bozza è conservata e Salva intervento resta disabilitato. La verifica non ripete il salvataggio.';
  } finally {
    reviewingTaskCreation = false;
    renderTaskCreationRecovery();
    updateTaskFormControls();
    (recovery.tasks ? element('task-recovery-status') : element('task-recovery-error')).focus();
  }
}

function showSelectedTaskItem() {
  const item = taskItems.find(item => item.id === taskSelectedItemId);
  const detail = element('task-item-detail');
  // The closed native select truncates long options. Keep the full selection
  // readable on touch screens and at zoom, with the same field association.
  detail.textContent = item
    ? `Oggetto selezionato: ${item.name}\nCategoria: ${item.category || 'Non indicata'}\nPosizione: ${item.location || 'Non indicata'}` : '';
  detail.hidden = !item;
}

async function loadTaskItems() {
  const sequence = invalidateTaskItemsLoad();
  const controller = new AbortController();
  taskItemsController = controller;
  const timeout = setTimeout(() => controller.abort(), 10000);
  const active = document.activeElement;
  const restoreRetry = active === element('retry-task-items');
  const status = element('task-items-status');
  status.textContent = 'Caricamento dell’inventario completo…';
  if (restoreRetry) status.focus();
  taskItemsReady = false;
  taskItems = [];
  showSelectedTaskItem();
  const select = element('task-item');
  select.disabled = true;
  select.setAttribute('aria-busy', 'true');
  element('retry-task-items').disabled = true;
  const placeholder = node('option', '', 'Caricamento degli oggetti…');
  placeholder.value = '';
  select.replaceChildren(placeholder);
  element('task-items-error').hidden = true;
  element('task-items-empty').hidden = true;
  updateTaskSaveButton();
  try {
    const archive = await requestJSON('/api/items', { signal: controller.signal });
    if (sequence !== taskItemsSequence || !taskDialog.open) return;
    if (!Array.isArray(archive) || !archive.every(isItem)) throw new ApiError('Il servizio ha restituito un elenco di oggetti non valido.');
    taskItems = archive;
    taskItemsReady = true;
    const prompt = node('option', '', archive.length ? 'Scegli un oggetto' : 'Nessun oggetto in inventario');
    prompt.value = '';
    const options = [...archive].sort((a, b) => a.name.localeCompare(b.name, 'it')).map(item => {
      const option = node('option', '', [item.name, item.category, item.location].filter(Boolean).join(' · '));
      option.value = item.id;
      option.title = option.textContent;
      return option;
    });
    select.replaceChildren(prompt, ...options);
    if (taskSelectedItemId && !archive.some(item => item.id === taskSelectedItemId)) {
      const missing = node('option', '', 'Oggetto non più disponibile: scegli un altro oggetto');
      missing.value = taskSelectedItemId;
      missing.disabled = true;
      select.append(missing);
      setTaskFieldError('itemId', 'L’oggetto scelto non è più disponibile. Scegli un altro oggetto.');
    } else if (taskSelectedItemId) setTaskFieldError('itemId');
    select.value = taskSelectedItemId;
    select.disabled = archive.length === 0;
    showSelectedTaskItem();
    element('task-items-empty').hidden = archive.length > 0;
    element('task-items-status').textContent = `${archive.length} ${archive.length === 1 ? 'oggetto disponibile' : 'oggetti disponibili'}.`;
  } catch (error) {
    if (sequence !== taskItemsSequence || !taskDialog.open) return;
    placeholder.textContent = 'Oggetti non disponibili';
    element('task-items-status').textContent = '';
    element('task-items-error-message').textContent = (error instanceof ApiError ? error.message : 'Controlla che Custode sia in esecuzione.') + ' La bozza è conservata: riprova il caricamento.';
    element('task-items-error').hidden = false;
  } finally {
    clearTimeout(timeout);
    if (sequence === taskItemsSequence && taskDialog.open) {
      select.setAttribute('aria-busy', 'false');
      element('retry-task-items').disabled = false;
      updateTaskSaveButton();
      if (restoreRetry && !taskSaving && document.activeElement === status) {
        (taskItemsReady && taskItems.length ? select : taskItemsReady
          ? element('task-form-first-item') : element('retry-task-items')).focus();
      }
    }
  }
}

function openTaskForm(event, task = null) {
  if (taskSaving || reviewingTaskCreation || taskDialog.open) return;
  taskOpener = event.currentTarget;
  editingTask = task ? { ...task } : null;
  taskEditBlocked = false;
  const values = editingTask ?? taskDraft;
  taskSelectedItemId = values.itemId;
  for (const name of taskFieldNames) {
    if (name !== 'itemId') taskForm.elements.namedItem(name).value = values[name];
    setTaskFieldError(name);
  }
  // Compare with displayed values: inputs normalize line endings and strip
  // line breaks. Untouched text from the API must survive a partial update.
  initialTaskFormValues = Object.fromEntries(taskFieldNames.map(name =>
    [name, name === 'itemId' ? values.itemId : taskForm.elements.namedItem(name).value]));
  element('task-form-title').textContent = editingTask ? 'Modifica intervento' : 'Nuovo intervento';
  element('task-form-description').textContent = editingTask
    ? 'Aggiorna le informazioni dell’intervento. Titolo, oggetto e date dei completamenti già registrati nello Storico resteranno invariati. ' +
      (editingTask.completed ? 'L’intervento è concluso: modificarlo non lo riapre.' : 'La ricorrenza modificata si applicherà ai prossimi completamenti.') +
      ' Con Annulla scarti le modifiche al modulo.'
    : 'Scegli un oggetto e una scadenza. Per un intervento una tantum lascia la ricorrenza a 0.';
  element('review-task-edit').hidden = true;
  element('task-feedback').textContent = '';
  showTaskFormError();
  renderTaskCreationRecovery();
  updateTaskFormControls();
  taskDialog.showModal();
  taskDialog.scrollTop = 0;
  const focusTarget = !editingTask && taskCreationRecovery
    ? element('review-task-creation') : element('task-title');
  focusTarget.focus();
  focusTarget.scrollIntoView({ block: 'nearest' });
  void loadTaskItems();
}

function closeTaskForm() {
  if (!taskSaving && !reviewingTaskCreation && taskDialog.open) taskDialog.close();
}

function addTaskItem() {
  if (taskSaving || reviewingTaskCreation) return;
  closeTaskForm();
  showView('inventory');
  openForm({ currentTarget: newItemButton });
}

function setTaskSaving(value) {
  taskSaving = value;
  updateTaskFormControls();
  element('save-task').textContent = value ? 'Salvataggio…' : 'Salva intervento';
  element('task-form-status').textContent = value ? 'Salvataggio in corso. Attendi la conferma.' : '';
  if (value) element('task-form-status').focus();
}

function openTaskDelete(event, task) {
  if (taskDeleting || deleteTaskDialog.open) return;
  taskDeleteOpener = event.currentTarget;
  deletionTask = { ...task };
  taskDeleteBlocked = false;
  element('delete-task-name').textContent = task.title;
  element('delete-task-error').hidden = true;
  element('delete-task-error').textContent = '';
  element('review-task-delete').hidden = true;
  element('task-feedback').textContent = '';
  setTaskDeleting(false);
  deleteTaskDialog.showModal();
  deleteTaskDialog.scrollTop = 0;
  element('cancel-delete-task').focus();
  element('cancel-delete-task').scrollIntoView({ block: 'nearest' });
}

function closeTaskDelete() {
  if (!taskDeleting && deleteTaskDialog.open) deleteTaskDialog.close();
}

function setTaskDeleting(value) {
  taskDeleting = value;
  for (const id of ['cancel-delete-task', 'close-delete-task', 'review-task-delete']) element(id).disabled = value;
  element('confirm-delete-task').disabled = value || taskDeleteBlocked;
  element('confirm-delete-task').textContent = value ? 'Eliminazione…' : 'Conferma eliminazione';
  deleteTaskForm.setAttribute('aria-busy', String(value));
  element('delete-task-status').textContent = value ? 'Eliminazione in corso. Attendi la conferma.' : '';
  if (value) element('delete-task-status').focus();
}

element('cancel-delete-task').addEventListener('click', closeTaskDelete);
element('close-delete-task').addEventListener('click', closeTaskDelete);
deleteTaskDialog.addEventListener('cancel', event => {
  if (taskDeleting) event.preventDefault();
});
deleteTaskDialog.addEventListener('close', () => restoreMaintenanceFocus(taskDeleteOpener));
element('review-task-delete').addEventListener('click', () => {
  if (taskDeleting) return;
  taskDeleteOpener = historyTitle;
  closeTaskDelete();
  historyTitle.focus();
  void loadMaintenance();
});
deleteTaskForm.addEventListener('submit', async event => {
  event.preventDefault();
  if (taskDeleting || taskDeleteBlocked || !deleteTaskDialog.open || !deletionTask) return;
  const task = deletionTask;
  element('delete-task-error').hidden = true;
  setTaskDeleting(true);
  let confirmed = false;
  try {
    const result = await requestJSON(`/api/tasks/${encodeURIComponent(task.id)}`, {
      method: 'DELETE',
      headers: { 'If-Match': JSON.stringify(task.updatedAt) },
      signal: AbortSignal.timeout(10000),
    });
    if (result !== undefined && result?.ok !== true) throw new ApiError('Risposta all’eliminazione inattesa.');
    confirmed = true;
  } catch (error) {
    const message = error.status === 404
      ? 'L’intervento non è più disponibile sul server. Potrebbe essere stato rimosso da un’altra finestra.'
      : error.status === 409
      ? `Eliminazione non consentita: ${error.message}`
      : 'Eliminazione non confermata: la risposta non permette di sapere se l’intervento è stato rimosso.';
    element('delete-task-error').textContent = `${message} Usa Rileggi interventi e storico per verificarne lo stato e aggiornare l’elenco; la verifica non ripete l’eliminazione. I completamenti registrati restano nello Storico.`;
    element('delete-task-error').hidden = false;
    element('review-task-delete').hidden = false;
    taskDeleteBlocked = true;
  } finally {
    setTaskDeleting(false);
  }
  if (!confirmed) {
    element('delete-task-error').focus();
    return;
  }
  taskDeleteOpener = task.completed ? historyTitle : taskTitle;
  deleteTaskDialog.close();
  taskDeleteOpener.focus();
  element('task-feedback').textContent = `Intervento eliminato: ${task.title}. I completamenti già registrati restano consultabili nello Storico.`;
  taskMutationConfirmed = 'L’intervento è stato eliminato. Lo Storico è conservato. Non ripetere l’eliminazione.';
  void loadMaintenance();
});

function completionDateError(value) {
  if (!civilDateValid(value)) return 'Inserisci una data valida, con anno da 0001 a 9999.';
  if (completionTask?.intervalDays > 0 && civilDayNumber(value) + completionTask.intervalDays > civilDayNumber('9999-12-31')) {
    return 'La prossima scadenza supererebbe il 31/12/9999. Scegli una data precedente.';
  }
  return '';
}

function setCompletionDateError(message = '') {
  if (message) completionDate.setAttribute('aria-invalid', 'true');
  else completionDate.removeAttribute('aria-invalid');
  element('completion-date-error').textContent = message;
  element('completion-date-error').hidden = !message;
}

function showCompletionError(message = '') {
  element('completion-error').textContent = message;
  element('completion-error').hidden = !message;
}

function updateCompletionEffect() {
  if (!completionTask) return;
  if (completionTask.intervalDays === 0) {
    element('completion-effect').textContent = 'Una tantum: l’intervento sarà concluso e uscirà dalle scadenze attive. La registrazione resterà nello Storico.';
    return;
  }
  const days = completionTask.intervalDays;
  const next = !completionDateError(completionDate.value)
    ? new Date((civilDayNumber(completionDate.value) + days) * 86400000).toISOString().slice(0, 10) : null;
  element('completion-effect').textContent = `Ricorrente: resterà attivo. La prossima scadenza sarà ${days === 1 ? '1 giorno' : `${days} giorni`} dopo la data di completamento${next ? `: ${dateLabel(next)}` : ''}. Ogni completamento resterà nello Storico.`;
}

function openCompletion(event, task) {
  if (completionSaving || completionDialog.open) return;
  completionOpener = event.currentTarget;
  completionTask = { ...task };
  element('task-feedback').textContent = '';
  element('completion-task-name').textContent = task.title;
  completionDate.value = completionDrafts.has(task.id) ? completionDrafts.get(task.id) : browserToday();
  setCompletionDateError();
  const issue = completionIssues.get(task.id);
  showCompletionError(issue);
  element('review-completion').hidden = !issue;
  element('confirm-completion').disabled = Boolean(issue);
  updateCompletionEffect();
  completionDialog.showModal();
  completionDialog.scrollTop = 0;
  (issue ? element('completion-error') : completionDate).focus();
  (issue ? element('completion-error') : completionDate).scrollIntoView({ block: 'nearest' });
}

function closeCompletion() {
  if (completionSaving || !completionDialog.open) return;
  if (completionTask) completionDrafts.set(completionTask.id, completionDate.value);
  completionDialog.close();
}

function setCompletionSaving(value) {
  completionSaving = value;
  element('completion-fields').disabled = value;
  element('cancel-completion').disabled = value;
  element('close-completion').disabled = value;
  element('confirm-completion').disabled = value || completionIssues.has(completionTask?.id);
  element('confirm-completion').textContent = value ? 'Registrazione…' : 'Conferma completamento';
  completionForm.setAttribute('aria-busy', String(value));
  element('completion-status').textContent = value ? 'Registrazione del completamento in corso. Attendi la conferma.' : '';
  if (value) element('completion-status').focus();
}

element('close-completion').addEventListener('click', closeCompletion);
element('cancel-completion').addEventListener('click', closeCompletion);
completionDialog.addEventListener('cancel', event => {
  if (completionSaving) event.preventDefault();
  else if (completionTask) completionDrafts.set(completionTask.id, completionDate.value);
});
completionDialog.addEventListener('close', () => {
  if (completionDialog.open) return;
  completionTask = null;
  restoreMaintenanceFocus(completionOpener);
});
element('review-completion').addEventListener('click', () => {
  if (completionSaving) return;
  // This recovery action only reads. The user can inspect the event and the
  // updated due date before explicitly opening another completion dialog.
  completionOpener = historyTitle;
  closeCompletion();
  historyTitle.focus();
  void loadMaintenance();
});
completionDate.addEventListener('input', () => {
  if (!completionTask) return;
  completionDrafts.set(completionTask.id, completionDate.value);
  if (completionDate.getAttribute('aria-invalid') === 'true') {
    const error = completionDateError(completionDate.value);
    setCompletionDateError(error);
    if (!error && !completionIssues.has(completionTask.id)) showCompletionError();
  }
  updateCompletionEffect();
});
completionForm.addEventListener('submit', async event => {
  event.preventDefault();
  if (completionSaving || !completionDialog.open || !completionTask || completionIssues.has(completionTask.id)) return;
  const task = completionTask;
  const completedOn = completionDate.value;
  completionDrafts.set(task.id, completedOn);
  showCompletionError();
  const dateError = completionDateError(completedOn);
  setCompletionDateError(dateError);
  if (dateError) {
    showCompletionError('Controlla la data segnalata prima di confermare. Il valore è stato conservato.');
    completionDate.focus();
    return;
  }
  setCompletionSaving(true);
  let confirmed;
  let fieldError = false;
  try {
    const result = await requestJSON(`/api/tasks/${encodeURIComponent(task.id)}/complete`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'If-Match': JSON.stringify(task.updatedAt) },
      body: JSON.stringify({ completedOn }),
      signal: AbortSignal.timeout(10000),
    });
    if (!isTask(result) || result.id !== task.id) throw new ApiError('Risposta al completamento inattesa.');
    confirmed = result;
  } catch (error) {
    let message;
    if (error instanceof ApiError && error.status === 400) {
      message = `${error.message} La data è stata conservata. Correggi il valore prima di confermare.`;
      fieldError = error.message.includes('completedOn') || error.message.includes('calendario');
      if (fieldError) setCompletionDateError(error.message);
    } else {
      message = error.status === 404
        ? 'L’intervento non è più disponibile sul server.'
        : error.status === 409
        ? `Completamento non consentito: ${error.message}`
        : 'Completamento non confermato: la risposta non permette di sapere se è stato registrato.';
      message += ' La data è stata conservata. Usa Verifica scadenze e storico per controllare i dati prima di un nuovo completamento. La verifica non ripete la registrazione.';
      completionIssues.set(task.id, message);
      element('review-completion').hidden = false;
    }
    showCompletionError(message);
  } finally {
    setCompletionSaving(false);
  }
  if (!confirmed) {
    (fieldError ? completionDate : element('completion-error')).focus();
    return;
  }
  completionDrafts.delete(task.id);
  completionIssues.delete(task.id);
  completionOpener = taskTitle;
  completionDialog.close();
  // Native close() may briefly restore the old action before its close event.
  // Keep the refresh from returning focus to a second completion of that task.
  taskTitle.focus();
  element('task-feedback').textContent = `Completamento registrato: ${confirmed.title}, ${dateLabel(completedOn)}. ` +
    (confirmed.completed ? 'Intervento concluso; lo ritrovi nello Storico.' : `Intervento ancora attivo. Prossima scadenza: ${dateLabel(confirmed.dueDate)}.`);
  taskMutationConfirmed = 'Il completamento è stato registrato nello Storico. Non ripetere il completamento.';
  void loadMaintenance();
});

element('maintenance-tab').addEventListener('click', () => showView('maintenance'));
element('new-task').addEventListener('click', openTaskForm);
element('first-task').addEventListener('click', openTaskForm);
element('refresh-tasks').addEventListener('click', loadMaintenance);
element('retry-tasks').addEventListener('click', loadMaintenance);
element('retry-history').addEventListener('click', loadMaintenance);
element('task-first-item').addEventListener('click', addTaskItem);
element('task-form-first-item').addEventListener('click', addTaskItem);
element('retry-task-items').addEventListener('click', loadTaskItems);
element('close-task-form').addEventListener('click', closeTaskForm);
element('cancel-task-form').addEventListener('click', closeTaskForm);
element('review-task-creation').addEventListener('click', reviewTaskCreation);
element('review-task-edit').addEventListener('click', () => {
  if (taskSaving || reviewingTaskCreation) return;
  taskOpener = historyTitle;
  closeTaskForm();
  historyTitle.focus();
  void loadMaintenance();
});
taskDialog.addEventListener('cancel', event => {
  if (taskSaving || reviewingTaskCreation) event.preventDefault();
});
taskDialog.addEventListener('close', () => {
  if (taskDialog.open) return;
  invalidateTaskItemsLoad();
  restoreMaintenanceFocus(taskOpener);
});
for (const name of taskFieldNames) {
  taskForm.elements.namedItem(name).addEventListener('input', event => {
    if (!editingTask) taskDraft[name] = event.currentTarget.value;
    if (name === 'itemId') {
      taskSelectedItemId = event.currentTarget.value;
      showSelectedTaskItem();
    }
    if (event.currentTarget.getAttribute('aria-invalid') === 'true') {
      setTaskFieldError(name, taskFieldError(name, event.currentTarget.value));
    }
    if (taskFormErrorKind === 'validation' && taskFieldNames.every(field =>
      taskForm.elements.namedItem(field).getAttribute('aria-invalid') !== 'true')) showTaskFormError();
  });
}
taskForm.addEventListener('submit', async event => {
  event.preventDefault();
  if (taskSaving || reviewingTaskCreation || taskEditBlocked || !taskDialog.open ||
      (!editingTask && taskCreationRecovery?.tasks === null) || !taskItemsReady || taskItems.length === 0) return;
  showTaskFormError();
  const original = editingTask;
  const values = Object.fromEntries(taskFieldNames.map(name => [name, taskForm.elements.namedItem(name).value]));
  if (!original) Object.assign(taskDraft, values);
  const fields = Object.fromEntries(Object.entries(values).filter(([name, value]) => !original ||
    (name === 'intervalDays' ? !value.trim() || Number(value) !== Number(initialTaskFormValues[name]) : value !== initialTaskFormValues[name])));
  if (original && Object.keys(fields).length === 0) {
    taskOpener = original.completed ? historyTitle : taskTitle;
    taskDialog.close();
    taskOpener.focus();
    element('task-feedback').textContent = 'Nessuna modifica inviata. Rilettura degli interventi e dello storico in corso.';
    void loadMaintenance();
    return;
  }
  let invalidField;
  for (const name of taskFieldNames) {
    // Validate only changed fields when editing: normalized controls must not
    // force unrelated stored text to change or block a valid partial update.
    const message = Object.hasOwn(fields, name) ? taskFieldError(name, values[name]) : '';
    setTaskFieldError(name, message);
    if (message) invalidField ??= name;
  }
  if (invalidField) {
    showTaskFormError('Controlla i campi segnalati prima di salvare. I valori sono stati conservati.', 'validation');
    taskForm.elements.namedItem(invalidField).focus();
    return;
  }
  if (!original) taskCreationRecovery = null;
  renderTaskCreationRecovery();
  setTaskSaving(true);
  let savedTask;
  try {
    if (Object.hasOwn(fields, 'intervalDays')) fields.intervalDays = Number(fields.intervalDays);
    const result = await requestJSON(original ? `/api/tasks/${encodeURIComponent(original.id)}` : '/api/tasks', {
      method: original ? 'PATCH' : 'POST',
      headers: { 'Content-Type': 'application/json', ...(original ? { 'If-Match': JSON.stringify(original.updatedAt) } : {}) },
      body: JSON.stringify(fields),
      signal: AbortSignal.timeout(10000),
    });
    if (!isTask(result) || (original && result.id !== original.id)) throw new ApiError('Risposta inattesa: verifica le scadenze prima di riprovare il salvataggio.');
    savedTask = result;
  } catch (error) {
    if (error.status === 400) {
      invalidField = taskFieldNames.find(name => error.message.includes(`campo ${name} `));
      if (invalidField) setTaskFieldError(invalidField, error.message);
      if (invalidField === 'itemId') {
        taskItemsReady = false;
        element('task-items-error-message').textContent = 'L’oggetto scelto non è più disponibile. Ricarica l’inventario e scegline un altro; i valori del modulo restano disponibili.';
        element('task-items-error').hidden = false;
      }
    }
    if (!original && error.status !== 400) {
      taskCreationRecovery = { tasks: null, items: [], error: '' };
      renderTaskCreationRecovery();
      showTaskFormError('Salvataggio non confermato: l’intervento potrebbe essere già stato creato. I valori restano nel modulo. Usa Rileggi tutti gli interventi per controllare l’elenco prima di un nuovo tentativo; la verifica non ripete il salvataggio.');
    } else if (original && error.status !== 400) {
      taskEditBlocked = true;
      element('review-task-edit').hidden = false;
      const message = error.status === 404
        ? 'L’intervento non è più disponibile sul server, forse rimosso da un’altra finestra. Non verrà ricreato.'
        : error.status === 409
        ? `Modifica non consentita: ${error.message}`
        : 'Salvataggio non confermato: la risposta non permette di sapere se le modifiche sono state salvate.';
      showTaskFormError(`${message} I valori restano nel modulo. Scarta modifiche e rileggi chiude il modulo e aggiorna interventi e storico, senza ripetere la scrittura.`, 'conflict');
    } else showTaskFormError(error instanceof ApiError
      ? `${error.message} I valori sono stati conservati.${invalidField === 'itemId' ? ' Usa Riprova caricamento oggetti per aggiornare il menu.' : ''}`
      : 'Salvataggio non confermato: il servizio non risponde. La bozza è conservata. Chiudi e usa Aggiorna manutenzioni prima di riprovare, per evitare duplicati.');
  } finally {
    setTaskSaving(false);
  }
  if (!savedTask) {
    (invalidField ? taskForm.elements.namedItem(invalidField) : element('task-form-error')).focus();
    return;
  }
  if (!original) Object.assign(taskDraft, { title: '', itemId: '', dueDate: '', intervalDays: '0', notes: '' });
  taskOpener = savedTask.completed ? historyTitle : taskTitle;
  taskDialog.close();
  taskOpener.focus();
  element('task-feedback').textContent = `Intervento ${original ? 'aggiornato' : 'salvato'}: ${savedTask.title}.` +
    (original ? ' I completamenti nello Storico sono invariati.' : '');
  taskMutationConfirmed = `L’intervento è stato ${original ? 'aggiornato' : 'salvato'}. Non ripetere il salvataggio.`;
  void loadMaintenance();
});

// The browser checks the container for a useful preview. The service remains
// responsible for validating every field and reference before any write.
function backupCounts(backup) {
  if (backup === null || typeof backup !== 'object' || Array.isArray(backup)) {
    throw new Error('Il file deve contenere un backup JSON di Custode.');
  }
  if (backup.schemaVersion !== 1) throw new Error('Versione del backup non supportata: scegli un backup di Custode versione 1.');
  const keys = ['schemaVersion', 'items', 'tasks', 'history'];
  if (Object.keys(backup).some(key => !keys.includes(key)) ||
      !['items', 'tasks', 'history'].every(key => Array.isArray(backup[key]) &&
        backup[key].every(record => record !== null && typeof record === 'object' && !Array.isArray(record)))) {
    throw new Error('Il backup deve contenere gli elenchi di oggetti, interventi e storico nel formato di Custode.');
  }
  return { items: backup.items.length, tasks: backup.tasks.length, history: backup.history.length };
}

function updateBackupControls() {
  element('restore-backup').disabled = !selectedBackup || readingBackup || restoringBackup || restoreBlocked;
  element('confirm-restore').disabled = restoringBackup || restoreBlocked || !element('restore-consent').checked;
  element('restore-fields').disabled = restoringBackup || restoreBlocked;
  for (const id of ['cancel-restore', 'close-restore']) element(id).disabled = restoringBackup;
  element('confirm-restore').textContent = restoringBackup ? 'Ripristino…' : 'Conferma ripristino';
  restoreForm.setAttribute('aria-busy', String(restoringBackup));
}

function clearBackupSelection() {
  backupFileSequence += 1;
  selectedBackup = null;
  readingBackup = false;
  restoreBlocked = false;
  backupFile.value = '';
  backupFile.removeAttribute('aria-invalid');
  backupFile.setAttribute('aria-busy', 'false');
  element('backup-file-status').textContent = '';
  element('backup-file-error').hidden = true;
  element('backup-file-error').textContent = '';
  element('backup-filename').textContent = '';
  element('backup-file-summary').textContent = '';
  element('backup-preview').hidden = true;
  element('clear-backup-file').hidden = true;
  updateBackupControls();
}

async function readBackupFile() {
  const file = backupFile.files[0];
  const sequence = ++backupFileSequence;
  selectedBackup = null;
  restoreBlocked = false;
  readingBackup = Boolean(file);
  backupFile.removeAttribute('aria-invalid');
  backupFile.setAttribute('aria-busy', String(readingBackup));
  element('backup-feedback').textContent = '';
  element('backup-file-error').hidden = true;
  element('backup-file-error').textContent = '';
  element('backup-preview').hidden = true;
  element('backup-file-status').textContent = file ? 'Lettura del file… Nessun dato viene modificato.' : '';
  element('clear-backup-file').hidden = !file;
  updateBackupControls();
  if (!file) return;
  try {
    if (file.size > maxRestoreBytes) throw new Error('Il file supera 2 MiB. Il ripristino richiede una richiesta completa entro 2 MiB. Conserva il file e usa la copia della cartella dati a servizio fermo, come descritto nel README.');
    let bytes;
    try { bytes = await file.arrayBuffer(); }
    catch { throw new Error('Impossibile leggere il file. Verifica che sia ancora disponibile e scegli una copia leggibile.'); }
    if (sequence !== backupFileSequence) return;
    let backup;
    try { backup = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes)); }
    catch { throw new Error('Il file non contiene JSON valido in UTF-8. Scegli una copia integra del backup.'); }
    const counts = backupCounts(backup);
    const body = JSON.stringify({ backup, mode: 'replace' });
    if (new Blob([body]).size > maxRestoreBytes) {
      throw new Error('Il file entra in 2 MiB, ma la richiesta completa di ripristino supera il limite. Nessun dato è stato modificato. Usa la copia della cartella dati a servizio fermo, come descritto nel README.');
    }
    // Keep the prepared request unchanged through the confirmation step.
    selectedBackup = { name: file.name, counts, body };
    element('backup-filename').textContent = file.name;
    element('backup-file-summary').textContent = `Oggetti: ${counts.items} · Interventi: ${counts.tasks} · Completamenti: ${counts.history}.`;
    element('backup-preview').hidden = false;
    element('backup-file-status').textContent = 'File letto. Nessun dato modificato. Prosegui per controllare il riepilogo e confermare.';
  } catch (error) {
    if (sequence !== backupFileSequence) return;
    backupFile.setAttribute('aria-invalid', 'true');
    element('backup-file-status').textContent = '';
    element('backup-file-error').textContent = `${error.message} La lettura del file non ha modificato l’archivio.`;
    element('backup-file-error').hidden = false;
    if (currentView === 'backup' && document.activeElement === backupFile) element('backup-file-error').focus();
  } finally {
    if (sequence === backupFileSequence) {
      readingBackup = false;
      backupFile.setAttribute('aria-busy', 'false');
      updateBackupControls();
    }
  }
}

async function downloadBackup() {
  if (downloadingBackup) return;
  downloadingBackup = true;
  const button = element('download-backup');
  const status = element('download-status');
  button.disabled = true;
  element('download-error').hidden = true;
  status.textContent = 'Preparazione del backup completo…';
  status.focus();
  try {
    const response = await fetch('/api/backup', { headers: { Accept: 'application/json' }, cache: 'no-store', signal: AbortSignal.timeout(10000) });
    if (!response.ok) {
      const error = await response.json();
      throw new Error(typeof error?.error === 'string' ? error.error : 'Il servizio non ha prodotto il backup.');
    }
    const blob = await response.blob();
    // Verify that an error page is not offered as a backup. Download the exact
    // response bytes, without filtering, normalizing or serializing them again.
    let backup;
    try { backup = JSON.parse(await blob.text()); }
    catch { throw new Error('Il servizio ha restituito un file non valido. Riprova il download.'); }
    backupCounts(backup);
    const exceedsRestoreLimit = new Blob([JSON.stringify({ backup, mode: 'replace' })]).size > maxRestoreBytes;
    const url = URL.createObjectURL(blob);
    const link = node('a');
    const filename = `custode-backup-${browserToday()}.json`;
    link.href = url;
    link.download = filename;
    document.body.append(link);
    try { link.click(); }
    finally {
      link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 60000);
    }
    status.textContent = `Download avviato: ${filename}. Controlla i download del browser e conserva il file.`;
    if (exceedsRestoreLimit) status.textContent += ' L’archivio supera il limite di ripristino via interfaccia: conserva anche una copia della cartella dati a servizio fermo (README).';
  } catch (error) {
    status.textContent = '';
    element('download-error').textContent = `Backup non scaricato. ${error.name === 'TimeoutError' || error.name === 'TypeError' ? 'Controlla che Custode sia in esecuzione e riprova.' : error.message} Il download non modifica l’archivio.`;
    element('download-error').hidden = false;
    if (currentView === 'backup' && !anyDialogOpen() && document.activeElement === status) element('download-error').focus();
  } finally {
    downloadingBackup = false;
    button.disabled = false;
    if (currentView === 'backup' && !anyDialogOpen() && document.activeElement === status) button.focus();
  }
}

function openRestore(event) {
  if (!selectedBackup || readingBackup || restoringBackup || restoreBlocked || anyDialogOpen()) return;
  restoreOpener = event.currentTarget;
  restoreForm.reset();
  element('restore-error').hidden = true;
  element('restore-error').textContent = '';
  element('restore-status').textContent = '';
  element('restore-filename').textContent = selectedBackup.name;
  for (const key of ['items', 'tasks', 'history']) element(`restore-${key}-count`).textContent = String(selectedBackup.counts[key]);
  updateBackupControls();
  restoreDialog.showModal();
  restoreDialog.scrollTop = 0;
  element('cancel-restore').focus();
  element('cancel-restore').scrollIntoView({ block: 'nearest' });
}

function closeRestore() {
  if (!restoringBackup && restoreDialog.open) restoreDialog.close();
}

function discardReplacedArchive() {
  // Removed cards must never offer writes against the previous archive, even
  // if the reads after a confirmed restore fail or an earlier read arrives late.
  invalidateListLoad();
  invalidateMaintenanceLoad();
  invalidateTaskItemsLoad();
  items = [];
  loadedQuery = null;
  searchInput.value = '';
  needsMutationRefresh = true;
  for (const key of fieldNames) newItemDraft[key] = '';
  itemCreationRecovery = null;
  renderItemCreationRecovery();
  Object.assign(taskDraft, { title: '', itemId: '', dueDate: '', intervalDays: '0', notes: '' });
  completionDrafts.clear();
  completionIssues.clear();
  editingItem = deletionItem = initialFormValues = null;
  editingTask = deletionTask = completionTask = initialTaskFormValues = null;
  taskCreationRecovery = null;
  renderTaskCreationRecovery();
  taskItems = [];
  taskItemsReady = false;
  taskSelectedItemId = '';
  taskEditBlocked = taskDeleteBlocked = false;
  form.reset();
  taskForm.reset();
  completionForm.reset();
  showSelectedTaskItem();
  for (const id of ['item-list', 'task-list', 'history-list']) {
    element(id).replaceChildren();
    element(id).hidden = true;
  }
  const message = 'Ripristino completato. Oggetti, interventi e storico sono stati sostituiti. Le bozze precedenti sono state scartate.';
  element('backup-feedback').textContent = message;
  element('feedback').textContent = message;
  element('task-feedback').textContent = message;
  taskMutationConfirmed = 'Il ripristino è stato confermato dal server. Non ripetere la sostituzione.';
  void loadItems();
  void loadMaintenance();
}

element('backup-tab').addEventListener('click', () => showView('backup'));
element('download-backup').addEventListener('click', downloadBackup);
backupFile.addEventListener('change', readBackupFile);
element('clear-backup-file').addEventListener('click', () => {
  clearBackupSelection();
  backupFile.focus();
});
element('restore-backup').addEventListener('click', openRestore);
element('restore-consent').addEventListener('change', updateBackupControls);
element('cancel-restore').addEventListener('click', closeRestore);
element('close-restore').addEventListener('click', closeRestore);
restoreDialog.addEventListener('cancel', event => {
  if (restoringBackup) event.preventDefault();
});
restoreDialog.addEventListener('close', () => {
  if (restoreDialog.open) return;
  restoreForm.reset();
  updateBackupControls();
  if (restoreBlocked) {
    element('backup-file-error').textContent = element('restore-error').textContent;
    element('backup-file-error').hidden = false;
  }
  if (currentView === 'backup' && !anyDialogOpen()) {
    const visible = restoreOpener.isConnected && !restoreOpener.disabled && restoreOpener.getClientRects().length;
    (visible ? restoreOpener : backupTitle).focus();
  }
});
restoreForm.addEventListener('submit', async event => {
  event.preventDefault();
  if (restoringBackup || restoreBlocked || !restoreDialog.open || !selectedBackup || !element('restore-consent').checked) return;
  restoringBackup = true;
  updateBackupControls();
  element('restore-status').textContent = 'Sostituzione dell’archivio in corso. Attendi la conferma.';
  element('restore-status').focus();
  let confirmed = false;
  try {
    const result = await requestJSON('/api/restore', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: selectedBackup.body, signal: AbortSignal.timeout(10000),
    });
    if (result?.ok !== true) throw new Error('Risposta al ripristino inattesa.');
    confirmed = true;
  } catch (error) {
    const rejected = error instanceof ApiError && [400, 413, 415].includes(error.status);
    const message = rejected
      ? `Ripristino rifiutato: ${error.message} L’archivio non è stato sostituito. Annulla, rimuovi il file e scegli una copia valida.`
      : 'Esito del ripristino non confermato: l’archivio potrebbe essere già stato sostituito. Chiudi questa conferma, scarica il backup corrente e controlla Oggetti, scadenze e Storico prima di qualsiasi nuovo tentativo. Nessun reinvio automatico.';
    restoreBlocked = true;
    element('restore-error').textContent = message;
    element('restore-error').hidden = false;
  } finally {
    restoringBackup = false;
    element('restore-status').textContent = '';
    updateBackupControls();
  }
  if (!confirmed) {
    element('restore-error').focus();
    return;
  }
  clearBackupSelection();
  restoreOpener = backupTitle;
  restoreDialog.close();
  backupTitle.focus();
  discardReplacedArchive();
});

newItemButton.disabled = false;
void loadItems();
